import { readdir, stat, writeFile } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const distPath = join(__dirname, '..', 'dist');
const siteUrl = 'https://www.ourgovtjob.com';

async function generateSitemap() {
    let sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n';
    sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

    const pages = [
        { url: '', priority: '1.0', changefreq: 'daily' },
        { url: '/jobs', priority: '0.9', changefreq: 'daily' },
        { url: '/tests', priority: '0.8', changefreq: 'weekly' },
        { url: '/typing_test', priority: '0.7', changefreq: 'monthly' },
        { url: '/result', priority: '0.8', changefreq: 'weekly' },
        { url: '/admit-card', priority: '0.8', changefreq: 'weekly' },
        { url: '/answer-key', priority: '0.8', changefreq: 'weekly' },
        { url: '/misc', priority: '0.5', changefreq: 'yearly' },
    ];
    
    const today = new Date().toISOString();

    pages.forEach(page => {
        sitemap += '  <url>\n';
        sitemap += `    <loc>${siteUrl}${page.url}</loc>\n`;
        sitemap += `    <lastmod>${today}</lastmod>\n`;
        sitemap += `    <changefreq>${page.changefreq}</changefreq>\n`;
        sitemap += `    <priority>${page.priority}</priority>\n`;
        sitemap += '  </url>\n';
    });

    sitemap += '</urlset>';

    try {
        await writeFile(join(distPath, 'sitemap.xml'), sitemap);
        console.log('sitemap.xml generated successfully.');
    } catch (err) {
        console.error('Error generating sitemap.xml:', err);
    }
}

async function main() {
    try {
        await stat(distPath);
        await generateSitemap();
    } catch (error) {
        if (error.code === 'ENOENT') {
            console.error(`dist directory not found at ${distPath}. Run build first.`);
        } else {
            console.error('An error occurred:', error);
        }
    }
}

main();