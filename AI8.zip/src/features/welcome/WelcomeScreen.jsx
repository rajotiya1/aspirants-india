import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Briefcase, FileText, ArrowRight } from 'lucide-react';
import SEO from '@/components/SEO';
import { Button } from '@/components/ui/button';

const WelcomeScreen = () => {
  const navigate = useNavigate();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };

  return (
    <>
      <SEO title="Welcome to Aspirants India" description="Your one-stop destination for government and private jobs, online tests, and exam updates." />
      <motion.div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-primary to-purple-700 text-white p-8" variants={containerVariants} initial="hidden" animate="visible">
        <motion.div variants={itemVariants} className="text-center">
          <img alt="Aspirants India Logo" className="w-24 h-24 mx-auto mb-4 rounded-full shadow-lg" src="https://quomkiuitctcghdppqrj.supabase.co/storage/v1/object/public/logos/icon_Logo.png" />
          <h1 className="text-4xl font-extrabold tracking-tight">Latest Govt Jobs, Results, Current Affairs and Practice Sets of all categories. </h1>
          <p className="mt-2 text-lg text-primary-foreground/80">Your journey to success starts here.</p>
        </motion.div>

        <motion.ul variants={itemVariants} className="mt-12 space-y-4 text-left max-w-md w-full">
          <li className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
            <span className="text-lg">Latest Govt Jobs</span>
          </li>
          <li className="flex items-start space-x-3">
            <CheckCircle className="w-6 h-6 text-green-400 flex-shrink-0 mt-1" />
            <span className="text-lg">Current Affairs & All Online Tests</span>
          </li>
          <li className="flex items-start space-x-3">
            <Briefcase className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
            <span className="text-lg">Private & Foreign Jobs</span>
          </li>
          <li className="flex items-start space-x-3">
            <FileText className="w-6 h-6 text-blue-400 flex-shrink-0 mt-1" />
            <span className="text-lg">Results, Admit Cards, and more!</span>
          </li>
        </motion.ul>

        <motion.div variants={itemVariants} className="mt-12 w-full max-w-xs">
          <Button
            size="lg"
            className="w-full bg-white text-primary hover:bg-gray-100 font-bold text-lg py-6 rounded-full shadow-lg transition-transform transform hover:scale-105"
            onClick={() => navigate('/app/dashboard')}
          >
            Go to Dashboard <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </motion.div>
    </>
  );
};

export default WelcomeScreen;