
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  UserCircle,
  Briefcase,
  LayoutGrid,
  GraduationCap,
  CalendarCheck,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { cn } from '@/lib/utils';

const tabsConfig = [
  { path: '/app/profile', label: 'My Profile', icon: UserCircle, activeColor: 'text-pink-400' },
  { path: '/app/jobs', label: 'Jobs', icon: Briefcase, activeColor: 'text-blue-400' },
  { path: '/app/dashboard', label: 'Dashboard', icon: LayoutGrid, activeColor: 'text-yellow-400' },
  { path: '/app/study', label: 'Online Study', icon: GraduationCap, activeColor: 'text-green-400' },
  { path: '/app/exams', label: 'Exam/Result', icon: CalendarCheck, activeColor: 'text-purple-400' },
];

const BottomTabs = () => {
  const { user } = useAuth();
  const location = useLocation();

  const getPathForTab = (tab) => {
    if (tab.path === '/app/profile' && user) {
      return `${tab.path}/summary/${user.id}`;
    }
    return tab.path;
  };

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 right-0 z-50 h-16 sm:h-20" // Restored normal height
      style={{
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div className="mx-auto max-w-full h-full bg-white backdrop-blur-md shadow-[0_-2px_10px_rgba(0,0,0,0.1)]">

        {/* TOP ALIGNED NAV ICONS */}
        <nav className="flex justify-around items-center h-full text-gray-400"> {/* Changed items-start to items-center */}

          {tabsConfig.map((tab) => {
            const isActive = location.pathname.startsWith(tab.path);
            return (
              <NavLink
                key={tab.path}
                to={getPathForTab(tab)}
                className="flex flex-col items-center justify-center w-full h-full" // Center content vertically
              >
                <motion.div
                  initial={false}
                  animate={{ scale: isActive ? 1.2 : 1 }} // Slightly increased scale for active icon
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                  className={cn(
                    "flex flex-col items-center",
                    isActive ? `${tab.activeColor} drop-shadow-[0_0_8px_rgba(255,255,255,0.6)]` : ''
                  )}
                >
                  <tab.icon
                    className="w-6 h-6"
                    fill={isActive ? 'currentColor' : 'none'} // Solid fill for active icons
                    strokeWidth={isActive ? 0 : 2} // No stroke when filled, default stroke otherwise
                  />

                  <span
                    className={cn(
                      "text-[10px] font-medium mt-0.5",
                      isActive ? 'font-bold' : ''
                    )}
                  >
                    {tab.label}
                  </span>

                </motion.div>
              </NavLink>
            );
          })}

        </nav>
      </div>
    </motion.div>
  );
};

export default BottomTabs;
