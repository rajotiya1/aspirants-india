import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  UserCircle,
  Briefcase,
  LayoutGrid,
  GraduationCap,
  CalendarCheck,
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const tabsConfig = [
  { path: '/app/profile', label: 'My Profile', icon: UserCircle, activeColor: 'text-pink-400' },
  { path: '/app/jobs', label: 'Jobs', icon: Briefcase, activeColor: 'text-blue-400' },
  { path: '/app/dashboard', label: 'Dashboard', icon: LayoutGrid, activeColor: 'text-yellow-400' },
  { path: '/app/study', label: 'Online Study', icon: GraduationCap, activeColor: 'text-green-400' },
  { path: '/app/exams', label: 'Exam/Result', icon: CalendarCheck, activeColor: 'text-purple-400' },
];

const BottomTabs = () => {
  const { user } = useAuth();
  const location = useLocation();

  const getPathForTab = (tab) => {
    if (tab.path === '/app/profile' && user) {
      return `${tab.path}/summary/${user.id}`;
    }
    return tab.path;
  };

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        height: 'var(--tabbar-h)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      <div className="mx-auto max-w-full h-full bg-gray-900/95 backdrop-blur-md border-t border-gray-800 shadow-[0_-2px_10px_rgba(0,0,0,0.5)]">
        <nav className="flex justify-around items-center h-full text-gray-400">
          {tabsConfig.map((tab) => {
            const isActive = location.pathname.startsWith(tab.path);
            return (
              <NavLink
                key={tab.path}
                to={getPathForTab(tab)}
                className={`flex flex-col items-center justify-center text-center w-full h-full transition-all duration-300 ease-in-out ${isActive
                    ? `${tab.activeColor} scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.4)]`
                    : 'hover:text-white'
                  }`}
              >
                <tab.icon className="w-6 h-6" />
                <span className="text-[10px] font-medium mt-1">{tab.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>
    </motion.div>
  );
};

export default BottomTabs;