import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/SupabaseAuthContext';
import { PresenceProvider } from '@/contexts/PresenceContext';
import { BadgeProvider } from '@/contexts/BadgeContext';
import { Loader2 } from 'lucide-react';
import useWebViewNavigation from '@/hooks/useWebViewNavigation';

import ScrollToTop from '@/components/common/ScrollToTop';

const AppShell = lazy(() => import('@/app/AppShell'));
const WelcomeScreen = lazy(() => import('@/features/welcome/WelcomeScreen'));
const AppDashboard = lazy(() => import('@/app/pages/AppDashboard'));
const AppJobs = lazy(() => import('@/app/pages/AppJobs'));
const AppProfile = lazy(() => import('@/app/pages/AppProfile'));
const AppStudy = lazy(() => import('@/app/pages/AppStudy'));
const AppExams = lazy(() => import('@/app/pages/AppExams'));
const MyStoryPage = lazy(() => import('@/pages/profile/MyStoryPage'));
const Login = lazy(() => import('@/pages/Login'));
const UpdatePassword = lazy(() => import('@/pages/UpdatePassword'));
const JobDetail = lazy(() => import('@/pages/JobDetail'));
const Admin = lazy(() => import('@/pages/Admin'));
const StoryListPage = lazy(() => import('@/pages/story/StoryListPage'));
const StoryDetailPage = lazy(() => import('@/pages/story/StoryDetailPage'));
const SubmitStoryPage = lazy(() => import('@/pages/story/SubmitStoryPage'));
const StoryManagement = lazy(() => import('@/pages/admin/StoryManagement'));
const Page = lazy(() => import('@/pages/Page'));
const ResumeBuilder = lazy(() => import('@/pages/ResumeBuilder'));
const SalaryCalculator = lazy(() => import('@/pages/SalaryCalculator'));
const ExamResourcesPage = lazy(() => import('@/pages/ExamResourcesPage'));

const LoadingFallback = () => (
  <div className="w-full h-screen flex items-center justify-center bg-background">
    <Loader2 className="animate-spin text-primary h-16 w-16" />
  </div>
);

const ProtectedRoute = ({ adminOnly = false }) => {
  const { user, loading } = useAuth();
  if (loading) return <LoadingFallback />;
  if (!user) return <Navigate to="/login" replace />;
  if (adminOnly && user && !user.is_admin) return <Navigate to="/app/dashboard" replace />;
  return <Outlet />;
};

const AppRoutes = () => {
  useWebViewNavigation();
  const { user, loading } = useAuth();
  if (loading) return <LoadingFallback />;

  const RootRedirect = () => (!user ? <Navigate to="/login" replace /> : <Navigate to="/welcome" replace />);

  return (
    <Suspense fallback={<LoadingFallback />}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/update-password" element={<UpdatePassword />} />
        <Route path="/page/:slug" element={<Page />} />
        <Route path="/" element={<RootRedirect />} />

        <Route element={<ProtectedRoute />}>
          <Route path="/welcome" element={<WelcomeScreen />} />
          <Route path="/app" element={<AppShell />}>
            <Route path="dashboard/*" element={<AppDashboard />} />
            <Route path="jobs/*" element={<AppJobs />} />
            <Route path="profile/my-story" element={<MyStoryPage />} />
            <Route path="profile/*" element={<AppProfile />} />
            <Route path="study/*" element={<AppStudy />} />
            <Route path="exams/*" element={<AppExams />} />
            <Route path="exam-resources" element={<ExamResourcesPage />} />
            <Route index element={<Navigate to="dashboard" replace />} />
          </Route>

          <Route path="/stories" element={<StoryListPage />} />
          <Route path="/stories/:slug" element={<StoryDetailPage />} />
          <Route path="/submit-story" element={<SubmitStoryPage />} />
          <Route path="/job/:slug" element={<JobDetail />} />
                    
          <Route path="/resume-builder" element={<ResumeBuilder />} />
          <Route path="/salary-calculator" element={<SalaryCalculator />} />
        </Route>

        <Route element={<ProtectedRoute adminOnly={true} />}>
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin/stories" element={<StoryManagement />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
};

const AppContent = () => (
  <Router>
    <ScrollToTop />
    <AppRoutes />
  </Router>
);

const AppWithProviders = () => (
  <AuthProvider>
    <PresenceProvider>
      <BadgeProvider>
        <AppContent />
      </BadgeProvider>
    </PresenceProvider>
  </AuthProvider>
);

function App() {
  return <AppWithProviders />;
}

export default App;