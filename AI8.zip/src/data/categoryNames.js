// ===============================
// CATEGORY NAME MAPPING (Frontend)
// ===============================
//
// Purpose:
// - Backend में मिलने वाला `shortName` हमेशा stable रहेगा (e.g., "SB1GK")
// - Frontend में user-friendly नाम दिखेगा (e.g., "Static GK Special")
// - केवल यहीं बदलाव करो → पूरा app अपने-आप update हो जाएगा
// - Test Book, Leaderboard, Profile, सब जगह एक समान नाम
//

export const CATEGORY_DISPLAY = {
  // ---- DEFAULT SYSTEM CATEGORIES ----
  "English-Test": "Daily Current Affairs",
  "SSC": "Static GK (SSC)",
  "UPSC": "UPSC Current Affairs",
  "Haryana": "Haryana Current Affairs",
  "Rajasthan": "Rajasthan Current Affairs",
  "U.P.": "Uttar Pradesh Current Affairs",
  "Bihar": "Bihar Current Affairs",

  // ---- SPECIAL BATCHES (Editable anytime) ----
  // Add your custom readable names here

  "SpecialBatch1GK": "Static GK Special",          // Special Batch 1
  "SpecialBatch2GK": "GK Advanced Batch",          // Example
  "SpecialBatch3ENG": "English Master Batch",      // Example
  "SpecialBatch4CSE": "Civil Services Batch",      // Example
  "SpecialBatch5SCI": "General Science Special",   // Example
  "SpecialBatch6HIS": "History Deep Batch",        // Example

  // Note: आप जितने चाहो उतने add कर सकते हो
};


// ⭐ Master function → Always use this to show names in frontend
export const getCategoryName = (category) => {
  return CATEGORY_DISPLAY[category] || category;
};
