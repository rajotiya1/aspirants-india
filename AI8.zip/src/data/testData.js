export const testCategories = {
    SSC: {
      name: "SSC",
      description: "Staff Selection Commission",
      icon: "🏛️",
      questions: [
        {
          id: 1,
          question: "What is the capital of India?",
          options: ["Mumbai", "Delhi", "Kolkata", "Chennai"],
          correct: 1
        },
        {
          id: 2,
          question: "Who is known as the Father of the Nation in India?",
          options: ["Jawaharlal Nehru", "Mahatma Gandhi", "Subhas Chandra Bose", "Bhagat Singh"],
          correct: 1
        },
        {
          id: 3,
          question: "What is 15% of 200?",
          options: ["25", "30", "35", "40"],
          correct: 1
        }
      ]
    },
    UPSC: {
      name: "UPSC",
      description: "Union Public Service Commission",
      icon: "🎯",
      questions: [
        {
          id: 1,
          question: "Which article of the Indian Constitution deals with Right to Education?",
          options: ["Article 19", "Article 21A", "Article 25", "Article 32"],
          correct: 1
        },
        {
          id: 2,
          question: "The Tropic of Cancer passes through how many Indian states?",
          options: ["6", "7", "8", "9"],
          correct: 2
        },
        {
          id: 3,
          question: "Who was the first Governor-General of independent India?",
          options: ["Lord Mountbatten", "C. Rajagopalachari", "Warren Hastings", "Lord Curzon"],
          correct: 0
        }
      ]
    },
    Haryana: {
      name: "Haryana",
      description: "Haryana State Exams",
      icon: "🌾",
      questions: [
        {
          id: 1,
          question: "What is the capital of Haryana?",
          options: ["Chandigarh", "Gurgaon", "Faridabad", "Panipat"],
          correct: 0
        },
        {
          id: 2,
          question: "Which river flows through Haryana?",
          options: ["Ganga", "Yamuna", "Sutlej", "Ravi"],
          correct: 1
        },
        {
          id: 3,
          question: "Haryana was formed in which year?",
          options: ["1965", "1966", "1967", "1968"],
          correct: 1
        }
      ]
    },
    Center: {
      name: "Center",
      description: "Central Government Exams",
      icon: "🏢",
      questions: [
        {
          id: 1,
          question: "How many members are there in Lok Sabha?",
          options: ["543", "545", "550", "552"],
          correct: 1
        },
        {
          id: 2,
          question: "Who is the current Chief Justice of India?",
          options: ["D.Y. Chandrachud", "N.V. Ramana", "S.A. Bobde", "Ranjan Gogoi"],
          correct: 0
        },
        {
          id: 3,
          question: "Which is the highest civilian award in India?",
          options: ["Padma Vibhushan", "Bharat Ratna", "Padma Bhushan", "Padma Shri"],
          correct: 1
        }
      ]
    }
  };