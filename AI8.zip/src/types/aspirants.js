// This file can be used to define shapes for JSDoc or for future migration to TypeScript.

/**
 * @typedef {Object} JobSurveySummary
 * @property {string} id
 * @property {string} title
 * @property {string} authority
 */

/**
 * @typedef {Object} CategoryCount
 * @property {number} category_id
 * @property {string} category_name
 * @property {number} applicant_count
 */

/**
 * @typedef {Object} ApplicantPublic
 * @property {string} name
 * @property {string} district
 * @property {string} state
 */

/**
 * @typedef {Object} MyApplication
 * @property {string} id - application id
 * @property {string} job_survey_id
 * @property {string} job_title
 * @property {number} category_id
 * @property {string} category_name
 */

/**
 * @typedef {Object} UpdateItem
 * @property {string} id
 * @property {string} content
 * @property {string} created_at
 * @property {number|null} category_id - null for job-wide updates
 */

export {};