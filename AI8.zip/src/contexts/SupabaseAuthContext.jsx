import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { getFriendlyErrorMessage } from '@/lib/errorUtils';
import { Loader2 } from 'lucide-react';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchUserProfile = useCallback(async (authUser) => {
    if (!authUser) return null;
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authUser.id)
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 = profile not found, which is ok
      console.error("Error fetching profile:", error);
      toast({
        variant: "destructive",
        title: "Profile Error",
        description: getFriendlyErrorMessage(error),
      });
      return { ...authUser }; // Return auth user data even if profile fetch fails
    }
    
    return { ...authUser, ...profile };
  }, [toast]);
  
  const handleSession = useCallback(async (currentSession) => {
    setLoading(true);
    if (currentSession?.user) {
      const userWithProfile = await fetchUserProfile(currentSession.user);
      setUser(userWithProfile);
      setSession(currentSession);
    } else {
      setUser(null);
      setSession(null);
    }
    setLoading(false);
  }, [fetchUserProfile]);

  useEffect(() => {
    const initializeSession = async () => {
      const { data: { session: initialSession } } = await supabase.auth.getSession();
      await handleSession(initialSession);
    };

    initializeSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        handleSession(session);
      }
    );

    return () => subscription?.unsubscribe();
  }, [handleSession]);

  const signOut = useCallback(async (options = { redirect: true }) => {
    const { error } = await supabase.auth.signOut();
    setUser(null);
    setSession(null);

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign out Failed",
        description: getFriendlyErrorMessage(error),
      });
    }
    
    if (options.redirect) {
      window.location.href = '/login';
    }

    return { error };
  }, [toast]);

  const signUp = useCallback(async (email, password, options) => {
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options,
    });
    setLoading(false);

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign up Failed",
        description: getFriendlyErrorMessage(error),
      });
    }
    return { error };
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);
    
    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: getFriendlyErrorMessage(error),
      });
    }
    return { error };
  }, [toast]);

  const refreshProfile = useCallback(async () => {
    if (session?.user) {
      const userWithProfile = await fetchUserProfile(session.user);
      setUser(userWithProfile);
    }
  }, [fetchUserProfile, session]);

  const value = useMemo(() => ({
    user,
    session,
    loading,
    authLoading: loading,
    signUp,
    signIn,
    signOut,
    refreshProfile,
  }), [user, session, loading, signUp, signIn, signOut, refreshProfile]);

  return (
      <AuthContext.Provider value={value}>
          {loading ? (
              <div className="w-full h-screen flex items-center justify-center bg-background">
                  <Loader2 className="animate-spin text-primary h-16 w-16" />
              </div>
          ) : (
              children
          )}
      </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};