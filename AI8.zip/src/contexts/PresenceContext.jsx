import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase'; // Corrected import
import { useAuth } from '@/contexts/SupabaseAuthContext';

const PresenceContext = createContext();

export const usePresence = () => useContext(PresenceContext);

export const PresenceProvider = ({ children }) => {
  const { user } = useAuth();
  const [onlineUsers, setOnlineUsers] = useState(new Map());

  useEffect(() => {
    if (!user) {
      setOnlineUsers(new Map());
      return;
    }

    const channel = supabase.channel('online-users', {
      config: {
        presence: {
          key: user.id,
        },
      },
    });

    channel
      .on('presence', { event: 'sync' }, () => {
        const newState = new Map();
        const presences = channel.presenceState();
        for (const id in presences) {
          const presence = presences[id][0];
          newState.set(presence.user.id, presence.user);
        }
        setOnlineUsers(newState);
      })
      .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        setOnlineUsers(prev => {
          const newMap = new Map(prev);
          newMap.set(key, newPresences[0].user);
          return newMap;
        });
      })
      .on('presence', { event: 'leave' }, ({ key }) => {
        setOnlineUsers(prev => {
          const newMap = new Map(prev);
          newMap.delete(key);
          return newMap;
        });
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({
            user: {
              id: user.id,
              name: user.name,
              avatar_url: user.avatar_url,
              show_online_status: user.show_online_status,
            },
            online_at: new Date().toISOString(),
          });
        }
      });
      
    const updateLastSeen = async () => {
        if (user) {
            await supabase.from('profiles').update({ last_seen: new Date().toISOString() }).eq('id', user.id);
        }
    };
    
    window.addEventListener('beforeunload', updateLastSeen);

    return () => {
      channel.unsubscribe();
      window.removeEventListener('beforeunload', updateLastSeen);
      updateLastSeen(); // Set last seen on logout/unmount
    };
  }, [user]);

  return (
    <PresenceContext.Provider value={{ onlineUsers }}>
      {children}
    </PresenceContext.Provider>
  );
};