import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase'; // Corrected import
import { useAuth } from './SupabaseAuthContext';

const BadgeContext = createContext({
  badgeState: {},
  checkAllUpdates: async () => {},
  markAsSeen: async () => {},
});

export const useBadges = () => useContext(BadgeContext);

export const BadgeProvider = ({ children }) => {
  const { user } = useAuth();
  const [badgeState, setBadgeState] = useState({});
  const [lastChecked, setLastChecked] = useState(null);

  const checkAllUpdates = useCallback(async () => {
    if (!user) {
      setBadgeState({});
      return;
    }
    
    if (lastChecked && (Date.now() - lastChecked < 30000)) {
        return;
    }

    setLastChecked(Date.now());

    try {
      const { data, error } = await supabase.rpc('get_all_update_statuses');
      
      if (error) {
        // Log the error but don't show a toast to avoid interrupting the user for a background task.
        console.error('Error fetching badge statuses:', error.message);
        return;
      }
      
      if (data) {
        const newState = data.reduce((acc, item) => {
          acc[item.section] = item.has_new_updates;
          return acc;
        }, {});
        setBadgeState(newState);
      }

    } catch (e) {
      console.error('Error in checkAllUpdates:', e.message);
    }
  }, [user, lastChecked]);

  useEffect(() => {
    checkAllUpdates();

    const interval = setInterval(() => {
      checkAllUpdates();
    }, 60000);

    return () => clearInterval(interval);
  }, [checkAllUpdates]);
  
  useEffect(() => {
      if(!user) setBadgeState({});
  }, [user]);

  const markAsSeen = useCallback(async (section) => {
    if (!user || !section) return;

    setBadgeState(prev => ({ ...prev, [section]: false }));

    const { error } = await supabase
      .from('user_last_seen')
      .upsert({ user_id: user.id, section: section, last_seen_at: new Date().toISOString() }, { onConflict: 'user_id, section' });

    if (error) {
      console.error(`Error marking ${section} as seen:`, error);
      setBadgeState(prev => ({ ...prev, [section]: true }));
    }
  }, [user]);

  const value = useMemo(() => ({
    badgeState,
    checkAllUpdates,
    markAsSeen,
  }), [badgeState, checkAllUpdates, markAsSeen]);

  return (
    <BadgeContext.Provider value={value}>
      {children}
    </BadgeContext.Provider>
  );
};