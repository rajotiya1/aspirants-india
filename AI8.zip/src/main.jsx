import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { Toaster } from '@/components/ui/toaster';
import { HelmetProvider } from 'react-helmet-async';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // This is the key change. It prevents react-query from
      // re-fetching data automatically whenever the window regains focus.
      // This stops the "page refresh" feel when switching tabs or apps.
      refetchOnWindowFocus: false,
    },
  },
});


ReactDOM.createRoot(document.getElementById('root')).render(
  <>
    <QueryClientProvider client={queryClient}>
      <HelmetProvider>
        <App />
        {/* Toaster is intentionally placed here to be outside the main app for global accessibility */}
        <Toaster />
      </HelmetProvider>
    </QueryClientProvider>
  </>
);