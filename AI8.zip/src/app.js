import React from "react";

// default export (most common usage)
export default function App() {
  return null; // keep empty; we just need the module to exist
}

// also provide named exports in case some files import { App } or { app }
export { App };
export const app = App;