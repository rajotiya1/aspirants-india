
import React, { useRef, useEffect, memo } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import BottomTabs from '@/widgets/BottomTabs';
import { Toaster } from '@/components/ui/toaster';
import { isWebViewGold } from '@/lib/admob';
import WebViewAdBanner from '@/components/WebViewAdBanner';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';
import UserAvatar from '@/components/UserAvatar';
import Footer from '@/components/Footer';

const pageNames = {
  '/app/profile': 'My Profile',
  '/app/jobs': 'Jobs',
  '/app/exams': 'Exam / Result',
  '/app/study': 'Online Study',
  '/app/dashboard': 'Dashboard',
};

const TopHeader = memo(() => {
  const { user, profile, signOut } = useAuth();
  const location = useLocation();

  const activePage = Object.keys(pageNames).find((path) =>
    location.pathname.startsWith(path)
  );
  const pageTitle = pageNames[activePage] || 'Aspirants India';

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-gray-200 flex items-center justify-between px-4 py-2">
      <div className="flex items-center gap-3">
        <Link to="/app/profile">
          <UserAvatar profile={profile} user={user} />
        </Link>
        <span className="font-semibold text-gray-800 text-sm sm:text-base">
          {pageTitle}
        </span>
      </div>

      <Button
        onClick={signOut}
        variant="outline"
        size="sm"
        className="flex items-center gap-2 text-gray-700 hover:bg-gray-100"
      >
        <LogOut className="h-4 w-4" />
        <span className="hidden sm:inline">Logout</span>
      </Button>
    </header>
  );
});

const AppShell = ({ children }) => {
  const mainRef = useRef(null);
  const location = useLocation();
  const showAds = isWebViewGold();

  // Scroll Reset Logic
  useEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: 'instant' });
    }
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [location.pathname]);

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {showAds && <WebViewAdBanner />}

      <TopHeader />

      <main ref={mainRef} className="flex-1 overflow-y-auto pb-24">
        {children || <Outlet />}
        <Footer />
      </main>

      <BottomTabs />
      <Toaster />
    </div>
  );
};

export default AppShell;
