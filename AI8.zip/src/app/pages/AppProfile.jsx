import React, { lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import TabSystem from '@/components/TabSystem';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useTargetUserId } from '@/hooks/useTargetUserId';
import { Loader2 } from 'lucide-react';
import LatestArticles from '@/components/LatestArticles';

const MyProfileInfo = lazy(() => import('@/pages/profile/MyProfileInfo'));
const SavedJobs = lazy(() => import('@/pages/SavedJobs'));
const AppliedJobsPage = lazy(() => import('@/pages/profile/AppliedJobsPage'));
const Friends = lazy(() => import('@/pages/Friends'));
const TestPerformanceTab = lazy(() => import('@/components/profile/TestPerformanceTab'));
const EducationalDetailsTab = lazy(() => import('@/components/profile/EducationalDetailsTab'));
const AchievementsTab = lazy(() => import('@/components/profile/AchievementsTab'));

const ProfileContent = () => {
  const targetUserId = useTargetUserId();
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex justify-center items-center h-full pt-10"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
  }
  
  if (!targetUserId) {
    if (user?.id) {
      return <Navigate to={`/app/profile/summary/${user.id}`} replace />;
    }
    return <Navigate to="/login" replace />;
  }

  const tabs = [
    { path: `summary/${targetUserId}`, label: 'Profile', component: <MyProfileInfo /> },
    { path: `saved-jobs/${targetUserId}`, label: 'Saved Jobs', component: <SavedJobs /> },
    { path: `applied-jobs/${targetUserId}`, label: 'Applied Jobs', component: <AppliedJobsPage /> },
    { path: `tests/${targetUserId}`, label: 'Test Book', component: <TestPerformanceTab /> },
    { path: `friends/${targetUserId}`, label: 'Friends', component: <Friends /> },
    { path: `education/${targetUserId}`, label: 'Education', component: <EducationalDetailsTab /> },
    { path: `achievements/${targetUserId}`, label: 'Achievements', component: <AchievementsTab /> },
  ];

  return (
    <>
      <TabSystem tabs={tabs} basepath="/app/profile" />

    </>
  );
};

const AppProfile = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
  }

  return (
    <div className="flex flex-col h-full">
      <main className="flex-grow overflow-y-auto">
        <Routes>
          <Route path=":tab/:userId" element={<ProfileContent />} />
          <Route path=":tab" element={<ProfileContent />} />
          <Route index element={user?.id ? <Navigate to={`summary/${user.id}`} replace /> : <Navigate to="/login" replace />} />
        </Routes>
      </main>
    </div>
  );
};

export default AppProfile;