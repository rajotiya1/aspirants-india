import React, { lazy, Suspense } from 'react';
import { Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

const JobListing = lazy(() => import('@/pages/JobListing'));
const PvtJobsPage = lazy(() => import('@/pages/PvtJobsPage'));
const ForeignJobsPage = lazy(() => import('@/pages/ForeignJobsPage'));

const topTabs = [
	{ path: 'govt', label: 'Govt Jobs' },
	{ path: 'pvt', label: 'Private Jobs' },
	/*{ path: 'foreign', label: 'Foreign Jobs' },*/ //frontend se hide kiya gya on 21-11-2025
];

const LoadingFallback = () => (
	<div className="w-full h-full flex items-center justify-center bg-background p-8">
		<Loader2 className="animate-spin text-primary h-10 w-10" />
	</div>
);

const TopNavBar = () => {
	const location = useLocation();

	return (
		<nav className="w-full flex-shrink-0 bg-gray-800 sticky top-0 z-20">
			<div className="flex items-center justify-center space-x-2 py-2">
				{topTabs.map(tab => {
					const isActive = location.pathname.startsWith(`/app/jobs/${tab.path}`);
					return (
						<Link
							key={tab.path}
							to={tab.path}
							className={cn(
								"shrink-0 whitespace-nowrap rounded-md px-5 py-2 text-sm font-medium transition-all duration-200",
								isActive
									? "bg-green-500 text-white shadow-md"
									: "bg-gray-700 text-gray-200 hover:bg-gray-600"
							)}
						>
							{tab.label}
						</Link>
					);
				})}
			</div>
		</nav>
	);
};

const AppJobs = () => {
	return (
		<div className="flex flex-col min-h-screen bg-background overflow-y-auto">
			<TopNavBar />
			<main className="flex-grow overflow-y-auto p-2">
				<Suspense fallback={<LoadingFallback />}>
					<Routes>
						<Route path="govt" element={<JobListing />} />
						<Route path="govt/:category" element={<JobListing />} />
						<Route path="pvt" element={<PvtJobsPage />} />
						<Route path="foreign" element={<ForeignJobsPage />} />
						<Route index element={<Navigate to="govt" replace />} />
					</Routes>
				</Suspense>
			</main>
		</div>
	);
};

export default AppJobs;