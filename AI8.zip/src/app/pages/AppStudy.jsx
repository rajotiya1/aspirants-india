// =====================
//    AppStudy.jsx
// =====================

import React, { lazy } from "react";
import { Routes, Route, NavLink } from "react-router-dom";
import { motion } from "framer-motion";

import {
  FileText,
  BookOpen,
  Type,
  Award,
  Trophy,
  Keyboard,
  Globe
} from "lucide-react";

import HtmlViewer from "@/components/HtmlViewer";

// Child pages here
const OnlineTests = lazy(() => import('@/pages/OnlineTests'));
const EnglishTest = lazy(() => import('@/pages/EnglishTest'));
const SSCOnlineTests = lazy(() => import('@/pages/SSCOnlineTests'));
const HSSConlineTests = lazy(() => import('@/pages/HSSConlineTests'));
const TypingTest = lazy(() => import('@/pages/TypingTest'));
const SpecialBatch1 = lazy(() => import('@/pages/SpecialBatch1'));

// ----------------------
// Theme Styles
// ----------------------
const themeStyles = {
  blue: { icon: "text-blue-600", bg: "bg-blue-100" },
  green: { icon: "text-emerald-600", bg: "bg-emerald-100" },
  purple: { icon: "text-purple-600", bg: "bg-purple-100" },
  amber: { icon: "text-amber-600", bg: "bg-amber-100" },
  red: { icon: "text-red-600", bg: "bg-red-100" },
  indigo: { icon: "text-indigo-600", bg: "bg-indigo-100" },
  pink: { icon: "text-pink-600", bg: "bg-pink-100" },
  teal: { icon: "text-teal-600", bg: "bg-teal-100" },
  cyan: { icon: "text-cyan-600", bg: "bg-cyan-100" },
  fuchsia: { icon: "text-fuchsia-600", bg: "bg-fuchsia-100" },
  orange: { icon: "text-orange-600", bg: "bg-orange-100" },
  lime: { icon: "text-lime-600", bg: "bg-lime-100" },
  sky: { icon: "text-sky-600", bg: "bg-sky-100" },
  rose: { icon: "text-rose-600", bg: "bg-rose-100" },
};

// ----------------------
// DashboardButton
// ----------------------
const DashboardButton = ({ to, text, icon: Icon, theme = "blue" }) => {
  const currentTheme = themeStyles[theme] || themeStyles.blue;

  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -4 }}
      whileTap={{ scale: 0.97 }}
      className="relative transition-all duration-200 ease-in-out"
    >
      <NavLink
        to={to}
        aria-label={text}
        className="
          flex flex-col items-center justify-center p-2 text-center h-full
          bg-card rounded-2xl border
          shadow-md hover:shadow-lg hover:border-primary/50
          transition-all duration-200
        "
      >
        <div
          className={`w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors ${currentTheme.bg}`}
        >
          <Icon className={`w-6 h-6 ${currentTheme.icon}`} />
        </div>

        <span className="font-semibold text-foreground leading-tight text-xs sm:text-sm whitespace-nowrap">
          {text}
        </span>
      </NavLink>
    </motion.div>
  );
};

// ----------------------
// Home Study Buttons Grid
// ----------------------
const StudyHome = () => {
  const cardData = [
    { to: "/app/study/english-test", text: "Daily Current Affairs", icon: BookOpen, theme: "blue" },
    { to: "/app/study/ssc-online-test", text: "SSC Tests", icon: Trophy, theme: "purple" },
    { to: "/app/study/hssc-online-test", text: "HSSC Tests", icon: Award, theme: "amber" },
    { to: "/app/study/online-test", text: "Reet Mains", icon: FileText, theme: "green" },
    { to: "/app/study/special-batch-1", text: "Static GK", icon: FileText, theme: "green" },
    { to: "/app/study/typing-test", text: "Typing Test", icon: Keyboard, theme: "pink" },

    // ============================================================
    //   🔒 HTML STATIC STUDY PAGES (COMMENTED OUT)
    //   ------------------------------------------------------------
    //   👉 These buttons are HIDDEN from the /app/study page.
    //   👉 To show any button, simply un-comment that line.
    //   👉 Route will still work from Dashboard.
    // ============================================================

    /*
    { to: "/app/study/exam-preparation", text: "Exam Prep", icon: Globe, theme: "teal" },
    { to: "/app/study/notes", text: "Notes", icon: Globe, theme: "indigo" },
    { to: "/app/study/study-material", text: "Study Material", icon: Globe, theme: "orange" },
    { to: "/app/study/gk-pages", text: "GK Pages", icon: Globe, theme: "red" },
    { to: "/app/study/quizzes", text: "Quizzes", icon: Globe, theme: "fuchsia" },
    { to: "/app/study/learning", text: "Learning", icon: Globe, theme: "cyan" },
    { to: "/app/study/mcqs", text: "MCQs", icon: Globe, theme: "lime" },
    { to: "/app/study/online-class", text: "Online Class", icon: Globe, theme: "sky" },
    { to: "/app/study/online-coaching", text: "Online Coaching", icon: Globe, theme: "rose" },
    { to: "/app/study/study-games", text: "Study Games", icon: Globe, theme: "purple" },
    */

  ];

  return (
    <div className="p-4 overflow-y-auto h-full pb-20">
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-4">
        {cardData.map((item, i) => (
          <DashboardButton key={i} {...item} />
        ))}
      </div>
    </div>
  );
};

// ----------------------
// Final Routing
// ----------------------
const AppStudy = () => {
  return (
    <Routes>
      <Route index element={<StudyHome />} />

      {/* Existing Tests */}
      <Route path="online-test" element={<OnlineTests />} />
      <Route path="english-test" element={<EnglishTest />} />
      <Route path="ssc-online-test" element={<SSCOnlineTests />} />
      <Route path="hssc-online-test" element={<HSSConlineTests />} />
      <Route path="typing-test" element={<TypingTest />} />
      <Route path="special-batch-1" element={<SpecialBatch1 />} />

      {/* ⭐ Permanent 10 HTML pages */}
      <Route path="exam-preparation" element={<HtmlViewer src="/study-pages/exam-preparation.html" title="Exam Preparation" />} />
      <Route path="notes" element={<HtmlViewer src="/study-pages/notes.html" title="Notes" />} />
      <Route path="study-material" element={<HtmlViewer src="/study-pages/study-material.html" title="Study Material" />} />
      <Route path="gk-pages" element={<HtmlViewer src="/study-pages/gk-pages.html" title="GK Pages" />} />
      <Route path="quizzes" element={<HtmlViewer src="/study-pages/quizzes.html" title="Quizzes" />} />
      <Route path="learning" element={<HtmlViewer src="/study-pages/learning.html" title="Learning" />} />
      <Route path="mcqs" element={<HtmlViewer src="/study-pages/mcqs.html" title="MCQs" />} />
      <Route path="online-class" element={<HtmlViewer src="/study-pages/online-class.html" title="Online Class" />} />
      <Route path="online-coaching" element={<HtmlViewer src="/study-pages/online-coaching.html" title="Online Coaching" />} />
      <Route path="study-games" element={<HtmlViewer src="/study-pages/study-games.html" title="Study Games" />} />
    </Routes>
  );
};

export default AppStudy;