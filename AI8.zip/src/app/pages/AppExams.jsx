import React, { lazy } from 'react';
import TabSystem from '@/components/TabSystem';
import LatestArticles from '@/components/LatestArticles';

const ExamDate = lazy(() => import('@/pages/ExamDate'));
const AdmitCard = lazy(() => import('@/pages/AdmitCard'));
const AnswerKey = lazy(() => import('@/pages/AnswerKey'));
const Result = lazy(() => import('@/pages/Result'));

const tabs = [
  { path: 'exam-date', label: 'Exam Date', component: <ExamDate /> },
  { path: 'admit-card', label: 'Admit Card', component: <AdmitCard /> },
  { path: 'answer-key', label: 'Answer Key', component: <AnswerKey /> },
  { path: 'result', label: 'Result', component: <Result /> },
];

const AppExams = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background overflow-y-auto">
      {/* Main tab system area */}
      <main className="flex-grow relative overflow-y-auto pb-24">
        <TabSystem tabs={tabs} basepath="/app/exams" />
      </main>

      {/* Story / LatestArticles Section */}
      <footer className="flex-shrink-0 p-4 bg-gray-100 border-t border-gray-200">
        <LatestArticles />
      </footer>
    </div>
  );
};

export default AppExams;