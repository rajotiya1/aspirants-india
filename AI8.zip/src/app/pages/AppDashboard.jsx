
import React, { lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

const Dashboard = lazy(() => import('@/pages/Dashboard'));
const Aspirants = lazy(() => import('@/pages/Aspirants'));
const UsersPage = lazy(() => import('@/pages/profile/UsersPage'));
const TypingTest = lazy(() => import('@/pages/TypingTest'));
const ExamDate = lazy(() => import('@/pages/ExamDate'));
const AdmitCard = lazy(() => import('@/pages/AdmitCard'));
const AnswerKey = lazy(() => import('@/pages/AnswerKey'));
const Result = lazy(() => import('@/pages/Result'));
const StoryListPage = lazy(() => import('@/pages/story/StoryListPage')); // Correctly imports StoryListPage
const Friends = lazy(() => import('@/pages/Friends'));
const HtmlViewer = lazy(() => import('@/components/HtmlViewer'));

const AppDashboard = () => {
  return (
    <Routes>

      {/* Default Dashboard */}
      <Route index element={<Dashboard />} />

      {/* Existing Main Routes */}
      <Route path="aspirants" element={<Aspirants />} />
      <Route path="users" element={<UsersPage />} />
      <Route path="typing-test" element={<TypingTest />} />
      <Route path="exam-date" element={<ExamDate />} />
      <Route path="admit-card" element={<AdmitCard />} />
      <Route path="answer-key" element={<AnswerKey />} />
      <Route path="result" element={<Result />} />
      {/* Corrected route for Success Story to point to the StoryListPage */}
      <Route path="success-story" element={<StoryListPage />} />
      <Route path="friends" element={<Friends />} />

      {/* ⭐ STUDY-PAGES Routes (HTML Viewer Pages) */}
      <Route
        path="current-affairs"
        element={<HtmlViewer src="/study-pages/current-affairs.html" title="Current Affairs | Aspirants India" />}
      />

      <Route
        path="notes"
        element={<HtmlViewer src="/study-pages/notes.html" title="Notes | Aspirants India" />}
      />

      <Route
        path="gk-pages"
        element={<HtmlViewer src="/study-pages/gk-pages.html" title="GK Pages | Aspirants India" />}
      />

      <Route
        path="exam-preparation"
        element={<HtmlViewer src="/study-pages/exam-preparation.html" title="Exam Preparation | Aspirants India" />}
      />

      <Route
        path="study-material"
        element={<HtmlViewer src="/study-pages/study-material.html" title="Study Material | Aspirants India" />}
      />

      <Route
        path="quizzes"
        element={<HtmlViewer src="/study-pages/quizzes.html" title="Quizzes | Aspirants India" />}
      />

      <Route
        path="learning"
        element={<HtmlViewer src="/study-pages/learning.html" title="Learning | Aspirants India" />}
      />

      <Route
        path="mcqs"
        element={<HtmlViewer src="/study-pages/mcqs.html" title="MCQs Practice | Aspirants India" />}
      />

      <Route
        path="online-class"
        element={<HtmlViewer src="/study-pages/online-class.html" title="Online Class | Aspirants India" />}
      />

      <Route
        path="online-coaching"
        element={<HtmlViewer src="/study-pages/online-coaching.html" title="Online Coaching | Aspirants India" />}
      />

      <Route
        path="study-games"
        element={<HtmlViewer src="/study-pages/study-games.html" title="Study Games | Aspirants India" />}
      />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/app/dashboard" replace />} />

    </Routes>
  );
};

export default AppDashboard;
