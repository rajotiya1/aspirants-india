import { supabase } from '@/lib/supabase';

const JOBS_PER_PAGE = 15;

export const fetchAspJobs = async ({ searchTerm, page = 0 }) => {
    let query = supabase
        .from('asp_jobs')
        .select('id, job_name, authority', { count: 'exact' })
        .order('created_at', { ascending: false });

    if (searchTerm) {
        const searchString = `%${searchTerm}%`;
        query = query.or(`job_name.ilike.${searchString},authority.ilike.${searchString}`);
    }

    const from = page * JOBS_PER_PAGE;
    const to = from + JOBS_PER_PAGE - 1;
    query = query.range(from, to);

    const { data, error, count } = await query;

    if (error) {
        console.error('Error fetching asp_jobs:', error);
        throw error;
    }

    return { data, count };
};


export const getMyAppliedJobs = async (userId) => {
  const { data, error } = await supabase
    .from('asp_applications')
    .select(`
      id,
      category_id,
      asp_categories(name),
      asp_jobs(job_name, authority)
    `)
    .eq('user_id', userId);

  if (error) throw error;
  return data;
};

export const getMyAppliedJobsWithDetails = async (userId) => {
  if (!userId) return [];

  const { data: applications, error: applicationsError } = await supabase
    .from('asp_applications')
    .select(`
      id,
      job_id,
      category_id,
      asp_categories(id, name, gradient_from, gradient_to),
      asp_jobs!inner(*)
    `)
    .eq('user_id', userId);

  if (applicationsError) {
    console.error("Error fetching applications:", applicationsError);
    throw applicationsError;
  }

  if (!applications || applications.length === 0) return [];
  
  const jobIds = applications.map(app => app.job_id);

  const { data: allCategoryCounts, error: countsError } = await supabase
    .from('vw_job_category_counts')
    .select('*')
    .in('job_id', jobIds);

  if (countsError) {
    console.error("Error fetching category counts:", countsError);
    throw countsError;
  }

  const { data: allJobTotals, error: totalsError } = await supabase
    .from('vw_job_totals')
    .select('*')
    .in('job_id', jobIds);
  
  if (totalsError) {
    console.error("Error fetching job totals:", totalsError);
    throw totalsError;
  }
  
  const countsMap = allCategoryCounts.reduce((acc, curr) => {
    if (!acc[curr.job_id]) acc[curr.job_id] = [];
    acc[curr.job_id].push(curr);
    return acc;
  }, {});

  const totalsMap = allJobTotals.reduce((acc, curr) => {
    acc[curr.job_id] = curr.total_applications;
    return acc;
  }, {});

  return applications.map(app => {
    const jobDetails = {
      last_date: app.asp_jobs.last_date,
      admit_card: app.asp_jobs.admit_card_status,
      exam_date: app.asp_jobs.exam_date_status,
      answer_key: app.asp_jobs.answer_key_status,
      result: app.asp_jobs.result_status,
      final_result: app.asp_jobs.final_result_status,
    };
    
    return {
      ...app,
      category_counts: countsMap[app.job_id] || [],
      total_applications: totalsMap[app.job_id] || 0,
      job_details: jobDetails
    };
  });
};


export const getApprovedJobSurveys = async (searchTerm) => {
  let query = supabase
    .from('job_surveys')
    .select('*')
    .eq('status', 'approved')
    .order('created_at', { ascending: false });

  if (searchTerm) {
    query = query.textSearch('title', searchTerm, { type: 'websearch' });
  }

  const { data, error } = await query;
  if (error) throw error;
  return data;
};

export const getJobSurveyDetails = async (jobSurveyId) => {
  const { data, error } = await supabase
    .from('job_surveys')
    .select(`
      *,
      job_category_counts (
        applicant_count,
        job_survey_categories ( name )
      )
    `)
    .eq('id', jobSurveyId)
    .single();

  if (error) throw error;
  return data;
};

export const getPublicApplicants = async (jobId) => {
  const { data, error } = await supabase.rpc('get_aspirant_public_applicants', { p_job_id: jobId });
  if (error) throw error;
  return data;
};


export const getMyApplicationForSurvey = async (jobSurveyId, userId) => {
  if (!userId) return null;
  const { data, error } = await supabase
    .from('job_applications')
    .select('*')
    .eq('job_survey_id', jobSurveyId)
    .eq('user_id', userId)
    .single();

  if (error && error.code !== 'PGRST116') { // Ignore 'not found' errors
    throw error;
  }
  return data;
};

export const getSurveyCategories = async () => {
  const { data, error } = await supabase
    .from('asp_categories')
    .select('*')
    .order('id');
  if (error) throw error;
  return data;
};

export const submitApplication = async ({ userId, jobSurveyId, categoryId }) => {
  const { data, error } = await supabase
    .from('job_applications')
    .upsert({
      user_id: userId,
      job_survey_id: jobSurveyId,
      category_id: categoryId,
    }, { onConflict: 'user_id, job_survey_id' });

  if (error) throw error;
  return data;
};

export const suggestNewSurvey = async ({ title, authority, userId }) => {
  const { data, error } = await supabase
    .from('job_survey_suggestions')
    .insert({
      title,
      authority,
      user_id: userId,
      status: 'pending'
    });

  if (error) throw error;
  return data;
};

export const submitJobSuggestion = async ({ vacancy_name, vacancy_details, suggester_name, suggester_email, suggester_mobile, userId }) => {
    const { data, error } = await supabase
        .from('asp_job_suggestions')
        .insert({
            vacancy_name,
            vacancy_details,
            suggester_name,
            suggester_email,
            suggester_mobile,
            user_id: userId
        });
    if (error) throw error;
    return data;
};

export const getUpdatesForJob = async (jobSurveyId, categoryId) => {
  const { data, error } = await supabase
    .from('job_updates')
    .select('*')
    .eq('job_survey_id', jobSurveyId)
    .or(`category_id.is.null,category_id.eq.${categoryId}`)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const fetchAspirants = async () => {
    const { data, error } = await supabase
        .from('job_survey_suggestions')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error fetching aspirants:', error);
        throw error;
    }
    return data;
};

export const getAspirantCategoryCounts = async (jobId) => {
  const { data, error } = await supabase.rpc('get_aspirant_category_counts', { p_job_id: jobId });
  if (error) throw error;
  return data;
};

export const submitAspirantApplication = async ({ userId, jobId, categoryId }) => {
  const { data, error } = await supabase
    .from('asp_applications')
    .upsert({
      user_id: userId,
      job_id: jobId,
      category_id: categoryId,
    }, { onConflict: 'user_id, job_id' });

  if (error) throw error;
  return data;
};

export const deleteAspirantApplication = async (applicationId, userId) => {
  const { error } = await supabase.rpc('delete_application_and_decrement_count', {
    p_application_id: applicationId,
    p_user_id: userId
  });

  if (error) throw error;
  return true;
};