import React from 'react';
import { useParams } from "react-router-dom";
import { supabase } from "@/lib/customSupabaseClient";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Helmet } from 'react-helmet-async';

export default function Page() {
  const { slug } = useParams();
  const [page, setPage] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPage = async () => {
      setLoading(true);
      const { data } = await supabase.from("pages").select("*").eq("slug", slug).single();
      setPage(data);
      setLoading(false);
    };
    fetchPage();
  }, [slug]);

  if (loading) {
    return (
      <div className="w-full h-96 flex items-center justify-center bg-background">
        <Loader2 className="animate-spin text-primary h-12 w-12" />
      </div>
    );
  }

  if (!page) {
    return <div className="p-8 text-center text-lg font-semibold">Page not found.</div>;
  }

  return (
    <>
      <Helmet>
        <title>{`${page.title} - Aspirants India`}</title>
        <meta name="description" content={`Learn more about ${page.title} at Aspirants India.`} />
      </Helmet>
      <div className="bg-background text-foreground container mx-auto p-4 sm:p-6 lg:p-8">
        <article className="prose dark:prose-invert lg:prose-xl max-w-4xl mx-auto">
          <h1 className="text-3xl sm:text-4xl font-bold mb-4 border-b pb-2">{page.title}</h1>
          <div dangerouslySetInnerHTML={{ __html: page.content }} />
        </article>
      </div>
    </>
  );
}