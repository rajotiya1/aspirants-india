
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { formatDate, normalizeUrl } from '@/lib/utils';
import SEO from '@/components/SEO';
import { Check, Loader2, Download, Link as LinkIcon } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';

const JobRow = ({ job, onAdd, isAdded, onToggleDetail, openDetailId }) => {
  const isOpen = openDetailId === job.id;

  const handleShowInterstitialAd = (e) => {
    e.stopPropagation();
    if (window.Android && typeof window.Android.showInterstitialAd === 'function') {
        window.Android.showInterstitialAd();
    }
    onToggleDetail(job.id);
  }

  return (
    <>
      <TableRow className="border-b border-border hover:bg-muted/50 cursor-pointer font-bold" onClick={handleShowInterstitialAd}>
        <TableCell className="font-bold">{job.name_of_post}</TableCell>
        <TableCell>{job.qualification}</TableCell>
        <TableCell>{formatDate(job.last_date)}</TableCell>
      </TableRow>
      <AnimatePresence>
        {isOpen && (
          <motion.tr
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-muted/30"
          >
            <TableCell colSpan={3} className="p-4 font-normal">
              <div className="space-y-3 text-black">
                <p><strong className="text-foreground">Details:</strong> {job.detail}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 text-sm">
                    <div><strong className="text-foreground">Authority:</strong> {job.authority || 'N/A'}</div>
                    <div><strong className="text-foreground">No. of Posts:</strong> {job.no_of_post || 'N/A'}</div>
                    <div><strong className="text-foreground">Pay Scale:</strong> {job.pay_scale || 'N/A'}</div>
                    <div><strong className="text-foreground">State:</strong> {job.state || 'N/A'}</div>
                    <div><strong className="text-foreground">Fee:</strong> {job.fee || 'N/A'}</div>
                    <div><strong className="text-foreground">How to Apply:</strong> {job.how_to_apply || 'N/A'}</div>
                </div>
                <div className="flex gap-4 items-center mt-4 pt-3 border-t">
                    {job.direct_link && 
                        <Button variant="link" size="sm" asChild className="text-blue-500 hover:text-blue-600 p-0 h-auto">
                           <a href={job.direct_link} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
                            <LinkIcon className="h-4 w-4"/> View Official Link
                           </a>
                        </Button>
                    }
                    {job.pdf_url && (
                        <Button variant="link" size="sm" asChild className="text-green-500 hover:text-green-600 p-0 h-auto">
                            {/* UPDATED: Use direct href with target="_blank" */}
                            <a href={normalizeUrl(job.pdf_url)} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1">
                                <Download className="h-4 w-4"/> Download PDF
                            </a>
                        </Button>
                    )}
                     <div className="flex-grow text-right">
                        {isAdded ? (
                            <Button size="sm" variant="outline" className="border-green-500 text-green-500" disabled>
                            <Check className="w-4 h-4 mr-1" /> Added
                            </Button>
                        ) : (
                            <Button size="sm" onClick={(e) => { e.stopPropagation(); onAdd(job); }} className="bg-wavy-navy hover:bg-wavy-navy/90 text-white">
                            Add
                            </Button>
                        )}
                    </div>
                </div>
              </div>
            </TableCell>
          </motion.tr>
        )}
      </AnimatePresence>
    </>
  );
};

const JobDetails = () => {
  const { categorySlug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [allJobs, setAllJobs] = useState([]);
  const [category, setCategory] = useState(null);
  const [userJobIds, setUserJobIds] = useState(new Set());
  const [openDetailId, setOpenDetailId] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    
    let categoryQuery = supabase.from('job_categories').select('id, name, slug').eq('slug', categorySlug).single();
    const { data: categoryData, error: categoryError } = await categoryQuery;

    if (categoryError || !categoryData) {
      toast({ title: "Error", description: "Job category not found.", variant: "destructive" });
      setLoading(false);
      navigate('/jobs');
      return;
    }
    setCategory(categoryData);

    let jobsQuery = supabase.from('jobs').select('*');
    if (categoryData.slug !== 'all-jobs') {
        jobsQuery = jobsQuery.eq('category_id', categoryData.id);
    }
    
    jobsQuery = jobsQuery.order('date_of_post', { ascending: false });

    const { data: jobsData, error: jobsError } = await jobsQuery;
    
    if (jobsError) {
      toast({ title: "Error fetching jobs", description: jobsError.message, variant: "destructive" });
    } else {
      setAllJobs(jobsData);
    }

    if (user) {
      const { data: savedJobsData, error: savedJobsError } = await supabase.from('user_saved_jobs').select('job_id').eq('user_id', user.id);
      if (!savedJobsError) {
        setUserJobIds(new Set(savedJobsData.map(j => j.job_id)));
      }
    }
    setLoading(false);
  }, [categorySlug, user, toast, navigate]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleAddToProfile = async (job) => {
    const { error } = await supabase.from('user_saved_jobs').insert({ user_id: user.id, job_id: job.id });
    if (error) {
      toast({ title: "Error saving job", description: error.message, variant: "destructive" });
    } else {
      setUserJobIds(new Set([...userJobIds, job.id]));
      toast({ title: "Success!", description: `${job.name_of_post} added to your saved jobs.` });
    }
  };

  const handleToggleDetail = (jobId) => setOpenDetailId(prevId => (prevId === jobId ? null : jobId));

  const groupedAndSortedJobs = useMemo(() => {
    const grouped = allJobs.reduce((acc, job) => {
      const postDate = formatDate(job.date_of_post);
      if (!postDate) return acc;
      if (!acc[postDate]) acc[postDate] = [];
      acc[postDate].push(job);
      return acc;
    }, {});

    return Object.keys(grouped).sort((a, b) => new Date(b.split('/').reverse().join('-')) - new Date(a.split('/').reverse().join('-')));
  }, [allJobs]);

  const renderJobTableHeader = () => (
    <TableRow className="border-b-0 hover:bg-transparent">
      <TableHead>Name of Post</TableHead>
      <TableHead>Qualification</TableHead>
      <TableHead>Last Date</TableHead>
    </TableRow>
  );

  return (
    <>
      <SEO 
        title={`${category ? category.name : 'Jobs'}`}
        description={`Find the latest government job openings for ${category ? category.name : 'various categories'}.`}
        keywords={`government jobs, sarkari naukri, ${category?.name}, job details`}
      />
      <div className="space-y-6">
        {loading ? (
            <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin" /></div>
        ) : groupedAndSortedJobs.length > 0 ? (
            groupedAndSortedJobs.map(date => (
                <div key={date} className="border rounded-lg overflow-hidden">
                    <h2 className="font-bold text-wavy-navy text-lg tracking-wider text-center bg-gray-200 py-2 px-4">{date}</h2>
                    <Table>
                        <TableHeader>{renderJobTableHeader()}</TableHeader>
                        <TableBody>
                            {allJobs.filter(j => formatDate(j.date_of_post) === date).map(job => (
                                <JobRow key={job.id} job={job} onAdd={handleAddToProfile} isAdded={userJobIds.has(job.id)} onToggleDetail={handleToggleDetail} openDetailId={openDetailId} />
                            ))}
                        </TableBody>
                    </Table>
                </div>
            ))
        ) : (
            <Card>
                <CardContent className="p-0">
                    <div className="text-center text-muted-foreground py-8">No jobs found in this category.</div>
                </CardContent>
            </Card>
        )}
      </div>
    </>
  );
};

export default JobDetails;
