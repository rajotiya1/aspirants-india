import React, { useEffect, useState, useCallback } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Briefcase, FileText, Type, Award, Key, CalendarDays, BookHeart, 
  Users, UserCheck, UserSquare, FolderKanban, Bookmark, ClipboardCheck, Puzzle, Building, Globe, FileCode2, Calculator, FileStack
} from 'lucide-react';
import SEO from '@/components/SEO';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useBadges } from '@/contexts/BadgeContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Loader2 } from 'lucide-react';

const themeStyles = {
  blue: { icon: 'text-blue-600', bg: 'bg-blue-100' },
  green: { icon: 'text-emerald-600', bg: 'bg-emerald-100' },
  purple: { icon: 'text-purple-600', bg: 'bg-purple-100' },
  amber: { icon: 'text-amber-600', bg: 'bg-amber-100' },
  red: { icon: 'text-red-600', bg: 'bg-red-100' },
  indigo: { icon: 'text-indigo-600', bg: 'bg-indigo-100' },
  pink: { icon: 'text-pink-600', bg: 'bg-pink-100' },
  teal: { icon: 'text-teal-600', bg: 'bg-teal-100' },
  cyan: { icon: 'text-cyan-600', bg: 'bg-cyan-100' },
  fuchsia: { icon: 'text-fuchsia-600', bg: 'bg-fuchsia-100' },
  orange: { icon: 'text-orange-600', bg: 'bg-orange-100' },
  lime: { icon: 'text-lime-600', bg: 'bg-lime-100' },
  sky: { icon: 'text-sky-600', bg: 'bg-sky-100' },
  rose: { icon: 'text-rose-600', bg: 'bg-rose-100' },
  slate: { icon: 'text-slate-600', bg: 'bg-slate-100' },
};

const DashboardButton = ({ to, text, icon: Icon, theme = 'blue', badgeKey, customBadgeState }) => {
  const { badgeState } = useBadges();
  const showBadge = badgeState[badgeKey] || customBadgeState;
  const currentTheme = themeStyles[theme] || themeStyles.blue;
  
  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -4 }}
      whileTap={{ scale: 0.97 }}
      className="relative transition-all duration-200 ease-in-out"
    >
      <NavLink
        to={to}
        aria-label={text}
        className={cn(
          "flex flex-col items-center justify-center p-2 text-center h-full",
          "bg-card rounded-2xl border",
          "shadow-md hover:shadow-lg hover:border-primary/50 transition-all duration-200",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
        )}
      >
        <div className={cn("w-12 h-12 rounded-full flex items-center justify-center mb-2 transition-colors", currentTheme.bg)}>
          <Icon className={cn("w-6 h-6", currentTheme.icon)} />
        </div>
        <span className="font-semibold text-foreground leading-tight text-xs sm:text-sm whitespace-nowrap">
          {text}
        </span>
        {showBadge && (
            <Badge variant="destructive" className="absolute -top-2 -right-2">NEW</Badge>
        )}
      </NavLink>
    </motion.div>
  );
};

const Dashboard = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { checkAllUpdates } = useBadges();
  const location = useLocation();
  const [hasNewPvtJobs, setHasNewPvtJobs] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [authLoading, user, navigate]);

  const cardData = [
    { to: '/app/jobs/govt', text: 'All Jobs', icon: Briefcase, theme: 'blue', badgeKey: 'jobs' },
    { to: `/app/profile/saved-jobs/${user?.id}`, text: 'Saved Jobs', icon: Bookmark, theme: 'indigo', badgeKey: 'saved_jobs' },
    { to: `/app/profile/applied-jobs/${user?.id}`, text: 'Applied Jobs', icon: ClipboardCheck, theme: 'purple', badgeKey: 'applied_jobs' },
    { to: '/app/exam-resources', text: 'PDF Jungle', icon: FileStack, theme: 'slate' },
    { to: '/app/dashboard/aspirants', text: 'Nos. of Candidates', icon: UserCheck, theme: 'sky' },
    { to: '/app/study/online-test', text: 'Online Tests', icon: FileText, theme: 'green' },
    { to: '/app/exams/exam-date', text: 'Exam Date', icon: CalendarDays, theme: 'cyan', badgeKey: 'exam-date' },
    { to: '/app/exams/admit-card', text: 'Admit Card', icon: FolderKanban, theme: 'red', badgeKey: 'admit-card' },
    { to: '/app/exams/answer-key', text: 'Answer Key', icon: Key, theme: 'teal', badgeKey: 'answer-key' },
    { to: '/app/exams/result', text: 'Result', icon: Award, theme: 'amber', badgeKey: 'result' },
    { to: '/app/dashboard/users', text: 'Users', icon: UserSquare, theme: 'lime' },
    { to: `/app/profile/friends/${user?.id}`, text: 'Friends', icon: Users, theme: 'orange', badgeKey: 'friends' },
    { to: '/app/study/exam-preparation', text: 'Age Calculator', icon: Globe, theme: 'teal', badgeKey: 'exam_preparation' }, 
    { to: '/resume-builder', text: 'Resume Maker', icon: FileCode2, theme: 'purple' },
    { to: '/salary-calculator', text: 'Salary Calculator', icon: Calculator, theme: 'emerald' },
  ];

  const checkNewPvtJobs = useCallback(async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const { data, error } = await supabase
      .from('private_jobs')
      .select('id')
      .gte('created_at', today.toISOString());

    if (error) {
      console.error('Error checking for new private jobs:', error);
      return;
    }

    if (data && data.length > 0) {
      setHasNewPvtJobs(true);
    }
  }, []);

  useEffect(() => {
    if (user) {
      checkAllUpdates();
      checkNewPvtJobs();
    }
  }, [location, checkAllUpdates, checkNewPvtJobs, user]);

  if (authLoading) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="h-10 w-10 animate-spin text-primary" /></div>;
  }
  
  if (!user) {
    return null; // Redirect is handled by the effect
  }

  return (
    <>
      <SEO
        title="Dashboard - Your Gateway to Government Jobs"
        description="Access all features from the dashboard: find jobs, take online tests, practice typing, check results, download admit cards, and more."
        ogTitle="Dashboard | ASPIRANTS INDIA"
        ogDescription="Your central hub for government job preparation. Navigate to jobs, tests, results, and other essential resources."
      />
      <div className="p-4 overflow-y-auto h-full pb-20">
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-4">
          {cardData.map((card, index) => (
            <DashboardButton 
              key={index} 
              {...card} 
              customBadgeState={card.badgeKey === 'pvt_jobs' ? hasNewPvtJobs : undefined}
            />
          ))}
        </div>

      </div>
    </>
  );
};

export default Dashboard;