import React, { useState } from "react";
import { supabase } from "@/lib/supabase"; // Corrected import
import { Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { getFriendlyErrorMessage } from "@/lib/errorUtils";

export default function LoginPage() {
  const { toast } = useToast();
  const { signIn } = useAuth();

  const [mode, setMode] = useState("login"); // login | signup | forgot
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);

  const handleApiCall = async (action, purpose, body) => {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("otp-service", {
      body: { action, purpose, ...body },
    });
    setLoading(false);
    return { data, error };
  };

  const handleLogin = async () => {
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);

    if (!error) {
      toast({ title: "Success", description: "Login successful ✅" });
      setTimeout(() => {
        window.location.href = "/app/dashboard";
      }, 600);
    }
  };

  const handleSignup = async () => {
    const { error } = await handleApiCall("send-otp", "signup_verify", { email });
    if (error) {
      toast({ title: "Error", description: getFriendlyErrorMessage(error), variant: "destructive" });
    } else {
      setOtpSent(true);
      toast({ title: "OTP Sent", description: "Check your email for the verification code." });
    }
  };

  const handleVerifyOtpAndSignup = async () => {
    const { data, error } = await handleApiCall("verify-otp", "signup_verify", { email, otp: Number(otp) });
    if (error || !data?.ok) {
      toast({
        title: "Verification Failed",
        description: getFriendlyErrorMessage(data?.error || "Invalid or expired OTP."),
        variant: "destructive",
      });
      return;
    }

    toast({ title: "Verified", description: "Your account has been verified 🎉 Creating account..." });

    setLoading(true);
    const { error: signUpError } = await supabase.auth.signUp({ email, password });
    setLoading(false);

    if (signUpError) {
      toast({ title: "Signup Failed", description: getFriendlyErrorMessage(signUpError), variant: "destructive" });
    } else {
      toast({ title: "Account Created", description: "Please login with your new credentials." });
      setMode("login");
      setOtpSent(false);
      setOtp("");
    }
  };

  const handleForgotPassword = async () => {
    const { error } = await handleApiCall("send-otp", "forgot_password", { email });
    if (error) {
      toast({ title: "Error", description: getFriendlyErrorMessage(error), variant: "destructive" });
    } else {
      setOtpSent(true);
      toast({ title: "OTP Sent", description: "Check your email to reset password." });
    }
  };

  const handleResetPassword = async () => {
    const { data, error } = await handleApiCall("verify-otp", "forgot_password", {
      email,
      otp: Number(otp),
      newPassword: password,
    });

    if (error || !data?.ok) {
      toast({
        title: "Failed",
        description: getFriendlyErrorMessage(data?.error || "Password reset failed."),
        variant: "destructive",
      });
      return;
    }

    toast({ title: "Password Reset", description: "You can now login with your new password." });
    setMode("login");
    setOtpSent(false);
    setOtp("");
    setPassword("");
  };

  const renderContent = () => {
    if (mode === "login") {
      return (
        <>
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <Button onClick={handleLogin} disabled={loading} className="w-full">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Login
          </Button>
          <p className="text-sm text-center">
            New user?{" "}
            <span
              onClick={() => {
                setMode("signup");
                setOtpSent(false);
              }}
              className="text-blue-600 cursor-pointer"
            >
              Create account
            </span>
          </p>
          <p className="text-sm text-center">
            <span
              onClick={() => {
                setMode("forgot");
                setOtpSent(false);
              }}
              className="text-blue-600 cursor-pointer"
            >
              Forgot Password?
            </span>
          </p>
        </>
      );
    }

    if (mode === "signup") {
      return (
        <>
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={otpSent}
          />
          <Input
            type="password"
            placeholder="Create a password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={otpSent}
          />
          {otpSent ? (
            <>
              <Input
                type="text"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
              <Button onClick={handleVerifyOtpAndSignup} disabled={loading} className="w-full">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Verify & Create Account
              </Button>
            </>
          ) : (
            <Button onClick={handleSignup} disabled={loading} className="w-full">
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send OTP
            </Button>
          )}
          <p className="text-sm text-center">
            Already have an account?{" "}
            <span onClick={() => setMode("login")} className="text-blue-600 cursor-pointer">
              Login
            </span>
          </p>
        </>
      );
    }

    if (mode === "forgot") {
      return (
        <>
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={otpSent}
          />
          {otpSent ? (
            <>
              <Input
                type="text"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
              <Input
                type="password"
                placeholder="Enter new password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <Button onClick={handleResetPassword} disabled={loading} className="w-full">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Verify & Reset Password
              </Button>
            </>
          ) : (
            <Button onClick={handleForgotPassword} disabled={loading} className="w-full">
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Send OTP
            </Button>
          )}
          <p className="text-sm text-center">
            Remembered your password?{" "}
            <span onClick={() => setMode("login")} className="text-blue-600 cursor-pointer">
              Login
            </span>
          </p>
        </>
      );
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader>
          <CardTitle className="text-center text-xl font-bold">
            {mode === "login" && "Login"}
            {mode === "signup" && "Create Account"}
            {mode === "forgot" && "Forgot Password"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">{renderContent()}</CardContent>
      </Card>
    </div>
  );
}