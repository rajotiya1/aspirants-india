
import React from 'react';
import OnlineTests from '@/pages/OnlineTests';

const SpecialBatch2 = () => {
  // This array is temporary. Actual categories will be fetched or defined here.
  const batchCategories = [];

  return <OnlineTests />;
};

export default SpecialBatch2;
