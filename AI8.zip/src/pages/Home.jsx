import React from 'react';
import Login from './Login';

const Home = () => {
    // This component is now just a wrapper for the Login component for unauthenticated users.
    // All authenticated users are redirected to /dashboard from App.jsx
    return <Login />;
};

export default Home;