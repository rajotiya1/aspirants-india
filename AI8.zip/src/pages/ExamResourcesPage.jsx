import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Loader2, AlertCircle, FileStack } from 'lucide-react';
import CategorySection from '@/components/exam-resources/CategorySection';
import SEO from '@/components/SEO';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const ExamResourcesPage = () => {
  const [resourceData, setResourceData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchResources = async () => {
      try {
        setLoading(true);

        const { data, error: fetchError } = await supabase
          .from('exam_resources')
          .select('*')
          .order('created_at', { ascending: false });

        if (fetchError) throw fetchError;

        const groupedData = (data || []).reduce((acc, item) => {
          const { category, exam_name } = item;

          const catKey = category || 'Other';
          const examKey = exam_name || 'General Resources';

          if (!acc[catKey]) acc[catKey] = {};
          if (!acc[catKey][examKey]) acc[catKey][examKey] = [];

          acc[catKey][examKey].push(item);
          return acc;
        }, {});

        setResourceData(groupedData);
      } catch (err) {
        console.error("Error fetching exam resources:", err);
        setError(err.message || 'Failed to load resources. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchResources();
  }, []);

  const sortedCategories = Object.keys(resourceData).sort();

  return (
    <>
      <SEO 
        title="PDF Jungle - Exam Resources & Study Material" 
        description="Download PDF notes, previous year papers, and study materials for SSC, UPSC, Banking, and other exams."
      />

      <div className="min-h-screen bg-gradient-to-b from-[#fdfdfd] to-[#f4f4f8] pb-20">

        {/* HEADER */}
        <div className="bg-white shadow-sm border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 py-6 flex items-center gap-3">
            <div className="p-3 bg-[#D70000] rounded-xl shadow-md">
              <FileStack className="w-8 h-8 text-white" />
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">
                PDF Jungle
              </h1>
              <p className="text-slate-500 text-sm">
                Premium study resources & previous year papers
              </p>
            </div>
          </div>
        </div>

        {/* BODY */}
        <div className="max-w-5xl mx-auto px-4 sm:px-6 mt-6">

          {loading ? (
            <div className="flex flex-col items-center justify-center h-[50vh] gap-4">
              <Loader2 className="w-12 h-12 text-[#D70000] animate-spin" />
              <p className="text-slate-500 font-medium animate-pulse">
                Loading resources...
              </p>
            </div>
          ) : error ? (
            <Alert className="bg-white max-w-lg mx-auto border-red-400 shadow-md">
              <AlertCircle className="h-5 w-5 text-red-500" />
              <AlertTitle>Error loading data</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : sortedCategories.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-xl border shadow-sm mt-8">
              <FileStack className="mx-auto w-10 h-10 text-slate-300 mb-3" />
              <h3 className="text-lg font-semibold text-slate-700">
                No Resources Yet
              </h3>
              <p className="text-slate-500 text-sm">
                Check back later for new updates.
              </p>
            </div>
          ) : (
            <div className="grid gap-5">
              {sortedCategories.map(category => (
                <div key={category} className="bg-white rounded-xl border shadow-sm p-5">
                  <h2 className="text-lg font-bold text-slate-800 mb-3 border-l-4 border-[#D70000] pl-2">
                    {category}
                  </h2>

                  <div className="space-y-2">
                    <CategorySection 
                      categoryName={category} 
                      examsData={resourceData[category]} 
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

        </div>
      </div>
    </>
  );
};

export default ExamResourcesPage;
