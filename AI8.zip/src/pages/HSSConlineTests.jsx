
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { format, subDays } from 'date-fns';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, PlayCircle, BarChart2 } from 'lucide-react';
import SEO from '@/components/SEO';
import TestRunner from '@/components/online-tests/TestRunner';
import TestResults from '@/components/online-tests/TestResults';
import LeaderboardDialog from '@/components/online-tests/LeaderboardDialog';

const hsscCategories = [
  { name: 'Haryana G.K.', tableName: 'hssc_gk_test', shortName: 'HSSC-GK' },
  { name: 'Hindi', tableName: 'hssc_hindi_test', shortName: 'HSSC-Hindi' },
  { name: 'G.K. + Computer', tableName: 'hssc_gk_computer_test', shortName: 'HSSC-GKComp' },
  { name: 'English', tableName: 'hssc_english_test', shortName: 'HSSC-English' },
  { name: 'Reasoning', tableName: 'hssc_reasoning_test', shortName: 'HSSC-Reasoning' },
  { name: 'Maths', tableName: 'hssc_maths_test', shortName: 'HSSC-Maths' },
];

const dates = {
  today: format(new Date(), 'yyyy-MM-dd'),
  yesterday: format(subDays(new Date(), 1), 'yyyy-MM-dd'),
  dayBefore: format(subDays(new Date(), 2), 'yyyy-MM-dd'),
};

const STORAGE_KEY = 'hssc_test_active_session';

const HSSConlineTests = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [view, setView] = useState('list');
  const [loading, setLoading] = useState(false);
  const [testData, setTestData] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboardContext, setLeaderboardContext] = useState(null);
  const [restoredAnswers, setRestoredAnswers] = useState({});

  useEffect(() => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed && parsed.testData && parsed.view === 'test') {
          setTestData(parsed.testData);
          setRestoredAnswers(parsed.answers || {});
          setView('test');
          toast({
            title: "Test Resumed",
            description: "We've restored your progress.",
          });
        }
      } catch (e) {
        console.error("Failed to restore session", e);
        sessionStorage.removeItem(STORAGE_KEY);
      }
    }
  }, [toast]);

  const startTest = async (category, date) => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed.testData && (parsed.testData.category.shortName !== category.shortName || parsed.testData.date !== date)) {
          if (!window.confirm("Starting a new test will discard progress from your current one. Continue?")) {
            return;
          }
        }
      } catch (e) {}
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from(category.tableName)
        .select('*')
        .eq('date', date);

      if (error || !data || data.length === 0) {
        toast({
          title: "Test Not Available",
          description: `No questions found for ${category.name} on this date.`,
          variant: "destructive",
        });
        setLoading(false);
        return;
      }
      
      const newTestData = { questions: data, category, date };
      setTestData(newTestData);
      setRestoredAnswers({});
      setView('test');

      sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
        view: 'test',
        testData: newTestData,
        answers: {}
      }));

    } catch (err) {
      toast({ title: "Error", description: "Could not load the test.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };
  
  const handleAnswerUpdate = (currentAnswers) => {
    if (!testData) return;
    const sessionPayload = {
      view: 'test',
      testData: testData,
      answers: currentAnswers
    };
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(sessionPayload));
  };

  const handleQuitTest = () => {
    if (window.confirm("Are you sure you want to quit? Your progress will be discarded.")) {
      sessionStorage.removeItem(STORAGE_KEY);
      setView('list');
      setTestData(null);
      setRestoredAnswers({});
    }
  };

  const handleSubmitTest = async (submission) => {
    const { answers, questions } = submission;
    setLoading(true);

    const normalizedQuestions = questions.map((q) => {
      if (q.correct_option) {
        return { id: q.id, correct_option: q.correct_option };
      }
      const adv = q.correct_answer_text || q.correct_answer_html || q.correct_answer_image_url || null;
      return { id: q.id, correct_option: adv };
    });

    try {
      const { data, error } = await supabase.functions.invoke('submit-test-and-get-rank', {
        body: {
          user_id: user.id,
          category: testData.category.shortName,
          date: testData.date,
          answers,
          questions: normalizedQuestions,
        },
      });

      if (error) throw new Error(error.message);
      if (!data || !data.result) throw new Error("Invalid response from server");

      toast({ title: "Success!", description: "Your test has been submitted and ranked." });

      sessionStorage.removeItem(STORAGE_KEY);
      setTestResult({
        result: data.result,
        questions: questions,
        answers: answers,
      });
      setView('results');
    } catch (err) {
      toast({ title: "Submission Failed", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleShowRank = (category, date) => {
    setLeaderboardContext({ category: category.shortName, date });
    setShowLeaderboard(true);
  };

  const renderListView = () => (
    <div className="space-y-6">
      <SEO
        title="HSSC Online Tests"
        description="Daily HSSC Haryana GK, Hindi, GK+Computer, English, Reasoning and Maths online tests with leaderboard and rank."
        keywords="hssc online test, haryana gk test, hssc reasoning test, hssc maths test, haryana govt exam"
      />
      <h1 className="text-xl font-bold text-blue-600">HSSC Online Test</h1>
      {loading && <div className="flex justify-center"><Loader2 className="animate-spin" /></div>}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {hsscCategories.map((category) => (
          <Card key={category.tableName} className="bg-white border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-blue-600">{category.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(dates).map(([key, date]) => (
                <div key={date} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                  <span className="font-semibold text-gray-700">  {format(new Date(date + 'T00:00:00'), 'dd MMM yyyy')}</span>

                  <div className="flex items-center gap-2">
                    <Button size="sm" onClick={() => startTest(category, date)} className="bg-blue-500 hover:bg-blue-600">
                      <PlayCircle className="w-4 h-4 mr-1" /> Start
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleShowRank(category, date)}>
                      <BarChart2 className="w-4 h-4 mr-1" /> Rank
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
      {showLeaderboard && leaderboardContext && (
        <LeaderboardDialog
          open={showLeaderboard}
          onOpenChange={setShowLeaderboard}
          category={leaderboardContext.category}
          date={leaderboardContext.date}
          currentUserId={user.id}
        />
      )}
    </div>
  );

  const renderTestView = () => (
    <TestRunner
      testData={testData}
      initialAnswers={restoredAnswers}
      onAnswerUpdate={handleAnswerUpdate}
      onSubmit={handleSubmitTest}
      onBack={handleQuitTest}
    />
  );

  const renderResultsView = () => (
    <TestResults
      resultData={testResult}
      onBack={() => setView('list')}
    />
  );

  return (
    <div className="p-4">
      {view === 'list' && renderListView()}
      {view === 'test' && renderTestView()}
      {view === 'results' && renderResultsView()}
    </div>
  );
};

export default HSSConlineTests;
