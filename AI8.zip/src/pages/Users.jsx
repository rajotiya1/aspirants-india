import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Loader2, Search, MapPin, UserPlus } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

const UserCard = ({ profile, onAddFriend, friendshipStatus }) => {
  const isFriend = friendshipStatus === 'accepted';
  const isPending = friendshipStatus === 'pending';
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="relative p-4 rounded-2xl overflow-hidden transition-all duration-300 ease-in-out group bg-white border border-gray-200"
    >
      <div className="flex items-center space-x-4">
        <Link to={`/app/profile/summary/${profile.id}`} className="flex-grow flex items-center space-x-4">
            <div className="flex-grow">
              <h3 className="font-bold text-lg text-blue-600 truncate">{profile.name || 'Unnamed User'}</h3>
              <div className="flex items-center text-sm text-gray-500 mt-1">
                <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                <span className="truncate">{profile.district || profile.city || 'N/A'}, {profile.state || 'N/A'}</span>
              </div>
            </div>
        </Link>
        <Button 
          variant={isFriend || isPending ? "outline" : "default"}
          size="sm" 
          onClick={() => onAddFriend(profile.id)}
          disabled={isFriend || isPending}
          className={`${isFriend || isPending ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
        >
          {isFriend ? 'Friend' : isPending ? 'Pending' : <><UserPlus className="w-4 h-4 mr-2"/> Add</>}
        </Button>
      </div>
    </motion.div>
  );
};


const Users = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [friendships, setFriendships] = useState({});

  const fetchUsers = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    
    try {
      let query = supabase
        .from('profiles')
        .select('id, name, district, city, state')
        .neq('id', user.id)
        .limit(50);
      
      if (searchTerm.trim()) {
        query = query.or(`name.ilike.%${searchTerm}%,city.ilike.%${searchTerm}%,state.ilike.%${searchTerm}%,district.ilike.%${searchTerm}%`);
      }
      
      const { data, error } = await query;

      if (error) {
        console.error('Error fetching users:', error);
        toast({ title: 'Error fetching users', description: error.message, variant: 'destructive' });
        setUsers([]);
      } else {
        setUsers(data || []);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      toast({ title: 'Error', description: 'An unexpected error occurred', variant: 'destructive' });
    }
    
    setLoading(false);
  }, [user, searchTerm, toast]);

  const fetchFriendships = useCallback(async () => {
    if(!user) return;
    const { data, error } = await supabase
      .from('friendships')
      .select('*')
      .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`);
    
    if (error) return;
    
    const statusMap = {};
    data.forEach(f => {
        const otherUserId = f.requester_id === user.id ? f.addressee_id : f.requester_id;
        statusMap[otherUserId] = f.status;
    });
    setFriendships(statusMap);
  }, [user]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      fetchUsers();
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm, fetchUsers]);

  useEffect(() => {
    fetchFriendships();
  }, [fetchFriendships]);


  const handleAddFriend = async (addresseeId) => {
    const { error } = await supabase
      .from('friendships')
      .insert({ requester_id: user.id, addressee_id: addresseeId, status: 'pending' });

    if (error) {
      toast({ title: 'Error sending request', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Friend request sent!' });
      fetchFriendships();
    }
  };

  if (!user) {
    return (
      <div className="flex justify-center items-center py-20">
        <p className="text-gray-400">Please log in to search for users.</p>
      </div>
    );
  }

  return (
    <>
      <SEO title="Find Users" description="Connect with other users on ASPIRANTS INDIA." />
      <div className="p-4 bg-gray-50 min-h-full">
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative mb-6"
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search by name, district, or state..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-full bg-white border-gray-300 text-gray-800 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </motion.div>

          {loading ? (
            <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
          ) : (
            <div className="space-y-3">
              {users.length > 0 ? users.map(profile => (
                <UserCard key={profile.id} profile={profile} onAddFriend={handleAddFriend} friendshipStatus={friendships[profile.id]} />
              )) : (
                <motion.p 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center text-gray-500 py-10"
                >
                  {searchTerm ? 'No users found matching your search.' : 'No users found.'}
                </motion.p>
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Users;