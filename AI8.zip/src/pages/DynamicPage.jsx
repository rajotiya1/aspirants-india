import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import SEO from '@/components/SEO';

const DynamicPage = () => {
  const { slug } = useParams();
  const [page, setPage] = useState(null);
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchPageData = async () => {
      setLoading(true);
      setError(null);

      try {
        // Step 1: Page info fetch karo
        const { data: pageData, error: pageError } = await supabase
          .from('pages')
          .select('id, title, content')
          .eq('slug', slug)
          .single();

        if (pageError) throw pageError;
        setPage(pageData);

        // Step 2: Agar page_sections me data ho to fetch karo
        const { data: sectionData, error: sectionError } = await supabase
          .from('page_sections')
          .select('id, section_title, section_body, position')
          .eq('page_id', pageData.id)
          .order('position', { ascending: true });

        if (sectionError) throw sectionError;
        setSections(sectionData || []);
      } catch (err) {
        console.error('Error fetching page:', err);
        setError('Could not load the page content.');
      } finally {
        setLoading(false);
      }
    };

    if (slug) {
      fetchPageData();
    }
  }, [slug]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Loader2 className="w-12 h-12 animate-spin text-blue-400" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20 text-red-400">
        <h1 className="text-2xl font-bold">Error</h1>
        <p>{error}</p>
      </div>
    );
  }

  if (!page) {
    return (
      <div className="text-center py-20 text-slate-400">
        <h1 className="text-2xl font-bold">Page Not Found</h1>
        <p>The page you are looking for does not exist.</p>
      </div>
    );
  }

  return (
    <>
      <SEO title={page.title} description={`Information about ${page.title}`} />
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-white">
            {page.title}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-white">
          {sections.length > 0 ? (
            sections.map((section) => (
              <div key={section.id} className="space-y-2">
                <h2 className="text-xl font-semibold">{section.section_title}</h2>
                <p className="whitespace-pre-line">{section.section_body}</p>
              </div>
            ))
          ) : (
            <div
              className="prose prose-invert max-w-none text-white"
              dangerouslySetInnerHTML={{ __html: page.content }}
            />
          )}
        </CardContent>
      </Card>
    </>
  );
};

export default DynamicPage;