import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabase";
import {
  Keyboard,
  Timer,
  Target,
  Percent,
  Play,
  RotateCcw,
  Trophy,
  Loader2,
} from "lucide-react";
import SEO from "@/components/SEO";

const timeOptions = [1, 2, 5, 10, 15, 20, 25, 30];
const speedOptions = [20, 25, 30, 35, 40, 45, 50, 60];

const TypingTest = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [testState, setTestState] = useState("setup");
  const [customText, setCustomText] = useState(
    "The quick brown fox jumps over the lazy dog. A journey of a thousand miles begins with a single step. Be the change that you wish to see in the world."
  );
  const [timeLimit, setTimeLimit] = useState("1");
  const [speedTarget, setSpeedTarget] = useState("40");
  const [timeLeft, setTimeLeft] = useState(0);
  const [userInput, setUserInput] = useState("");
  const [wpm, setWpm] = useState(0);
  const [accuracy, setAccuracy] = useState(100);
  const [leaderboard, setLeaderboard] = useState([]);
  const [loadingLeaderboard, setLoadingLeaderboard] = useState(true);
  const timerRef = useRef(null);
  const inputRef = useRef(null);

  // Leaderboard Fetch
  const fetchLeaderboard = useCallback(async () => {
    setLoadingLeaderboard(true);
    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0)).toISOString();
    const endOfDay = new Date(today.setHours(23, 59, 59, 999)).toISOString();

    const { data, error } = await supabase
      .from("typing_test_leaderboard")
      .select("*, profiles(name, city, state)")
      .gte("created_at", startOfDay)
      .lte("created_at", endOfDay)
      .order("wpm", { ascending: false })
      .order("accuracy", { ascending: false })
      .limit(10);

    if (error)
      toast({
        title: "Error fetching leaderboard",
        description: error.message,
        variant: "destructive",
      });
    else setLeaderboard(data);

    setLoadingLeaderboard(false);
  }, [toast]);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  const calculateWPM = (input, timeElapsed) => {
    if (!input || timeElapsed <= 0) return 0;
    const words = input.trim().split(/\s+/).length;
    return Math.round((words / timeElapsed) * 60);
  };

  const calculateAccuracy = (input, original) => {
    if (!input) return 100;
    let correctChars = 0;
    const originalSlice = original.slice(0, input.length);
    for (let i = 0; i < input.length; i++) {
      if (input[i] === originalSlice[i]) correctChars++;
    }
    return Math.round((correctChars / input.length) * 100) || 0;
  };

  const endTest = useCallback(async () => {
    clearInterval(timerRef.current);
    setTestState("finished");

    const timeElapsed = parseInt(timeLimit) * 60 - timeLeft;
    const finalWpm = calculateWPM(userInput, timeElapsed);
    const finalAccuracy = calculateAccuracy(userInput, customText);

    setWpm(finalWpm);
    setAccuracy(finalAccuracy);

    const today = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0)).toISOString();
    const endOfDay = new Date(today.setHours(23, 59, 59, 999)).toISOString();

    const { data: existingScores, error: fetchError } = await supabase
      .from("typing_test_leaderboard")
      .select("id, wpm")
      .eq("user_id", user.id)
      .gte("created_at", startOfDay)
      .lte("created_at", endOfDay);

    if (fetchError) {
      toast({
        title: "Error checking score",
        description: fetchError.message,
        variant: "destructive",
      });
      return;
    }

    if (existingScores && existingScores.length > 0) {
      const existingScore = existingScores[0];
      if (finalWpm > existingScore.wpm) {
        const { error: updateError } = await supabase
          .from("typing_test_leaderboard")
          .update({ wpm: finalWpm, accuracy: finalAccuracy })
          .eq("id", existingScore.id);
        if (updateError)
          toast({
            title: "Error updating score",
            description: updateError.message,
            variant: "destructive",
          });
        else {
          toast({
            title: "Score Updated!",
            description: "You've beaten your previous score for today!",
          });
          fetchLeaderboard();
        }
      } else {
        toast({
          title: "Nice Try!",
          description: "You didn't beat your previous high score for today.",
        });
      }
    } else {
      const { error: insertError } = await supabase
        .from("typing_test_leaderboard")
        .insert({
          user_id: user.id,
          wpm: finalWpm,
          accuracy: finalAccuracy,
        });
      if (insertError)
        toast({
          title: "Error saving score",
          description: insertError.message,
          variant: "destructive",
        });
      else {
        toast({
          title: "Score Saved!",
          description: "Your result has been added to today's leaderboard.",
        });
        fetchLeaderboard();
      }
    }
  }, [user.id, timeLimit, timeLeft, userInput, customText, toast, fetchLeaderboard]);

  useEffect(() => {
    if (testState === "testing" && timeLeft > 0) {
      timerRef.current = setInterval(() => setTimeLeft((prev) => prev - 1), 1000);
    } else if (timeLeft === 0 && testState === "testing") {
      endTest();
    }
    return () => clearInterval(timerRef.current);
  }, [testState, timeLeft, endTest]);

  const startTest = useCallback(() => {
    if (customText.trim().length < 20) {
      toast({
        title: "Error",
        description: "Please provide a longer text to start the test.",
        variant: "destructive",
      });
      return;
    }
    setTestState("testing");
    setTimeLeft(parseInt(timeLimit) * 60);
    setUserInput("");
    setWpm(0);
    setAccuracy(100);
    setTimeout(() => inputRef.current?.focus(), 100);
  }, [customText, timeLimit, toast]);

  const resetTest = useCallback(() => {
    setTestState("setup");
    clearInterval(timerRef.current);
  }, []);

  const handleInputChange = (e) => {
    const currentInput = e.target.value;
    setUserInput(currentInput);
    const timeElapsed = parseInt(timeLimit) * 60 - timeLeft;
    setWpm(calculateWPM(currentInput, timeElapsed));
    setAccuracy(calculateAccuracy(currentInput, customText));
  };

  const renderTestText = () =>
    customText.split("").map((char, index) => {
      let colorClass = "text-gray-500";
      if (index < userInput.length)
        colorClass =
          char === userInput[index]
            ? "text-black"
            : "text-red-500 bg-red-100";
      return (
        <span key={index} className={colorClass}>
          {char}
        </span>
      );
    });

  return (
    <>
      <SEO
        title="Typing Test"
        description="Improve your typing speed and accuracy with our free online typing test. Compete on the daily leaderboard and track your progress."
        keywords="typing test, online typing test, wpm test, typing speed, improve typing"
      />

      <div className="space-y-6">
        <AnimatePresence mode="wait">
          {/* Setup */}
          {testState === "setup" && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center text-blue-600">
                    <Keyboard className="mr-2" />
                    Test Setup
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="customText" className="text-sm text-blue-600">
                      Paste your typing text here
                    </Label>
                    <Textarea
                      id="customText"
                      value={customText}
                      onChange={(e) => setCustomText(e.target.value)}
                      className="min-h-[100px] text-sm"
                    />
                  </div>

                  {/* Dropdowns */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm text-blue-600">Time Limit</Label>
                      <Select value={timeLimit} onValueChange={setTimeLimit}>
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent
                          align="center"
                          side="bottom"
                          className="z-[9999] max-h-[300px] overflow-y-auto bg-white border rounded-lg shadow-lg w-[180px] fixed left-1/2 -translate-x-1/2"
                        >
                          {timeOptions.map((t) => (
                            <SelectItem key={t} value={String(t)}>
                              {t} Minute{t > 1 ? "s" : ""}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-sm text-blue-600">
                        Speed Target (WPM)
                      </Label>
                      <Select value={speedTarget} onValueChange={setSpeedTarget}>
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent
                          align="center"
                          side="bottom"
                          className="z-[9999] max-h-[300px] overflow-y-auto bg-white border rounded-lg shadow-lg w-[180px] fixed left-1/2 -translate-x-1/2"
                        >
                          {speedOptions.map((s) => (
                            <SelectItem key={s} value={String(s)}>
                              {s} WPM
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button
                    onClick={startTest}
                    className="w-full bg-blue-600 text-white hover:bg-blue-700"
                  >
                    <Play className="mr-2" /> Start Typing
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Testing */}
          {testState === "testing" && (
            <motion.div
              key="testing"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <Card>
                <CardHeader>
                  <div className="flex justify-around text-center text-sm">
                    <div className="flex items-center space-x-2">
                      <Timer className="text-blue-500" />
                      <p>
                        <span className="text-xl font-bold">
                          {Math.floor(timeLeft / 60)}:
                          {("0" + (timeLeft % 60)).slice(-2)}
                        </span>
                        <br />
                        Time
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Target className="text-green-500" />
                      <p>
                        <span className="text-xl font-bold">{wpm}</span>
                        <br />
                        WPM
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Percent className="text-yellow-500" />
                      <p>
                        <span className="text-xl font-bold">{accuracy}</span>
                        <br />
                        Acc
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 rounded-lg bg-gray-100 font-mono text-base tracking-wider leading-relaxed h-40 overflow-y-auto">
                    {renderTestText()}
                  </div>
                  <Textarea
                    ref={inputRef}
                    value={userInput}
                    onChange={handleInputChange}
                    placeholder="Start typing here..."
                    className="font-mono text-base tracking-wider"
                  />
                  <Button
                    onClick={endTest}
                    variant="destructive"
                    className="w-full"
                  >
                    End Test
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Finished */}
          {testState === "finished" && (
            <motion.div
              key="finished"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
            >
              <Card className="text-center">
                <CardHeader>
                  <CardTitle className="text-blue-600 text-xl">
                    Test Complete!
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-around">
                    <div>
                      <p className="text-2xl font-bold text-green-600">{wpm}</p>
                      <p>WPM</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-yellow-600">
                        {accuracy}%
                      </p>
                      <p>Accuracy</p>
                    </div>
                  </div>
                  <p
                    className={
                      wpm >= parseInt(speedTarget)
                        ? "text-green-600"
                        : "text-red-600"
                    }
                  >
                    {wpm >= parseInt(speedTarget)
                      ? `🎉 Congratulations! You beat ${speedTarget} WPM target.`
                      : `Keep practicing! You were below ${speedTarget} WPM.`}
                  </p>
                  <Button
                    onClick={resetTest}
                    className="w-full bg-blue-600 text-white hover:bg-blue-700"
                  >
                    <RotateCcw className="mr-2" /> Try Again
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Leaderboard */}
        <motion.div layout>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center text-blue-600">
                <Trophy className="mr-2 text-yellow-500" />
                Daily Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                {loadingLeaderboard ? (
                  <div className="flex justify-center items-center py-10">
                    <Loader2 className="w-8 h-8 animate-spin" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="text-blue-600">RANK</TableHead>
                        <TableHead className="text-blue-600">NAME</TableHead>
                        <TableHead className="text-blue-600">WPM</TableHead>
                        <TableHead className="text-blue-600">ACCURACY</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {leaderboard.length > 0 ? (
                        leaderboard.map((entry, index) => (
                          <TableRow key={entry.id}>
                            <TableCell className="font-bold">
                              {index + 1}
                            </TableCell>
                            <TableCell>
                              {entry.profiles?.name || "Anonymous"}
                            </TableCell>
                            <TableCell className="font-semibold">
                              {entry.wpm}
                            </TableCell>
                            <TableCell className="font-semibold">
                              {entry.accuracy}%
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell
                            colSpan={4}
                            className="text-center py-8"
                          >
                            No scores yet for today. Be the first!
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default TypingTest;