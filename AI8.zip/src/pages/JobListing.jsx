import React, { lazy } from 'react';
import { useLocation } from 'react-router-dom';
import TabSystem from '@/components/TabSystem';
import SEO from '@/components/SEO';

const JobCategoryPage = lazy(() => import('@/components/jobs/JobCategoryPage'));

const jobSubCategories = [
  { name: "All Jobs", slug: "all" },
  { name: "States Wise", slug: "all-states" },
  /*{ name: "Banking", slug: "banking" },
  { name: "Forces", slug: "forces" },
  { name: "Teaching", slug: "teaching" },
  { name: "Engineering", slug: "engineering" },
  { name: "Railway", slug: "railway" },*/ //yaha pr menu se tabs ko hide kiya gya hai
];

const JobListingPage = () => {
  const location = useLocation();

  const tabs = jobSubCategories.map(category => {
    // We construct the path based on the category slug.
    // The basepath in TabSystem will prepend "/app/jobs".
    // The query param is what matters for filtering.
    const path = `govt?category=${category.slug}`;
    
    return {
      path: path,
      label: category.name,
      component: <JobCategoryPage categorySlug={category.slug} />
    };
  });

  return (
    <>
      <SEO
        title="Find Govt Jobs"
        description="Browse the latest government job openings by category."
      />
      <TabSystem tabs={tabs} basepath="/app/jobs" />
    </>
  );
};

export default JobListingPage;