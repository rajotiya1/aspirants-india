
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { supabase } from "@/lib/supabase";
import { Loader2, PlayCircle, BarChart2 } from "lucide-react";
import SEO from "@/components/SEO";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { subDays, format } from "date-fns";
import TestRunner from "@/components/online-tests/TestRunner";
import TestResults from "@/components/online-tests/TestResults";
import LeaderboardDialog from "@/components/online-tests/LeaderboardDialog";

const defaultCategories = [
  { name: "भौगोलिक भाग", tableName: "ssc_current_affairs", shortName: "SSC" },
  { name: "ऐतिहासिक भाग", tableName: "upsc_current_affairs", shortName: "UPSC" },
  { name: "सांस्कृतिक भाग", tableName: "haryana_current_affairs", shortName: "Haryana" },
  { name: "सामान्य ज्ञान राजस्थान", tableName: "rajasthan_current_affairs", shortName: "Rajasthan" },
  { name: "शैक्षिक परिदृश्य", tableName: "up_current_affairs", shortName: "U.P." },
  { name: "बाल शिक्षा अधिकार Act", tableName: "bihar_current_affairs", shortName: "Bihar" },
];

const dates = {
  today: format(new Date(), "yyyy-MM-dd"),
  yesterday: format(subDays(new Date(), 1), "yyyy-MM-dd"),
  dayBefore: format(subDays(new Date(), 2), "yyyy-MM-dd"),
};

const STORAGE_KEY_PREFIX = 'generic_test_session_';

const OnlineTests = ({ externalCategories }) => {
  const categories = Array.isArray(externalCategories) && externalCategories.length > 0
      ? externalCategories
      : defaultCategories;

  // Use the first category's shortName for a unique storage key
  const STORAGE_KEY = `${STORAGE_KEY_PREFIX}${categories[0]?.shortName || 'default'}`;

  const { user } = useAuth();
  const { toast } = useToast();

  const [view, setView] = useState("list");
  const [loading, setLoading] = useState(false);
  const [testData, setTestData] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboardContext, setLeaderboardContext] = useState(null);
  const [restoredAnswers, setRestoredAnswers] = useState({});

  useEffect(() => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed && parsed.testData && parsed.view === 'test') {
          setTestData(parsed.testData);
          setRestoredAnswers(parsed.answers || {});
          setView('test');
          toast({
            title: "Test Resumed",
            description: "We've restored your progress.",
          });
        }
      } catch (e) {
        console.error("Failed to restore session", e);
        sessionStorage.removeItem(STORAGE_KEY);
      }
    }
  }, [toast, STORAGE_KEY]);

  const startTest = async (category, date) => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed.testData && (parsed.testData.category.shortName !== category.shortName || parsed.testData.date !== date)) {
          if (!window.confirm("Starting a new test will discard progress from your current one. Continue?")) {
            return;
          }
        }
      } catch (e) {}
    }

    setLoading(true);
    const { data, error } = await supabase
      .from(category.tableName)
      .select("*")
      .eq("date", date);

    if (error || !data || data.length === 0) {
      toast({
        title: "Test Not Available",
        description: `No questions found for ${category.name} on this date.`,
        variant: "destructive",
      });
      setLoading(false);
      return;
    }

    const newTestData = { questions: data, category, date };
    setTestData(newTestData);
    setRestoredAnswers({});
    setView("test");
    setLoading(false);

    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
      view: 'test',
      testData: newTestData,
      answers: {}
    }));
  };
  
  const handleAnswerUpdate = (currentAnswers) => {
    if (!testData) return;
    const sessionPayload = {
      view: 'test',
      testData: testData,
      answers: currentAnswers
    };
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(sessionPayload));
  };

  const handleQuitTest = () => {
    if (window.confirm("Are you sure you want to quit? Your progress will be discarded.")) {
      sessionStorage.removeItem(STORAGE_KEY);
      setView('list');
      setTestData(null);
      setRestoredAnswers({});
    }
  };

  const handleShowRank = (category, date) => {
    setLeaderboardContext({ category: category.shortName, date });
    setShowLeaderboard(true);
  };

  const handleSubmitTest = async (submission) => {
    const { answers, questions } = submission;
    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke(
        "submit-test-and-get-rank",
        {
          body: {
            user_id: user.id,
            category: testData.category.shortName,
            date: testData.date,
            answers,
            questions: questions.map((q) => ({
              id: q.id,
              correct_option: q.correct_option || q.correct_answer_text,
            })),
          },
        }
      );

      if (error) throw new Error(error.message);
      if (!data?.result) throw new Error("Invalid server response.");

      toast({
        title: "Success!",
        description: "Your test has been submitted and ranked.",
      });

      sessionStorage.removeItem(STORAGE_KEY);
      setTestResult({
        result: data.result,
        questions,
        answers,
      });
      setView("results");
    } catch (err) {
      toast({
        title: "Submission Failed",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center py-20">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
        </div>
      );
    }

    switch (view) {
      case "test":
        return (
          <TestRunner
            testData={testData}
            initialAnswers={restoredAnswers}
            onAnswerUpdate={handleAnswerUpdate}
            onSubmit={handleSubmitTest}
            onBack={handleQuitTest}
          />
        );

      case "results":
        return (
          <TestResults
            resultData={testResult}
            onBack={() => setView("list")}
          />
        );

      default:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat, index) => (
              <motion.div
                key={cat.tableName + cat.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-white border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-blue-600">
                      {cat.name}
                    </CardTitle>
                  </CardHeader>

                  <CardContent className="space-y-3">
                    {Object.entries(dates).map(([key, dateValue]) => (
                      <div
                        key={dateValue}
                        className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
                      >
                        <span className="font-semibold text-gray-700">
                          {format(
                            new Date(dateValue + "T00:00:00"),
                            "dd MMM yyyy"
                          )}
                        </span>

                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => startTest(cat, dateValue)}
                            className="bg-blue-500 hover:bg-blue-600"
                          >
                            <PlayCircle className="w-4 h-4 mr-1" /> Start
                          </Button>

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleShowRank(cat, dateValue)}
                          >
                            <BarChart2 className="w-4 h-4 mr-1" /> Rank
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        );
    }
  };

  return (
    <>
      <SEO
        title="Online Tests"
        description="Practice daily tests and check your rank."
      />
      {showLeaderboard && leaderboardContext && (
        <LeaderboardDialog
          open={showLeaderboard}
          onOpenChange={setShowLeaderboard}
          category={leaderboardContext.category}
          date={leaderboardContext.date}
          currentUserId={user.id}
        />
      )}
      <div className="space-y-4">{renderContent()}</div>
    </>
  );
};

export default OnlineTests;
