import React, { useState, useEffect, useMemo } from "react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Loader2, Search } from "lucide-react";
import { motion } from "framer-motion";
import SEO from "@/components/SEO";
import { useBadges } from "@/contexts/BadgeContext";
import { Input } from "@/components/ui/input";

const ExamDate = () => {
  const [examDates, setExamDates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const { toast } = useToast();
  const { markAsSeen } = useBadges();

  useEffect(() => {
    markAsSeen("exam-date");
  }, [markAsSeen]);

  useEffect(() => {
    const fetchExamDates = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("exam_dates")
        .select("id, name_of_exam, date_of_exam")
        .order("created_at", { ascending: false }); // latest first

      if (error) {
        toast({
          title: "Error fetching exam dates",
          description: error.message,
          variant: "destructive",
        });
      } else {
        setExamDates(data || []);
      }
      setLoading(false);
    };
    fetchExamDates();
  }, [toast]);

  const filteredData = useMemo(() => {
    if (!searchTerm) return examDates;
    return examDates.filter((item) =>
      (item.name_of_exam || "")
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, examDates]);

  return (
    <>
      <SEO
        title="Exam Dates"
        description="Find the latest exam dates for various government exams."
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <Card>
          {/* 🔍 Search Bar */}
          <CardHeader>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search exam name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardHeader>

          {/* 📅 Simple Table */}
          <CardContent>
            {loading ? (
              <div className="flex justify-center items-center py-20">
                <Loader2 className="w-12 h-12 animate-spin text-blue-600" />
              </div>
            ) : filteredData.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full border border-gray-200">
                  <thead className="bg-blue-50 border-b">
                    <tr>
                      <th className="text-left px-4 py-2 font-semibold text-gray-700">
                        Name of Exam
                      </th>
                      <th className="text-left px-4 py-2 font-semibold text-gray-700">
                        Exam Date
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredData.map((item) => (
                      <tr
                        key={item.id}
                        className="border-b hover:bg-gray-50 transition"
                      >
                        <td className="px-4 py-2 text-gray-800">
                          {item.name_of_exam}
                        </td>
                        <td className="px-4 py-2 text-gray-600">
                          {item.date_of_exam
                            ? new Date(item.date_of_exam).toLocaleDateString(
                                "en-GB"
                              )
                            : "Not announced"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-20 text-gray-500">
                <p>No exam dates have been posted yet. Please check back later.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </>
  );
};

export default ExamDate;