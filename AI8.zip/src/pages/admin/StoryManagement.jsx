import React from 'react';
import { supabase } from '@/lib/supabase';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Check, X, Trash2, Eye } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { getFriendlyErrorMessage } from '@/lib/errorUtils';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const StoryManagement = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stories, isLoading, error } = useQuery({
    queryKey: ['admin-stories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stories')
        .select('*')
        .order('created_at', { descending: true });
      if (error) throw error;
      return data;
    },
  });

  const updateStoryStatus = useMutation({
    mutationFn: async ({ id, status }) => {
      const { error } = await supabase
        .from('stories')
        .update({ status: status, approved: status === 'Published' })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-stories'] });
      toast({ title: 'Success', description: 'Story status updated.' });
    },
    onError: (err) => {
      toast({
        title: 'Error',
        description: getFriendlyErrorMessage(err),
        variant: 'destructive',
      });
    },
  });

  const deleteStory = useMutation({
    mutationFn: async (id) => {
      const { error } = await supabase.from('stories').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-stories'] });
      toast({ title: 'Success', description: 'Story deleted.' });
    },
    onError: (err) => {
      toast({
        title: 'Error',
        description: getFriendlyErrorMessage(err),
        variant: 'destructive',
      });
    },
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Published':
        return 'bg-green-500 hover:bg-green-600';
      case 'Rejected':
        return 'bg-red-500 hover:bg-red-600';
      case 'Pending':
      default:
        return 'bg-yellow-500 hover:bg-yellow-600';
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-500 py-10">
        Error fetching stories: {getFriendlyErrorMessage(error)}
      </div>
    );
  }

  return (
    <>
      <SEO title="Manage Stories" description="Approve, reject, and manage user-submitted stories." />
      <div className="container mx-auto p-4">
        <h1 className="text-3xl font-bold mb-6 text-center text-gray-800">Story Management</h1>
        <div className="space-y-4">
          {stories.length === 0 ? (
            <p className="text-center text-gray-500 py-10">No stories submitted yet.</p>
          ) : (
            stories.map((story) => (
              <Card key={story.id} className="shadow-md hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl">{story.title}</CardTitle>
                      <p className="text-sm text-gray-500">By: {story.author_name || 'Anonymous'}</p>
                      <p className="text-xs text-gray-400">Submitted: {new Date(story.created_at).toLocaleString()}</p>
                    </div>
                    <Badge className={getStatusBadge(story.status)}>{story.status}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4 line-clamp-3">{story.content}</p>
                  <div className="flex flex-wrap gap-2 justify-end">
                    <Link to={`/stories/${story.slug}`} target="_blank" rel="noopener noreferrer">
                       <Button variant="outline" size="sm"><Eye className="w-4 h-4 mr-2" />View</Button>
                    </Link>
                    {story.status !== 'Published' && (
                      <Button
                        size="sm"
                        className="bg-green-500 hover:bg-green-600 text-white"
                        onClick={() => updateStoryStatus.mutate({ id: story.id, status: 'Published' })}
                        disabled={updateStoryStatus.isPending}
                      >
                        <Check className="w-4 h-4 mr-2" /> Approve
                      </Button>
                    )}
                    {story.status !== 'Rejected' && (
                      <Button
                        size="sm"
                        variant="destructive"
                        className="bg-orange-500 hover:bg-orange-600"
                        onClick={() => updateStoryStatus.mutate({ id: story.id, status: 'Rejected' })}
                        disabled={updateStoryStatus.isPending}
                      >
                        <X className="w-4 h-4 mr-2" /> Reject
                      </Button>
                    )}
                     <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                            if(window.confirm('Are you sure you want to delete this story permanently?')) {
                                deleteStory.mutate(story.id)
                            }
                        }}
                        disabled={deleteStory.isPending}
                      >
                        <Trash2 className="w-4 h-4 mr-2" /> Delete
                      </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </>
  );
};

export default StoryManagement;