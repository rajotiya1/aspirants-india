import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SEO from '@/components/SEO';
import JobManagement from '@/components/admin/JobManagement';
import StoryManagement from '@/components/admin/StoryManagement';
import TestManagement from '@/components/admin/TestManagement';
import SettingsManagement from '@/components/admin/SettingsManagement';
import AdManagement from '@/components/admin/AdManagement';
import JobDetailManagement from '@/components/admin/JobDetailManagement';

const Admin = () => {
  return (
    <>
      <SEO title="Admin Panel" description="Manage the application content." />
      <div className="container mx-auto py-10 px-4">
        <h1 className="text-3xl font-bold mb-6">Admin Panel</h1>
        <Tabs defaultValue="jobs" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
            <TabsTrigger value="jobs">Jobs</TabsTrigger>
            <TabsTrigger value="job_details">Job Details</TabsTrigger>
            <TabsTrigger value="stories">Stories</TabsTrigger>
            <TabsTrigger value="tests">Tests</TabsTrigger>
            <TabsTrigger value="ads">Ads</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>
          <TabsContent value="jobs">
            <JobManagement />
          </TabsContent>
          <TabsContent value="job_details">
            <JobDetailManagement />
          </TabsContent>
          <TabsContent value="stories">
            <StoryManagement />
          </TabsContent>
          <TabsContent value="tests">
            <TestManagement />
          </TabsContent>
          <TabsContent value="ads">
            <AdManagement />
          </TabsContent>
          <TabsContent value="settings">
            <SettingsManagement />
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default Admin;