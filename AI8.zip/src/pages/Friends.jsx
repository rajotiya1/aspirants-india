import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, UserCheck, UserX, Clock, ArrowRight, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePresence } from '@/contexts/PresenceContext';
import { Card, CardContent } from '@/components/ui/card';
import { useBadges } from '@/contexts/BadgeContext';
import { useTargetUserId } from '@/hooks/useTargetUserId';

const Friends = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { onlineUsers } = usePresence();
  const { markAsSeen } = useBadges();
  const targetUserId = useTargetUserId();

  const [friends, setFriends] = useState([]);
  const [incomingRequests, setIncomingRequests] = useState([]);
  const [outgoingRequests, setOutgoingRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  const isOwnProfile = user?.id === targetUserId;

  const fetchFriendsData = useCallback(async () => {
    if (!targetUserId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from('friendships')
      .select('*, requester:requester_id(*), addressee:addressee_id(*)')
      .or(`requester_id.eq.${targetUserId},addressee_id.eq.${targetUserId}`);

    if (error) {
      toast({ title: 'Error fetching friends data', description: error.message, variant: 'destructive' });
    } else {
      setFriends(data.filter(f => f.status === 'accepted'));
      setIncomingRequests(data.filter(f => f.status === 'pending' && f.addressee_id === targetUserId));
      setOutgoingRequests(data.filter(f => f.status === 'pending' && f.requester_id === targetUserId));
    }
    setLoading(false);
  }, [targetUserId, toast]);

  useEffect(() => {
    fetchFriendsData();
     const channel = supabase.channel('public:friendships')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'friendships' }, (payload) => {
          const record = payload.new || payload.old;
          if (record && (record.requester_id === targetUserId || record.addressee_id === targetUserId)) {
            fetchFriendsData();
          }
      })
      .subscribe();
    
    return () => supabase.removeChannel(channel);
  }, [fetchFriendsData, targetUserId]);
  
  useEffect(() => {
    if(isOwnProfile) {
      markAsSeen('friends');
    }
  }, [isOwnProfile, markAsSeen, incomingRequests]);

  const handleRequest = async (friendshipId, newStatus) => {
    const { error } = await supabase
      .from('friendships')
      .update({ status: newStatus, updated_at: new Date().toISOString() })
      .eq('id', friendshipId);

    if (error) {
      toast({ title: 'Error updating request', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: `Friend request ${newStatus === 'accepted' ? 'accepted' : 'declined'}.` });
    }
  };
  
  const handleCancelRequest = async (friendshipId) => {
    const { error } = await supabase.from('friendships').delete().eq('id', friendshipId);
    if (error) {
      toast({ title: 'Error cancelling request', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Friend request cancelled.' });
    }
  };
  
  const isUserOnline = (profileId) => {
    const onlineUser = onlineUsers.get(profileId);
    return onlineUser && onlineUser.show_online_status;
  };

  const filteredFriends = useMemo(() => {
    return friends.filter(friendship => {
      const profile = friendship.requester.id === targetUserId ? friendship.addressee : friendship.requester;
      return profile.name?.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [friends, searchTerm, targetUserId]);

  const UserCard = ({ friendship, type }) => {
    const profile = type === 'friend' ? (friendship.requester.id === targetUserId ? friendship.addressee : friendship.requester) :
                    type === 'incoming' ? friendship.requester : friendship.addressee;
    if (!profile) return null;
    
    return (
       <div className="flex items-center justify-between p-2 bg-secondary/30 rounded-lg">
        <Link to={`/app/profile/summary/${profile.id}`} className="flex items-center space-x-3 group">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src={profile.avatar_path} alt={profile.name}/>
              <AvatarFallback>{profile.name ? profile.name.charAt(0) : 'U'}</AvatarFallback>
            </Avatar>
            {isUserOnline(profile.id) && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background"></div>}
          </div>
          <div>
            <p className="font-semibold text-sm text-foreground group-hover:underline">{profile.name}</p>
            <p className="text-xs text-muted-foreground">{profile.district}, {profile.state}</p>
          </div>
        </Link>
        {isOwnProfile && (
          <div className="flex items-center space-x-1">
            {type === 'incoming' && (
              <>
                <Button size="icon" className="h-8 w-8 bg-green-500 hover:bg-green-600" onClick={() => handleRequest(friendship.id, 'accepted')}><UserCheck className="w-4 h-4" /></Button>
                <Button size="icon" className="h-8 w-8" variant="destructive" onClick={() => handleRequest(friendship.id, 'declined')}><UserX className="w-4 h-4" /></Button>
              </>
            )}
            {type === 'outgoing' && (
              <Button size="sm" variant="outline" onClick={() => handleCancelRequest(friendship.id)}><Clock className="w-4 h-4 mr-1" />Cancel</Button>
            )}
          </div>
        )}
      </div>
    );
  };

  const UserList = ({ list, type, emptyMessage }) => (
    <div className="space-y-2">
      {list.length > 0 ? list.map(item => <UserCard key={item.id} friendship={item} type={type} />) : <p className="text-muted-foreground text-center py-4">{emptyMessage}</p>}
    </div>
  );
  
  if (loading) return <div className="flex justify-center items-center p-10"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;

  return (
    <>
      <SEO title="My Friends" description="Manage your friends and friend requests on ourgovtjob.com" />
      <div className="space-y-4 p-4">
         {isOwnProfile ? (
            <Tabs defaultValue="friends" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="friends">Friends ({friends.length})</TabsTrigger>
                <TabsTrigger value="incoming">Incoming ({incomingRequests.length})</TabsTrigger>
                <TabsTrigger value="outgoing">Outgoing ({outgoingRequests.length})</TabsTrigger>
              </TabsList>
                <CardContent className="pt-4 px-0">
                  <TabsContent value="friends">
                      <div className="relative mb-4">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input
                          placeholder="Search friends..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 h-9"
                        />
                      </div>
                      <UserList list={filteredFriends} type="friend" emptyMessage={searchTerm ? 'No friends found.' : <>No friends yet. <Link to={`/app/profile/users/${user.id}`} className="text-primary hover:underline">Find users <ArrowRight className="inline w-4 h-4"/></Link></>} />
                    </TabsContent>
                    <TabsContent value="incoming">
                      <UserList list={incomingRequests} type="incoming" emptyMessage="No incoming friend requests." />
                    </TabsContent>
                    <TabsContent value="outgoing">
                      <UserList list={outgoingRequests} type="outgoing" emptyMessage="No outgoing friend requests." />
                    </TabsContent>
                </CardContent>
            </Tabs>
         ) : (
            <div>
              <h2 className="text-xl font-bold mb-4">{friends.length} Friends</h2>
              <UserList list={friends} type="friend" emptyMessage="This user has no friends yet." />
            </div>
         )}
      </div>
    </>
  );
};

export default Friends;