
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/supabase';
import { Loader2, PlayCircle, BarChart2 } from 'lucide-react';
import SEO from '@/components/SEO';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { subDays, format } from 'date-fns';
import TestRunner from '@/components/online-tests/TestRunner';
import TestResults from '@/components/online-tests/TestResults';
import LeaderboardDialog from '@/components/online-tests/LeaderboardDialog';

const categories = [
  { name: 'English (Vocabs)', tableName: 'ssc_english_vocabs_test', shortName: 'SSC-Vocabs' },
  { name: 'English (Tier-I)', tableName: 'ssc_english_tier1_test', shortName: 'SSC-English-T1' },
  { name: 'G.S. (Tier-I)', tableName: 'ssc_gs_tier1_test', shortName: 'SSC-GS-T1' },
  { name: 'Reasoning (Tier-I)', tableName: 'ssc_reasoning_tier1_test', shortName: 'SSC-Reasoning-T1' },
  { name: 'Maths (Tier-I)', tableName: 'ssc_maths_tier1_test', shortName: 'SSC-Maths-T1' },
];

const dates = {
  today: format(new Date(), 'yyyy-MM-dd'),
  yesterday: format(subDays(new Date(), 1), 'yyyy-MM-dd'),
  dayBefore: format(subDays(new Date(), 2), 'yyyy-MM-dd'),
};

const STORAGE_KEY = 'ssc_test_active_session_v2';

const SSCOnlineTests = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  const [view, setView] = useState('list');
  const [loading, setLoading] = useState(false);
  const [testData, setTestData] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboardContext, setLeaderboardContext] = useState(null);
  const [restoredAnswers, setRestoredAnswers] = useState({});

  // Restore session on mount
  useEffect(() => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
        try {
            const parsed = JSON.parse(savedSession);
            if (parsed && parsed.testData && parsed.view === 'test') {
                setTestData(parsed.testData);
                setRestoredAnswers(parsed.answers || {});
                setView('test');
                toast({
                    title: "Test Resumed",
                    description: "We've restored your progress from where you left off.",
                    variant: "default",
                });
            }
        } catch (e) {
            console.error("Failed to restore session", e);
            sessionStorage.removeItem(STORAGE_KEY);
        }
    }
  }, [toast]);

  const startTest = async (category, date) => {
    const savedSession = sessionStorage.getItem(STORAGE_KEY);
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed.testData && (parsed.testData.category.shortName !== category.shortName || parsed.testData.date !== date)) {
           if (!window.confirm("You have an unfinished test in progress. Starting a new one will discard it. Continue?")) {
             return;
           }
        }
      } catch(e) {}
    }

    setLoading(true);
    const { data, error } = await supabase
      .from(category.tableName)
      .select('*')
      .eq('date', date);

    if (error || !data || data.length === 0) {
      toast({ title: "Test Not Available", description: `No questions found for ${category.name} on this date.`, variant: "destructive" });
      setLoading(false);
      return;
    }

    const newTestData = { questions: data, category, date };
    setTestData(newTestData);
    setRestoredAnswers({});
    setView('test');
    setLoading(false);

    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({
        view: 'test',
        testData: newTestData,
        answers: {}
    }));
  };

  const handleAnswerUpdate = (currentAnswers) => {
    if (!testData) return;
    
    const sessionPayload = {
        view: 'test',
        testData: testData,
        answers: currentAnswers
    };
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(sessionPayload));
  };

  const handleQuitTest = () => {
    if (window.confirm("Are you sure you want to quit? Your progress will be discarded.")) {
        sessionStorage.removeItem(STORAGE_KEY);
        setView('list');
        setTestData(null);
        setRestoredAnswers({});
    }
  };

  const handleShowRank = (category, date) => {
    setLeaderboardContext({ category: category.shortName, date });
    setShowLeaderboard(true);
  };

  const handleSubmitTest = async (submission) => {
    const { answers, questions } = submission;
    setLoading(true);
    try {
      const normalizedQuestions = questions.map((q) => {
        if (q.correct_option) {
          return { id: q.id, correct_option: q.correct_option };
        }
        const adv = q.correct_answer_text || q.correct_answer_html || q.correct_answer_image_url || null;
        return { id: q.id, correct_option: adv };
      });

      const { data, error } = await supabase.functions.invoke('submit-test-and-get-rank', {
        body: {
          user_id: user.id,
          category: testData.category.shortName,
          date: testData.date,
          answers,
          questions: normalizedQuestions,
        },
      });

      if (error) throw new Error(`Edge function invocation failed: ${error.message}`);
      if (data && data.error) throw new Error(`Error from edge function: ${data.error}`);
      if (!data || !data.result) throw new Error("Received an invalid response from the server.");

      toast({ title: "Success!", description: "Your test has been submitted and ranked." });
      
      sessionStorage.removeItem(STORAGE_KEY);
      
      setTestResult({ result: data.result, questions: questions, answers: answers });
      setView('results');

    } catch (error) {
      toast({ title: "Submission Failed", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    if (loading) {
      return <div className="flex justify-center items-center py-20"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;
    }

    switch (view) {
      case 'test':
        return (
            <TestRunner 
                testData={testData} 
                initialAnswers={restoredAnswers}
                onAnswerUpdate={handleAnswerUpdate}
                onSubmit={handleSubmitTest} 
                onBack={handleQuitTest} 
            />
        );

      case 'results':
        return <TestResults resultData={testResult} onBack={() => setView('list')} />;

      default:
        return (
          <div className="space-y-6">
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {categories.map((cat, index) => (
                <motion.div key={cat.name} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
                    <Card className="bg-white border-gray-200 shadow-sm hover:shadow-md transition-all">
                    <CardHeader className="pb-3">
                        <CardTitle className="text-blue-600 text-lg">{cat.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                        {Object.entries(dates).map(([key, dateValue]) => (
                        <div
                            key={dateValue}
                            className="flex items-center justify-between p-2 bg-gray-50 rounded-md w-full whitespace-nowrap border border-transparent hover:border-blue-100 transition-colors"
                        >
                            <span className="font-medium text-gray-700 flex-grow text-sm">
                            {format(new Date(dateValue + 'T00:00:00'), 'dd-MM-yyyy')}
                            </span>

                            <div className="flex items-center gap-2 shrink-0">
                            <Button size="sm" onClick={() => startTest(cat, dateValue)} className="bg-blue-500 hover:bg-blue-600 h-8 px-3">
                                <PlayCircle className="w-3.5 h-3.5 mr-1.5" /> Start
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleShowRank(cat, dateValue)} className="h-8 px-3 text-gray-600">
                                <BarChart2 className="w-3.5 h-3.5 mr-1.5" /> Rank
                            </Button>
                            </div>
                        </div>
                        ))}
                    </CardContent>
                    </Card>
                </motion.div>
                ))}
            </div>
          </div>
        );
    }
  };

  return (
    <>
      <SEO
        title="SSC Online Tests"
        description="Take daily SSC tests for English, GS, Reasoning, and Maths. Check your rank on the daily leaderboard."
        keywords="ssc online tests, ssc vocabs, ssc tier 1, ssc gs, ssc reasoning, ssc maths"
      />

      {showLeaderboard && leaderboardContext && (
        <LeaderboardDialog
          open={showLeaderboard}
          onOpenChange={setShowLeaderboard}
          category={leaderboardContext.category}
          date={leaderboardContext.date}
          currentUserId={user.id}
        />
      )}

      <div className="space-y-4 min-h-[80vh]">
        {renderContent()}
      </div>
    </>
  );
};

export default SSCOnlineTests;
