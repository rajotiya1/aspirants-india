import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/supabase';
import SEO from '@/components/SEO';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Trash2, Download, Link as LinkIcon, Eye, Briefcase } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useTargetUserId } from '@/hooks/useTargetUserId';
import { formatDate } from '@/lib/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Link } from 'react-router-dom';
import ProfileContentLock from '@/components/profile/ProfileContentLock';

const JobRow = ({ job, onRemove, onToggleDetail, openDetailId, isOwnProfile }) => {
  const isOpen = openDetailId === job.saved_id;

  const handleShowInterstitialAd = (e) => {
    e.stopPropagation();
    if (window.Android && typeof window.Android.showInterstitialAd === 'function') {
      window.Android.showInterstitialAd();
    }
    onToggleDetail(job.saved_id);
  };

  return (
    <>
      <TableRow
        className="border-b border-border hover:bg-muted/50 cursor-pointer font-bold"
        onClick={handleShowInterstitialAd}
      >
        <TableCell className="font-bold">{job.name_of_post}</TableCell>
        <TableCell className="hidden md:table-cell">{job.qualification}</TableCell>
        <TableCell>{formatDate(job.last_date)}</TableCell>
        <TableCell className="text-right">
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-foreground flex items-center h-8"
          >
            <Eye className="w-4 h-4 mr-1" />
            <span className="hidden sm:inline">Details</span>
          </Button>
        </TableCell>
      </TableRow>

      <AnimatePresence>
        {isOpen && (
          <motion.tr
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-muted/30"
          >
            <TableCell colSpan={5} className="p-4 font-normal">
              <div className="space-y-3 text-black dark:text-white">
                <p>
                  <strong className="text-foreground">Details:</strong> {job.detail}
                </p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <p>
                    <strong className="text-foreground">Authority:</strong>{' '}
                    {job.requirement_board || job.authority}
                  </p>
                  <p>
                    <strong className="text-foreground">No. of Posts:</strong> {job.no_of_post}
                  </p>
                </div>

                <div className="flex gap-4 items-center mt-4">
                  {job.direct_link && (
                    <Button
                      variant="link"
                      size="sm"
                      asChild
                      className="text-blue-500 hover:text-blue-600 p-0 h-auto"
                    >
                      <a
                        href={job.direct_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1"
                      >
                        <LinkIcon className="h-4 w-4" /> Apply
                      </a>
                    </Button>
                  )}

                  {job.pdf_url && (
                    <Link
                      to={`/notice/${job.job_id_bigint}/pdf`}
                      className="text-green-500 hover:text-green-600 inline-flex items-center gap-1 text-sm"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <Download className="w-3 h-3" />
                      Notification
                    </Link>
                  )}

                  <div className="flex-grow text-right">
                    {isOwnProfile && (
                      <Button
                        variant="destructive"
                        size="icon"
                        className="h-8 w-8"
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemove(job.saved_id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </TableCell>
          </motion.tr>
        )}
      </AnimatePresence>
    </>
  );
};

const SavedJobs = () => {
  const targetUserId = useTargetUserId();
  const { user } = useAuth();
  const { toast } = useToast();
  const [savedJobs, setSavedJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openDetailId, setOpenDetailId] = useState(null);
  const [profile, setProfile] = useState(null);
  const [accessDenied, setAccessDenied] = useState(false);

  const isOwnProfile = user?.id === targetUserId;

  const fetchSavedJobs = useCallback(async () => {
    if (!targetUserId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setAccessDenied(false);

    try {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('name')
        .eq('id', targetUserId)
        .single();

      if (profileError && profileError.code !== 'PGRST116') throw profileError;
      setProfile(profileData);

      const { data, error } = await supabase.rpc('get_all_saved_jobs', {
        p_user_id: targetUserId,
      });

      if (error) {
        if (error.code === 'PGRST200' || error.message.includes('permission denied')) {
          setAccessDenied(true);
        } else {
          throw error;
        }
      } else {
        setSavedJobs(data || []);
      }
    } catch (error) {
      console.error('Error fetching saved jobs:', error);
      toast({
        title: 'Error fetching saved jobs',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    if (targetUserId) {
      fetchSavedJobs();
    } else {
      setLoading(false);
    }
  }, [targetUserId, fetchSavedJobs]);
  
  const handleRemoveJob = async (savedId) => {
    if (!user) return;
  
    const { error } = await supabase
      .from('user_saved_jobs')
      .delete()
      .eq('id', savedId)
      .eq('user_id', user.id);
  
    if (error) {
      toast({
        title: 'Error removing job',
        description: error.message,
        variant: 'destructive',
      });
    } else {
      setSavedJobs((prev) => prev.filter((job) => job.saved_id !== savedId));
      toast({ title: 'Removed', description: 'Job removed from your saved list.' });
    }
  };

  const handleToggleDetail = (savedJobId) =>
    setOpenDetailId((prevId) => (prevId === savedJobId ? null : savedJobId));

  if (loading) {
    return (
      <div className="flex justify-center items-center py-10">
        <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
      </div>
    );
  }

  if (accessDenied) {
    return (
      <ProfileContentLock
        sectionName="Saved Jobs"
        profileOwnerName={profile?.name || 'this user'}
      />
    );
  }

  const renderJobTableHeader = () => (
    <TableRow>
      <TableHead>Name of Post</TableHead>
      <TableHead className="hidden md:table-cell">Qualification</TableHead>
      <TableHead>Last Date</TableHead>
      <TableHead className="text-right">Details</TableHead>
    </TableRow>
  );

  return (
    <>
      <SEO title="Saved Jobs" description="Your saved government job listings." />
      <Card className="glass-effect border-white/20 shadow-none border-0 p-4">
        {savedJobs.length > 0 ? (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>{renderJobTableHeader()}</TableHeader>
              <TableBody>
                {savedJobs.map(
                  (job) =>
                    job && (
                      <JobRow
                        key={job.saved_id}
                        job={job}
                        onToggleDetail={handleToggleDetail}
                        openDetailId={openDetailId}
                        onRemove={handleRemoveJob}
                        isOwnProfile={isOwnProfile}
                      />
                    )
                )}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-10 text-gray-400">
            <Briefcase className="mx-auto w-12 h-12 mb-4" />
            <p>
              {isOwnProfile
                ? "You haven't saved any jobs yet."
                : 'No saved jobs to display.'}
            </p>
          </div>
        )}
      </Card>
    </>
  );
};

export default SavedJobs;