import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, User, Calendar, Award } from 'lucide-react';
import { motion } from 'framer-motion';
import SEO from '@/components/SEO';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import WebViewAdBanner from '@/components/WebViewAdBanner';
import { isWebViewGold } from '@/lib/admob';

const StoryDetailPage = () => {
    const { slug } = useParams();
    const [story, setStory] = useState(null);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();

    useEffect(() => {
        const fetchStory = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('stories')
                .select('*')
                .eq('slug', slug)
                .eq('approved', true)
                .single();

            if (error || !data) {
                toast({ title: 'Error', description: 'Story not found or not approved yet.', variant: 'destructive' });
            } else {
                setStory(data);
            }
            setLoading(false);
        };

        if (slug) {
            fetchStory();
        }
    }, [slug, toast]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen bg-gray-50">
                <Loader2 className="w-16 h-16 animate-spin text-blue-600" />
            </div>
        );
    }

    if (!story) {
        return (
            <div className="text-center py-20 bg-gray-50">
                <h1 className="text-3xl font-bold text-gray-800">Story Not Found</h1>
                <p className="text-gray-500 mt-2">The story you are looking for does not exist or is under review.</p>
                <Button asChild className="mt-6 bg-blue-600 hover:bg-blue-700">
                    <Link to="/stories">Back to Stories</Link>
                </Button>
            </div>
        );
    }
    
    const metaDescription = story.content ? story.content.replace(/<[^>]+>/g, ' ').substring(0, 160) : 'Read the success story of ' + (story.author_name || 'an aspirant');

    return (
        <>
            <SEO
                title={`${story.title} by ${story.author_name || 'Anonymous'}`}
                description={metaDescription}
                canonical={`https://www.ourgovtjob.com/stories/${story.slug}`}
                ogType="article"
                ogTitle={story.title}
                ogDescription={metaDescription}
                ogImage="https://imagedelivery.net/LqiWLm-3MGbYHtFuUbcBtA/119580eb-abd9-4191-b93a-f01938786700/public" 
            >
                <script type="application/ld+json">
                    {`
                    {
                        "@context": "https://schema.org",
                        "@type": "Article",
                        "headline": "${story.title}",
                        "author": {
                            "@type": "Person",
                            "name": "${story.author_name || 'Anonymous'}"
                        },
                        "datePublished": "${new Date(story.created_at).toISOString()}",
                        "description": "${metaDescription}",
                        "publisher": {
                            "@type": "Organization",
                            "name": "ourgovtjob.com",
                            "logo": {
                                "@type": "ImageObject",
                                "url": "https://imagedelivery.net/LqiWLm-3MGbYHtFuUbcBtA/119580eb-abd9-4191-b93a-f01938786700/public"
                            }
                        }
                    }
                    `}
                </script>
            </SEO>
            {isWebViewGold() && <WebViewAdBanner />}
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="max-w-4xl mx-auto px-4 py-8 bg-gray-50 rounded-lg"
            >
                <article className="prose prose-lg max-w-none text-black">
                    <header className="mb-8 border-b border-gray-200 pb-4">
                        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-blue-600 mb-4">{story.title}</h1>
                        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-gray-500">
                            <div className="flex items-center gap-2">
                                <User className="w-5 h-5" />
                                <span>{story.author_name || 'Anonymous'}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Calendar className="w-5 h-5" />
                                <span>{format(new Date(story.created_at), 'MMMM d, yyyy')}</span>
                            </div>
                        </div>
                    </header>

                    <div className="space-y-6 story-content text-black">
                        {story.content.split('\n').map((paragraph, index) => (
                           <React.Fragment key={index}>
                                <p>{paragraph}</p>
                           </React.Fragment> 
                        ))}
                    </div>

                    {story.tips && (
                        <div className="mt-12 p-6 rounded-lg bg-blue-50 border border-blue-200">
                            <h3 className="text-2xl font-bold text-blue-600 flex items-center gap-3 mb-4">
                                <Award className="w-7 h-7" />
                                Top Tips for Success
                            </h3>
                            <div className="prose prose-lg max-w-none text-gray-800 space-y-4 whitespace-pre-wrap">
                                {story.tips}
                            </div>
                        </div>
                    )}
                    
                    <footer className="mt-12 pt-8 border-t border-gray-200 text-center">
                        <h3 className="text-2xl font-semibold text-blue-600">Inspired? News/Article/Story!</h3>
                        <p className="text-gray-600 mt-2 mb-4">Help others on their journey by sharing your own success.</p>
                        <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
                           <Link to="/app/profile/my-story">Submit Your Article/Story</Link>
                        </Button>
                    </footer>
                </article>
            </motion.div>
        </>
    );
};

export default StoryDetailPage;