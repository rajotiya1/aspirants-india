import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Search, BookHeart, Edit } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SEO from '@/components/SEO';
import { formatDistanceToNow } from 'date-fns';

const StoryListPage = () => {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('created_at'); // 'created_at' or 'popularity'
  const {
    toast
  } = useToast();
  const navigate = useNavigate();
  useEffect(() => {
    const fetchStories = async () => {
      setLoading(true);
      let query = supabase.from('stories').select('*').eq('approved', true);
      if (searchTerm) {
        query = query.textSearch('title', `'${searchTerm}'`);
      }
      if (sortBy === 'created_at') {
        query = query.order('created_at', {
          ascending: false
        });
      }
      // Add popularity sort logic later if needed

      const {
        data,
        error
      } = await query;
      if (error) {
        toast({
          title: 'Error fetching stories',
          description: error.message,
          variant: 'destructive'
        });
      } else {
        setStories(data);
      }
      setLoading(false);
    };
    fetchStories();
  }, [toast, searchTerm, sortBy]);
  const filteredStories = useMemo(() => {
    return stories.filter(story => story.title.toLowerCase().includes(searchTerm.toLowerCase()) || story.content && story.content.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [stories, searchTerm]);
  return <>
            <SEO title="Success Stories" description="Read inspiring success stories from candidates who have cleared various government exams." />
            <div className="container mx-auto px-4 py-8 bg-gray-50">
                <motion.div className="text-center mb-8" initial={{
        opacity: 0,
        y: -20
      }} animate={{
        opacity: 1,
        y: 0
      }}>
                    <h1 className="text-4xl font-bold tracking-tight text-blue-600 mb-2">News/Articles/Stories</h1>
                    <p className="text-lg text-gray-600 max-w-2xl mx-auto">Discover the journeys, strategies, and tips from those who have achieved their dreams.</p>
                     <Button onClick={() => navigate('/submit-story')} className="mt-4 bg-blue-600 hover:bg-blue-700">
                        <Edit className="mr-2 h-4 w-4" /> Share Your Article/Story
                    </Button>
                </motion.div>

                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                    <div className="relative flex-grow">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input placeholder="Search stories by title or keyword..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10 bg-white border-gray-300" />
                    </div>
                    <Select onValueChange={setSortBy} defaultValue={sortBy}>
                        <SelectTrigger className="w-full sm:w-[180px] bg-white border-gray-300">
                            <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="created_at">Most Recent</SelectItem>
                            <SelectItem value="popularity" disabled>Popularity</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
                
                {loading ? <div className="flex justify-center items-center py-20"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div> : filteredStories.length > 0 ? <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <AnimatePresence>
                            {filteredStories.map((story, index) => <motion.div key={story.id} initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} exit={{
            opacity: 0,
            y: -20
          }} transition={{
            duration: 0.3,
            delay: index * 0.05
          }}>
                                    <Card className="h-full flex flex-col bg-gray-50 border border-gray-200 hover:border-blue-500 transition-all duration-300 shadow-md">
                                        <CardHeader>
                                            <CardTitle className="text-blue-600">{story.title}</CardTitle>
                                            <CardDescription className="text-gray-500">
                                                By {story.author_name || 'Anonymous'} • {formatDistanceToNow(new Date(story.created_at), {
                    addSuffix: true
                  })}
                                            </CardDescription>
                                        </CardHeader>
                                        <CardContent className="flex-grow">
                                            <p className="text-black line-clamp-4">
                                                {story.content.replace(/<[^>]+>/g, '')}
                                            </p>
                                        </CardContent>
                                        <CardFooter>
                                            <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                                                <Link to={`/stories/${story.slug}`}>Read Full Article</Link>
                                            </Button>
                                        </CardFooter>
                                    </Card>
                                </motion.div>)}
                        </AnimatePresence>
                    </div> : <motion.div initial={{
        opacity: 0,
        scale: 0.9
      }} animate={{
        opacity: 1,
        scale: 1
      }} className="text-center py-20 text-gray-500">
                         <BookHeart className="mx-auto w-16 h-16 mb-4 text-gray-400" />
                        <p className="text-xl font-semibold">No stories found.</p>
                        <p>No stories match your search. Why not be the first to share one?</p>
                    </motion.div>}
            </div>
        </>;
};
export default StoryListPage;