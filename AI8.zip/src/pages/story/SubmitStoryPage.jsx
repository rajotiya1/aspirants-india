import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import SEO from '@/components/SEO';
import { useNavigate } from 'react-router-dom';
import Filter from 'bad-words';
import { motion } from 'framer-motion';

const profanityFilter = new Filter();

const SubmitStoryPage = () => {
    const { user, profile } = useAuth();
    const { toast } = useToast();
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [tips, setTips] = useState('');
    const [authorName, setAuthorName] = useState(profile?.name || '');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [captcha, setCaptcha] = useState({ num1: 0, num2: 0, answer: '' });

    React.useEffect(() => {
        generateCaptcha();
    }, []);

    const generateCaptcha = () => {
        const num1 = Math.floor(Math.random() * 10) + 1;
        const num2 = Math.floor(Math.random() * 10) + 1;
        setCaptcha({ num1, num2, answer: '' });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (parseInt(captcha.answer, 10) !== captcha.num1 + captcha.num2) {
            toast({
                title: 'Incorrect CAPTCHA',
                description: 'Please solve the math problem correctly.',
                variant: 'destructive',
            });
            generateCaptcha();
            return;
        }

        if (!title.trim() || !content.trim()) {
            toast({
                title: 'Missing Information',
                description: 'Title and Story Content are required.',
                variant: 'destructive',
            });
            return;
        }

        setIsSubmitting(true);
        
        try {
            const { data: slugData, error: slugError } = await supabase.rpc('generate_slug', { title_text: title });
            
            if (slugError) {
                console.error("Slug generation error:", slugError);
                throw new Error("Could not generate a unique slug. Please try a different title.");
            }

            let finalSlug = slugData;
            if (!finalSlug) {
                // Fallback slug generation in case RPC fails silently
                finalSlug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') + '-' + Date.now();
                toast({
                    title: 'Slug Generation Warning',
                    description: 'Could not generate a perfect URL slug, using a fallback.',
                    variant: 'default',
                });
            }

            const cleanTitle = profanityFilter.clean(title);
            const cleanContent = profanityFilter.clean(content);
            const cleanTips = tips ? profanityFilter.clean(tips) : null;

            const { error: insertError } = await supabase.from('stories').insert({
                user_id: user.id,
                title: cleanTitle,
                content: cleanContent,
                tips: cleanTips,
                author_name: authorName,
                slug: finalSlug,
                approved: false
            });

            if (insertError) throw insertError;

            toast({
                title: 'Success!',
                description: 'Your story has been submitted for review. Thank you for sharing!',
                className: 'bg-green-600 text-white',
            });
            navigate('/stories');

        } catch (error) {
            toast({
                title: 'Submission Failed',
                description: error.message || 'An unexpected error occurred. Please try again.',
                variant: 'destructive',
            });
            generateCaptcha();
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <>
            <SEO
                title="Submit Your Success Story"
                description="Share your journey of clearing exams like SSC, UPSC, or Banking to inspire others."
            />
            <div className="max-w-4xl mx-auto py-12 px-4">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <Card className="bg-gray-900/50 border border-gray-700 text-white">
                        <CardHeader className="text-center">
                            <CardTitle className="text-3xl font-bold tracking-tight text-blue-400">Share Your Article/Story</CardTitle>
                            <CardDescription className="text-gray-400">Your journey can inspire thousands of fellow aspirants.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="space-y-2">
                                    <Label htmlFor="authorName">Full Name (Optional)</Label>
                                    <Input
                                        id="authorName"
                                        value={authorName}
                                        onChange={(e) => setAuthorName(e.target.value)}
                                        placeholder="Your name will be displayed with the story"
                                        className="bg-gray-800 border-gray-600"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="title">Story Title <span className="text-red-500">*</span></Label>
                                    <Input
                                        id="title"
                                        value={title}
                                        onChange={(e) => setTitle(e.target.value)}
                                        placeholder="e.g., How I Cleared SSC CGL in My First Attempt"
                                        required
                                        className="bg-gray-800 border-gray-600"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="content">Your Story <span className="text-red-500">*</span></Label>
                                    <Textarea
                                        id="content"
                                        value={content}
                                        onChange={(e) => setContent(e.target.value)}
                                        placeholder="Describe your preparation journey, challenges, and success..."
                                        required
                                        rows={12}
                                        className="bg-gray-800 border-gray-600"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="tips">Top 3 Tips for Aspirants (Optional)</Label>
                                    <Textarea
                                        id="tips"
                                        value={tips}
                                        onChange={(e) => setTips(e.target.value)}
                                        placeholder="1. Stay consistent...&#10;2. Practice mock tests...&#10;3. Revise regularly..."
                                        rows={4}
                                        className="bg-gray-800 border-gray-600"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="captcha">Anti-Spam Check: What is {captcha.num1} + {captcha.num2}?</Label>
                                    <Input
                                        id="captcha"
                                        type="number"
                                        value={captcha.answer}
                                        onChange={(e) => setCaptcha({ ...captcha, answer: e.target.value })}
                                        required
                                        className="bg-gray-800 border-gray-600 w-32"
                                    />
                                </div>
                                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isSubmitting}>
                                    {isSubmitting ? (
                                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...</>
                                    ) : (
                                        'Submit for Review'
                                    )}
                                </Button>
                            </form>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </>
    );
};

export default SubmitStoryPage;