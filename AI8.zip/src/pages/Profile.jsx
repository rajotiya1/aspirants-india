import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Loader2, Edit, Save, Lock, BookOpen, Briefcase, Eye, EyeOff,
  Award, Users, UserPlus, FileText, AlertCircle
} from 'lucide-react';
import SEO from '@/components/SEO';
import FriendshipButton from '@/components/FriendshipButton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SavedJobsTab from '@/components/profile/SavedJobsTab';
import TestPerformanceTab from '@/components/profile/TestPerformanceTab';
import EducationalDetailsTab from '@/components/profile/EducationalDetailsTab';
import AchievementsTab from '@/components/profile/AchievementsTab';
import { formatDate } from '@/lib/utils';
import { usePresence } from '@/contexts/PresenceContext';
import AvatarEditor from '@/components/profile/AvatarEditor';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import UserAvatar from '@/components/UserAvatar';
import ProfileContentLock from '@/components/ProfileContentLock';

const Profile = () => {
  const { userId } = useParams();
  const { user: currentUser, refreshProfile } = useAuth();
  const { toast } = useToast();
  const { onlineUsers } = usePresence();

  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});
  const [avatarToEdit, setAvatarToEdit] = useState(null);
  const [isFriend, setIsFriend] = useState(false);
  
  const isOwnProfile = currentUser?.id === userId;

  // ---------------- Fetch Profile & Friendship Status -----------------
  const fetchProfileData = useCallback(async () => {
    if (!userId || !currentUser) return;
    setLoading(true);

    try {
      // Fetch profile data
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profileError) {
        toast({ title: 'Error fetching profile', description: profileError.message, variant: 'destructive' });
        setProfile(null);
        setLoading(false);
        return;
      }

      // Parse privacy_settings if it's a string
      let parsedSettings = profileData.privacy_settings;
      if (typeof parsedSettings === 'string') {
        try {
          parsedSettings = JSON.parse(parsedSettings);
        } catch (e) {
          console.error("Failed to parse privacy settings:", e);
          parsedSettings = {}; // Fallback to default
        }
      }
      
      const finalProfile = { ...profileData, privacy_settings: parsedSettings };
      setProfile(finalProfile);

      setEditData({
        name: finalProfile.name || '',
        dob: finalProfile.dob || '',
        city: finalProfile.city || '',
        state: finalProfile.state || '',
        caste: finalProfile.caste || '',
        category: finalProfile.category || '',
        bio: finalProfile.bio || ''
      });

      // Fetch friendship status if not own profile
      if (!isOwnProfile) {
        const { data: friendData, error: friendError } = await supabase.rpc('is_friend', {
          uid1: currentUser.id,
          uid2: userId
        });
        if (friendError) throw friendError;
        setIsFriend(friendData);
      }
      
      // Debug logs
      console.log("Privacy Settings:", finalProfile.privacy_settings);
      console.log("isFriend:", isFriend);
      console.log("isOwnProfile:", isOwnProfile);

    } catch (error) {
      toast({ title: 'Error', description: 'Unexpected error occurred while fetching data.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [userId, currentUser, toast, isOwnProfile, isFriend]);

  useEffect(() => {
    fetchProfileData();
  }, [fetchProfileData]);

  // ---------------- Access Logic -----------------
  const canViewSection = (sectionKey) => {
    if (isOwnProfile) return true;
    const setting = profile?.privacy_settings?.[sectionKey] || "friends";
    if (setting === "public") return true;
    if (setting === "private") return isOwnProfile;
    if (setting === "friends") return isOwnProfile || isFriend;
    return false;
  };

  // ---------------- Profile Update -----------------
  const handleUpdateProfile = async () => {
    const { gotra, ...updateData } = editData;
    const { error } = await supabase.from('profiles').update(updateData).eq('id', userId);
    if (error) {
      toast({ title: 'Error updating profile', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Profile updated successfully.' });
      setIsEditing(false);
      await fetchProfileData();
      await refreshProfile();
    }
  };

  // ---------------- Avatar Edit -----------------
  const handleAvatarFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setAvatarToEdit(reader.result);
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const onEditorSave = async () => {
    setAvatarToEdit(null);
    await fetchProfileData();
    await refreshProfile();
  };

  // ---------------- Render -----------------
  if (loading) return <div className="flex justify-center items-center py-20"><Loader2 className="w-10 h-10 animate-spin text-primary" /></div>;
  if (!profile) return <Navigate to="/app/dashboard" />;

  const profileDetails = [
    { label: "Name", key: "name", editable: true },
    { label: "D.O.B.", key: "dob", editable: true, type: "date" },
    { label: "District", key: "city", editable: true },
    { label: "State", key: "state", editable: true },
    { label: "Town/City", key: "caste", editable: true },
    { label: "Aspirants", key: "category", editable: true },
  ];

  const tabItems = [
    { value: "saved_jobs", label: "Saved Jobs", icon: Briefcase, component: <SavedJobsTab userId={userId} /> },
    { value: "test_performance", label: "Test Performance", icon: Award, component: <TestPerformanceTab /> },
    { value: "educational_detail", label: "Educational Details", icon: BookOpen, component: <EducationalDetailsTab /> },
    { value: "govt_job_achievements", label: "Govt. Job Achievements", icon: Award, component: <AchievementsTab /> },
  ];

  return (
    <>
      <SEO title={`${isOwnProfile ? 'My Profile' : `${profile.name}'s Profile`}`} />
      {avatarToEdit && <AvatarEditor src={avatarToEdit} onSave={onEditorSave} onCancel={() => setAvatarToEdit(null)} />}

      <Card className="w-full">
        <CardHeader className="relative p-4 md:p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="relative group">
              <UserAvatar user={profile} className="w-24 h-24 md:w-32 md:h-32 border-4 border-wavy-navy text-4xl" />
              {isOwnProfile && (
                <label htmlFor="avatar-upload" className="absolute inset-0 bg-black/60 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 rounded-full cursor-pointer transition-opacity">
                  <Edit className="w-6 h-6" />
                  <input id="avatar-upload" type="file" className="hidden" onChange={handleAvatarFileChange} accept="image/png, image/jpeg, image/webp" />
                </label>
              )}
            </div>
            <div className="flex-grow w-full">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2">
                {profileDetails.map(({ label, key, type }) => (
                  <div key={key}>
                    <Label className="text-xs text-gray-500">{label}</Label>
                    {isEditing && isOwnProfile ? (
                      <Input name={key} value={editData[key] || ''} onChange={(e) => setEditData({ ...editData, [key]: e.target.value })} type={type || 'text'} className="h-8 text-sm" />
                    ) : (
                      <p className="font-semibold text-black">{profile[key] ? (type === 'date' ? formatDate(profile[key]) : profile[key]) : 'N/A'}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="mt-6">
        <Tabs defaultValue="saved_jobs" className="w-full">
          <TabsList className="flex flex-wrap h-auto justify-center gap-1 sm:gap-2 bg-gray-200">
            {tabItems.map(tab => (
              <TabsTrigger key={tab.value} value={tab.value} className="text-xs sm:text-sm flex-shrink-0 text-wavy-navy data-[state=active]:bg-wavy-navy data-[state=active]:text-white">
                <tab.icon className="w-4 h-4 mr-1 sm:mr-2" />{tab.label}
              </TabsTrigger>
            ))}
          </TabsList>

          {tabItems.map(tab => (
            <TabsContent key={tab.value} value={tab.value} className="mt-4">
              {canViewSection(tab.value) ? (
                tab.component
              ) : (
                <ProfileContentLock sectionName={tab.label} profileOwnerName={profile.name} />
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </>
  );
};

export default Profile;