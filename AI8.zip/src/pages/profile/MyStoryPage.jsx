
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
const MyStoryPage = () => {
  return <div className="p-4 h-full overflow-y-auto">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              My Story
            </div>
            <Button asChild size="sm">
                <Link to="/submit-story">Write a Story</Link>
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-8">
            <p>Your success stories will be shown on story page after approval.</p>
            <p className="text-sm mt-2">Share your journey with others!</p>
          </div>
        </CardContent>
      </Card>
    </div>;
};
export default MyStoryPage;
