// 📁 File: src/pages/profile/applied/AppliedJobsPage.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Briefcase } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import AppliedJobCard from '@/components/applied/AppliedJobCard';
import { useTargetUserId } from '@/hooks/useTargetUserId';
import { getMyAppliedJobsWithDetails } from '@/services/aspirantsApi';
import { AnimatePresence, motion } from 'framer-motion';
import { supabase } from '@/lib/supabase';

const AppliedJobsPage = () => {
  const { user } = useAuth();
  const targetUserId = useTargetUserId();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);

  const isOwner = user?.id === targetUserId;

  const fetchAppliedJobs = useCallback(async () => {
    if (!targetUserId) {
      setLoading(false);
      return;
    }
    setLoading(true);

    try {
      // Fetch profile (optional: just for name display)
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('name')
        .eq('id', targetUserId)
        .single();

      if (profileError && profileError.code !== 'PGRST116') throw profileError;
      if (profileData) setProfile(profileData);

      // Fetch applied jobs directly (public view allowed)
      const data = await getMyAppliedJobsWithDetails(targetUserId);
      setJobs(data || []);
    } catch (error) {
      toast({
        title: 'Error fetching applied jobs',
        description: error.message,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    fetchAppliedJobs();
  }, [fetchAppliedJobs]);

  const handleDeleteApplication = async (applicationId) => {
    if (!isOwner) return;
    try {
      const { error } = await supabase
        .from('asp_applications')
        .delete()
        .match({ id: applicationId, user_id: user.id });

      if (error) throw error;

      setJobs((prevJobs) => prevJobs.filter((job) => job.id !== applicationId));
      toast({
        title: 'Application Removed',
        description: 'Your job application has been successfully removed.',
      });
    } catch (err) {
      toast({
        title: 'Error',
        description: 'Failed to remove application. ' + err.message,
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-10">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <AnimatePresence>
        {jobs.length > 0 ? (
          jobs.map((jobData) => (
            <motion.div
              key={jobData.id}
              layout
              exit={{ opacity: 0, y: -20, transition: { duration: 0.3 } }}
            >
              <AppliedJobCard
                jobData={jobData}
                onDelete={isOwner ? handleDeleteApplication : null}
              />
            </motion.div>
          ))
        ) : (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center py-10 text-muted-foreground">
                <Briefcase className="mx-auto w-12 h-12 mb-4" />
                <p>No jobs applied for yet.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AppliedJobsPage;