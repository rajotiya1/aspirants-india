import React from 'react';
import TestPerformanceTab from '@/components/profile/TestPerformanceTab';

const TestPerformancePage = () => {
  return (
    <div className="max-w-4xl mx-auto p-4">
      <TestPerformanceTab />
    </div>
  );
};

export default TestPerformancePage;