import React from 'react';
import AchievementsTab from '@/components/profile/AchievementsTab';

const GovtJobAchievementPage = () => {
  return <AchievementsTab />;
};

export default GovtJobAchievementPage;