import React from 'react';
import EducationalDetailsTab from '@/components/profile/EducationalDetailsTab';

const EducationDetailPage = () => {
  return <EducationalDetailsTab />;
};

export default EducationDetailPage;