import React from 'react';
import MyProfileInfo from '@/pages/profile/MyProfileInfo';

const MyProfileWrapper = () => {
  return <MyProfileInfo />;
};

export default MyProfileWrapper;