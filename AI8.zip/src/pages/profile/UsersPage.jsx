import React from 'react';
import Users from '@/pages/Users';

const UsersPage = () => {
  return <div className="p-0 sm:p-4"><Users /></div>;
};

export default UsersPage;