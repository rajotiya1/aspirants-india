import React from 'react';
import SavedJobs from '@/pages/SavedJobs';

const SavedJobsPage = () => {
  return <SavedJobs />;
};

export default SavedJobsPage;