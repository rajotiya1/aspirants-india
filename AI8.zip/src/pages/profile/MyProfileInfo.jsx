import React, { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { useToast } from "@/components/ui/use-toast";
import { getFriendlyErrorMessage } from "@/lib/errorUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import LatestArticles from "@/components/LatestArticles";
import {
  Loader2,
  Edit,
  Save,
  Camera,
  Settings,
  Shield,
  Trash2
} from "lucide-react";
import SEO from "@/components/SEO";
import FriendshipButton from "@/components/FriendshipButton";
import AvatarEditor from "@/components/profile/AvatarEditor";
import UserAvatar from "@/components/UserAvatar";
import CoverUploader from "@/components/profile/CoverUploader";
import PrivacySettingsTab from "@/components/profile/PrivacySettingsTab";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "@/components/ui/alert-dialog";
import { useTargetUserId } from "@/hooks/useTargetUserId";

const indianStates = [
  "Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat",
  "Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh",
  "Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab",
  "Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh",
  "Uttarakhand","West Bengal","Andaman and Nicobar Islands","Chandigarh",
  "Dadra and Nagar Haveli and Daman and Diu","Delhi","Jammu and Kashmir",
  "Ladakh","Lakshadweep","Puducherry"
];

const aspirantOptions = [
  "All GOVT JOB",
  "UPSC",
  "SSC",
  "STATE PCS",
  "STATE GOVT JOB",
  "TEACHER"
];

const MyProfileInfo = () => {
  const { user: currentUser, signOut, authLoading, refreshProfile } = useAuth();
  const targetUserId = useTargetUserId();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editingAvatar, setEditingAvatar] = useState(null);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const avatarInputRef = useRef(null);
  const isOwnProfile = currentUser?.id === targetUserId;
  const { register, handleSubmit, control, setValue, formState: { isSubmitting } } = useForm();

  const fetchProfileData = useCallback(async () => {
    if (!targetUserId) {
      if (!authLoading) navigate("/login");
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", targetUserId)
        .single();
      if (error) {
        if (error.code !== "PGRST116") throw error;
        setProfile(null);
      } else {
        setProfile(data);
        if (data) {
          Object.keys(data).forEach((key) => {
            if (data[key]) setValue(key, data[key]);
          });
        }
      }
    } catch (err) {
      toast({
        title: "Error",
        description: getFriendlyErrorMessage(err),
        variant: "destructive"
      });
      setProfile(null);
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast, setValue, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading) fetchProfileData();
  }, [authLoading, fetchProfileData]);

  const onSubmit = async (data) => {
    const updateData = { ...data, updated_at: new Date().toISOString() };
    const { error } = await supabase
      .from("profiles")
      .update(updateData)
      .eq("id", targetUserId);

    if (error) {
      toast({
        title: "Error",
        description: getFriendlyErrorMessage(error),
        variant: "destructive"
      });
    } else {
      toast({
        title: "Success!",
        description: "Profile updated successfully."
      });
      setIsEditing(false);
      await fetchProfileData();
      await refreshProfile();
    }
  };

  const handleAvatarClick = () => {
    if (isOwnProfile) avatarInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setEditingAvatar(reader.result);
      reader.readAsDataURL(file);
    }
    event.target.value = null;
  };

  const handleAvatarSave = async () => {
    setEditingAvatar(null);
    await fetchProfileData();
    await refreshProfile();
  };

  const handleDeleteAccount = async () => {
    if (!currentUser) return;
    setIsDeleting(true);
    try {
      const { data, error: functionError } = await supabase.functions.invoke(
        "delete-account",
        { body: { userId: currentUser.id } }
      );
      if (functionError) throw functionError;
      if (data && data.error) throw new Error(data.error);

      toast({
        title: "✅ Account Deleted",
        description: "आपका अकाउंट सफलतापूर्वक डिलीट कर दिया गया है।"
      });
      await signOut();
      navigate("/login");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "❌ Deletion Failed",
        description: getFriendlyErrorMessage(error)
      });
    } finally {
      setIsDeleting(false);
      setIsDialogOpen(false);
    }
  };

  if (loading || authLoading)
    return (
      <div className="flex justify-center items-center h-full pt-10">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );

  if (!profile)
    return (
      <div className="text-center py-20 text-lg text-muted-foreground">
        Profile नहीं मिला या हटा दिया गया।
      </div>
    );

  return (
    <>
      <SEO
        title={`${profile.name || "User"}'s Profile`}
        description="View user profile information."
      />

      <div className="w-full pb-16">
        <CoverUploader profile={profile} onUploadComplete={fetchProfileData} />

        <div className="relative px-6">
          <div
            className="absolute -bottom-14 left-6 w-28 h-28 sm:w-32 sm:h-32 rounded-full border-4 border-background shadow-lg group cursor-pointer bg-white overflow-hidden"
            onClick={handleAvatarClick}
          >
            <UserAvatar
              user={profile}
              className="!w-full !h-full rounded-full object-cover"
            />
            {isOwnProfile && (
              <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-6 h-6 text-white" />
              </div>
            )}
          </div>
        </div>

        <div className="pt-16 px-6 pb-6">
          {isEditing ? (
            <Input
              defaultValue={profile.name}
              {...register("name", { required: true })}
              className="text-2xl font-bold"
            />
          ) : (
            <h1 className="text-2xl font-bold text-foreground">
              {profile.name || "N/A"}
            </h1>
          )}

          <div className="mt-4">
            {isEditing ? (
              <>
                <Label
                  htmlFor="bio-textarea"
                  className="text-xs text-muted-foreground"
                >
                  Bio
                </Label>
                <Textarea
                  id="bio-textarea"
                  defaultValue={profile.bio}
                  {...register("bio")}
                  placeholder="Write something about yourself..."
                  className="mt-1"
                />
              </>
            ) : (
              <p className="text-sm text-muted-foreground italic">
                {profile.bio || "No bio yet."}
              </p>
            )}
          </div>

          <div className="mt-6">
            <form onSubmit={handleSubmit(onSubmit)}>
              {/* --- form fields unchanged --- */}
              <div className="bg-card p-4 rounded-lg border">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  <div>
                    <Label className="text-xs text-muted-foreground mb-1">
                      District
                    </Label>
                    {isEditing ? (
                      <Input
                        defaultValue={profile.district}
                        {...register("district")}
                      />
                    ) : (
                      <p className="font-semibold text-sm">
                        {profile.district || "N/A"}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground mb-1">
                      State
                    </Label>
                    {isEditing ? (
                      <Controller
                        name="state"
                        control={control}
                        defaultValue={profile.state}
                        render={({ field }) => (
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select State" />
                            </SelectTrigger>
                            <SelectContent>
                              {indianStates.map((s) => (
                                <SelectItem key={s} value={s}>
                                  {s}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      />
                    ) : (
                      <p className="font-semibold text-sm">
                        {profile.state || "N/A"}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground mb-1">
                      City
                    </Label>
                    {isEditing ? (
                      <Input
                        defaultValue={profile.city}
                        {...register("city")}
                      />
                    ) : (
                      <p className="font-semibold text-sm">
                        {profile.city || "N/A"}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label className="text-xs text-muted-foreground mb-1">
                      Village
                    </Label>
                    {isEditing ? (
                      <Input
                        defaultValue={profile.village}
                        {...register("village")}
                      />
                    ) : (
                      <p className="font-semibold text-sm">
                        {profile.village || "N/A"}
                      </p>
                    )}
                  </div>

                  <div className="sm:col-span-2">
                    <Label className="text-xs text-muted-foreground mb-1">
                      Aspirant For
                    </Label>
                    {isEditing ? (
                      <Controller
                        name="aspirants"
                        control={control}
                        defaultValue={profile.aspirants}
                        render={({ field }) => (
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Aspirant Type" />
                            </SelectTrigger>
                            <SelectContent>
                              {aspirantOptions.map((s) => (
                                <SelectItem key={s} value={s}>
                                  {s}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      />
                    ) : (
                      <p className="font-semibold text-sm">
                        {profile.aspirants || "N/A"}
                      </p>
                    )}
                  </div>

                </div>
              </div>

              <div className="flex gap-4 justify-center pt-6">
                {isOwnProfile ? (
                  <>
                    <Button
                      type="button"
                      onClick={() => setIsEditing(!isEditing)}
                      variant={isEditing ? "secondary" : "outline"}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      {isEditing ? "Cancel" : "Edit Profile"}
                    </Button>
                    {isEditing && (
                      <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Save className="w-4 h-4 mr-2" />
                        )}
                        Save Changes
                      </Button>
                    )}
                  </>
                ) : (
                  <FriendshipButton
                    profileId={targetUserId}
                    onStatusChange={fetchProfileData}
                  />
                )}
              </div>
            </form>
          </div>

          {isOwnProfile && (
            <>
              <div className="mt-12 pt-8 border-t border-destructive/50 border-dashed">
                <h3 className="text-lg font-bold text-destructive mb-4 text-center">
                  ⚙️ Account Settings
                </h3>

                <div className="flex justify-center">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button className="bg-gray-800 text-white hover:bg-gray-700 px-5">
                        <Settings className="w-4 h-4 mr-2" /> Settings
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="center" className="w-56">
                      <DropdownMenuLabel>Profile Settings</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => setShowPrivacy(true)}>
                        <Shield className="w-4 h-4 mr-2 text-blue-600" /> Privacy
                        Settings
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setIsDialogOpen(true)}>
                        <Trash2 className="w-4 h-4 mr-2 text-red-600" /> Delete
                        Account
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {showPrivacy && (
                  <div className="mt-6 border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-semibold text-gray-800">
                        Privacy Settings
                      </h4>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowPrivacy(false)}
                      >
                        बंद करें ✖
                      </Button>
                    </div>
                    <PrivacySettingsTab />
                  </div>
                )}
              </div>

              {/* Alert Dialog kept OUTSIDE the dropdown */}
              <AlertDialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>
                      क्या आप वाकई अकाउंट डिलीट करना चाहते हैं?
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      यह कार्रवाई वापस नहीं की जा सकती।
                      आपका पूरा डेटा (Jobs, Tests, Stories आदि) स्थायी रूप से हटा दिया जाएगा।
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>रद्द करें</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDeleteAccount}
                      disabled={isDeleting}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      {isDeleting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />{" "}
                          Deleting...
                        </>
                      ) : (
                        "हाँ, डिलीट करें"
                      )}
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </>
          )}
        </div>
      </div>

      {/* 🔵 Success Stories / Latest Articles Section INSERTED HERE */}
      <div className="mt-10 px-6">
        <LatestArticles />
      </div>

      <input
        type="file"
        ref={avatarInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
      />

      {editingAvatar && (
        <AvatarEditor
          src={editingAvatar}
          onSave={handleAvatarSave}
          onCancel={() => setEditingAvatar(null)}
        />
      )}
    </>
  );
};

export default MyProfileInfo;