import React, { useState, useEffect, useCallback } from 'react';
import { Search, Plus, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SEO from '@/components/SEO';
import { useToast } from "@/components/ui/use-toast";
import { useDebounce } from '@/hooks/useDebounce';
import { fetchAspJobs } from '@/services/aspirantsApi';
import AspirantJobModal from '@/components/AspirantJobModal';
import CreateSurveyModal from '@/components/aspirants/CreateSurveyModal';
import { Button } from '@/components/ui/button';

// Survey Button component
const AspirantButton = ({ title, subtitle, gradient, onClick }) => (
  <motion.button
    onClick={onClick}
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.2 }}
    whileHover={{ scale: 1.02, y: -2 }}
    whileTap={{ scale: 0.98 }}
    className={`w-full text-white font-semibold py-3 px-4 rounded-2xl shadow-lg transition-all duration-200 mb-4 ${gradient}`}
  >
    <span className="block text-base">{title}</span>
    <span className="block text-xs font-normal opacity-80">{subtitle}</span>
  </motion.button>
);

const Aspirants = () => {
  const [jobSurveys, setJobSurveys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [page, setPage] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  const { toast } = useToast();
  const [selectedJob, setSelectedJob] = useState(null);
  const [isAspirantModalOpen, setIsAspirantModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Button gradients
  const gradients = [
    'bg-gradient-to-r from-teal-400 to-cyan-500',
    'bg-gradient-to-r from-cyan-500 to-blue-500',
    'bg-gradient-to-r from-blue-500 to-indigo-500',
    'bg-gradient-to-r from-indigo-500 to-purple-500'
  ];

  // Load Surveys
  const loadJobs = useCallback(async (currentPage, search) => {
    if (currentPage === 0) setLoading(true);
    else setLoadingMore(true);

    try {
      const { data, count } = await fetchAspJobs({ searchTerm: search, page: currentPage });

      const formattedData = data.map((job, index) => ({
        id: job.id,
        title: job.job_name,
        subtitle: job.authority,
        gradient: gradients[(currentPage * 15 + index) % gradients.length]
      }));

      setJobSurveys(prev => currentPage === 0 ? formattedData : [...prev, ...formattedData]);
      setHasMore((currentPage + 1) * 15 < count);

    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error fetching job surveys",
        description: error.message,
      });
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [toast]);

  // Re-load when search changes
  useEffect(() => {
    setPage(0);
    setJobSurveys([]);
    setHasMore(true);
    loadJobs(0, debouncedSearchTerm);
  }, [debouncedSearchTerm, loadJobs]);

  const handleLoadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    loadJobs(nextPage, debouncedSearchTerm);
  };

  const handleJobClick = (job) => {
    setSelectedJob(job);
    setIsAspirantModalOpen(true);
  };

  return (
    <>
      <SEO
        title="Nos. of Aspirants - Job Survey"
        description="Know the competition for your job or post. See how many aspirants applied."
      />

      {/* MAIN LAYOUT */}
      <div className="min-h-screen sm:min-h-0 sm:p-4 flex flex-col items-center bg-gray-50">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative w-full h-full sm:h-auto sm:max-w-sm p-6 pb-6 flex flex-col bg-white sm:rounded-2xl border border-gray-200 shadow-2xl"
        >

          {/* HEADING + SLIM BUTTON (Under heading) */}
          <h1 className="text-center text-2xl font-bold text-blue-600 mb-1">
            Nos. of Aspirants
          </h1>

          <Button
            onClick={() => setIsCreateModalOpen(true)}
            className="w-full mb-5 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold py-2 text-sm rounded-lg shadow-md"
          >
            <Plus className="w-4 h-4 mr-1" /> Create New Job-Survey
          </Button>

          <p className="text-center text-gray-500 text-xs mb-6">
            Know competition by Job / Post / Category / State
          </p>

          {/* SEARCH BAR */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by job or authority..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-100 border border-gray-300 rounded-full py-3 pl-12 pr-4 text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* LIST AREA */}
          <div className="flex-grow overflow-y-auto no-scrollbar">
            {loading ? (
              <div className="flex justify-center items-center h-48">
                <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
              </div>
            ) : (
              <AnimatePresence>
                {jobSurveys.length > 0 ? (
                  jobSurveys.map((job) => (
                    <AspirantButton key={job.id} {...job} onClick={() => handleJobClick(job)} />
                  ))
                ) : (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center text-gray-400 py-10">
                    No jobs found.
                  </motion.div>
                )}
              </AnimatePresence>
            )}

            {loadingMore && (
              <div className="flex justify-center items-center py-4">
                <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
              </div>
            )}

            {!loading && hasMore && !loadingMore && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                <Button onClick={handleLoadMore} variant="secondary" className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800">
                  Load More
                </Button>
              </motion.div>
            )}
          </div>

        </motion.div>
      </div>

      {/* MODALS */}
      <AspirantJobModal
        job={selectedJob}
        isOpen={isAspirantModalOpen}
        onClose={() => setIsAspirantModalOpen(false)}
      />

      <CreateSurveyModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </>
  );
};

export default Aspirants;