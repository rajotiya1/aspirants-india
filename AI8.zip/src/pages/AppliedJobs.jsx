import React, { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getMyAppliedJobsWithDetails, deleteAspirantApplication } from '@/services/aspirantsApi';
import { Loader2, ServerCrash, FileSearch, ClipboardCheck } from 'lucide-react';
import SEO from '@/components/SEO';
import AppliedJobCard from '@/components/applied/AppliedJobCard';
import { AnimatePresence, motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useBadges } from '@/contexts/BadgeContext';
import { useToast } from '@/components/ui/use-toast';

const AppliedJobs = () => {
  const { user } = useAuth();
  const { markAsSeen } = useBadges();
  const [appliedJobs, setAppliedJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    markAsSeen('applied_jobs');
  }, [markAsSeen]);

  const fetchJobs = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const jobs = await getMyAppliedJobsWithDetails(user.id);
      setAppliedJobs(jobs || []);
    } catch (err) {
      setError('Failed to load your applied jobs. Please try again later.');
      console.error("Failed to load applied jobs", err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleDeleteApplication = async (applicationId) => {
    try {
      await deleteAspirantApplication(applicationId, user.id);
      setAppliedJobs(prevJobs => prevJobs.filter(job => job.id !== applicationId));
      toast({
        title: "Application Removed",
        description: "Your job application has been successfully removed.",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to remove application. " + err.message,
        variant: "destructive",
      });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      },
    },
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex flex-col justify-center items-center h-full text-muted-foreground py-10">
          <Loader2 className="w-10 h-10 animate-spin text-primary" />
          <p className="mt-4 text-lg">Loading Your Applied Jobs...</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col justify-center items-center h-full text-center text-destructive bg-destructive/10 p-8 rounded-2xl">
          <ServerCrash className="w-12 h-12 mb-4" />
          <h3 className="text-xl font-bold mb-2">Oops! Something went wrong.</h3>
          <p>{error}</p>
          <button onClick={fetchJobs} className="mt-6 bg-destructive/20 hover:bg-destructive/30 font-bold py-2 px-4 rounded-lg transition-colors">
            Try Again
          </button>
        </div>
      );
    }

    if (appliedJobs.length === 0) {
      return (
        <div className="flex flex-col justify-center items-center h-full text-center text-muted-foreground py-10">
          <FileSearch className="w-16 h-16 mb-4" />
          <h3 className="text-2xl font-bold mb-2">No Applied Jobs Found</h3>
          <p>You haven't applied for any job surveys yet.</p>
        </div>
      );
    }

    return (
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-6"
      >
        <AnimatePresence>
          {appliedJobs.map(job => (
            <motion.div key={job.id} layout variants={itemVariants} exit={{ opacity: 0, y: -20, transition: { duration: 0.3 } }}>
              <AppliedJobCard jobData={job} onDelete={handleDeleteApplication} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    );
  };

  return (
    <>
      <SEO
        title="My Applied Jobs"
        description="View the status and details of all the job surveys you have applied for."
      />
      <div className="bg-gray-50 p-4 rounded-lg">
        <Card className="bg-transparent shadow-none border-none">
          <CardHeader>
              <CardTitle className="text-blue-600 flex items-center gap-2 text-lg">
                  <ClipboardCheck />
                  Applied Jobs
              </CardTitle>
          </CardHeader>
          <CardContent>
              <AnimatePresence mode="wait">
                  <motion.div
                    key={loading ? 'loading' : error ? 'error' : 'content'}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    {renderContent()}
                  </motion.div>
              </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </>
  );
};

export default AppliedJobs;