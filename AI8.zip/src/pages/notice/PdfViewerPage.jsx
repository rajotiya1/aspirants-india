// ===========================================================
// FINAL STABLE PDF VIEWER for WEB + APP (WebViewGold)
// - Mobile (WebView): In-app PDF viewing via Google Docs + Download Button
// - Desktop: Inline Native PDF Viewer
// - Download Action: Opens in Chrome (Intent) + Auto-closes viewer
// ===========================================================

import React, { useEffect, useMemo, useState, useCallback } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/lib/customSupabaseClient";
import SEO from "@/components/SEO";
import { normalizeUrl, formatDate } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Loader2,
  AlertTriangle,
  Download,
  ArrowLeft,
  Home,
  ExternalLink
} from "lucide-react";
import WebViewAdBanner from "@/components/WebViewAdBanner";
import { isWebViewGold } from "@/lib/admob";

// --- Supabase helpers ---
const isSupabasePublic = (url) =>
  typeof url === "string" &&
  url.includes(".supabase.co/storage/v1/object/public/");

const addDownloadParam = (url, filename) =>
  url +
  (url.includes("?") ? "&" : "?") +
  "download=" +
  encodeURIComponent(filename);

const PdfViewerPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // --------------------------------------------------------
  // FETCH JOB DATA
  // --------------------------------------------------------
  useEffect(() => {
    let active = true;

    (async () => {
      setLoading(true);

      // Try fetching from V2 table first
      const { data, error } = await supabase
        .from("jobs_public_v2")
        .select("*")
        .eq("id", id)
        .single();

      if (!active) return;

      if (error || !data) {
        setError("Job notification not found.");
        setLoading(false);
        return;
      }

      setJob(data);
      setLoading(false);
    })();

    return () => {
      active = false;
    };
  }, [id]);

  // --------------------------------------------------------
  // PDF URL COMPUTATION
  // --------------------------------------------------------
  const pdfUrl = job ? normalizeUrl(job.pdf_url || job.notification_pdf) : null;

  const fileName = useMemo(
    () => `${(job?.name_of_post || "notice").replace(/\s+/g, "_")}.pdf`,
    [job?.name_of_post]
  );

  // Mobile Viewer URL: Use Google Docs Viewer to render inside iframe
  // This prevents auto-downloading and allows in-app viewing
  const googleDocsUrl = useMemo(() => {
    if (!pdfUrl) return null;
    return `https://docs.google.com/gview?embedded=true&url=${encodeURIComponent(pdfUrl)}`;
  }, [pdfUrl]);

  // --------------------------------------------------------
  // ACTIONS
  // --------------------------------------------------------

  // Handle Download: Open in Chrome & Close Viewer (Mobile)
  const handleDownloadAndClose = useCallback(() => {
    if (!pdfUrl) return;

    // 1. Prepare URL with download param if it's Supabase
    const downloadUrl = isSupabasePublic(pdfUrl)
      ? addDownloadParam(pdfUrl, fileName)
      : pdfUrl;

    if (isWebViewGold()) {
      // 2. Use Android Intent to force Chrome
      const cleanUrl = downloadUrl.replace(/^https?:\/\//, "");
      window.location.href = `intent://${cleanUrl}#Intent;scheme=https;package=com.android.chrome;end`;

      // 3. Auto-close the viewer to return user to job list
      // Small delay ensures the intent fires before navigation
      setTimeout(() => {
        navigate(-1);
      }, 1000);
    } else {
      // Fallback for standard mobile browsers
      window.open(downloadUrl, "_blank");
    }
  }, [pdfUrl, fileName, navigate]);

  // Desktop: Open in new tab
  const handleOpenNewTab = () => {
    if (pdfUrl) window.open(pdfUrl, "_blank");
  };

  // --------------------------------------------------------
  // RENDER
  // --------------------------------------------------------
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-10 text-center">
        <AlertTriangle className="mx-auto h-12 w-12 text-destructive" />
        <h1 className="mt-4 text-2xl font-bold">Error</h1>
        <p className="mt-2 text-muted-foreground">{error}</p>

        <div className="mt-6 flex gap-3 justify-center">
          <Button variant="secondary" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <SEO title={job?.name_of_post} description="Official Job PDF Viewer" />

      {/* Optional Ad Banner */}
      {isWebViewGold() && <WebViewAdBanner />}

      <div className="flex flex-col h-screen bg-background">
        {/* TOP HEADER */}
        <div className="flex items-center p-3 border-b bg-white shadow-sm z-10 shrink-0">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="mr-2 shrink-0">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-semibold truncate pr-2">
              {job?.name_of_post}
            </h1>
          </div>
        </div>

        {/* MAIN CONTENT AREA */}
        <div className="flex-1 relative bg-gray-100 overflow-hidden">
          {!pdfUrl ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground p-4">
              <AlertTriangle className="h-10 w-10 mb-4 text-yellow-500" />
              <p>PDF is not available.</p>
            </div>
          ) : (
            <>
              {/* MOBILE: Google Docs Viewer Iframe */}
              <div className="md:hidden absolute inset-0 w-full h-full">
                <iframe
                  src={googleDocsUrl}
                  className="w-full h-full border-0"
                  title="PDF Viewer"
                />
              </div>

              {/* DESKTOP: Native Object Viewer */}
              <div className="hidden md:block w-full h-full p-6">
                <div className="w-full h-full bg-white rounded-lg shadow border overflow-hidden">
                  <object
                    data={pdfUrl}
                    type="application/pdf"
                    width="100%"
                    height="100%"
                  >
                    <div className="flex flex-col items-center justify-center h-full space-y-4 p-4">
                      <p>Your browser does not support inline PDF viewing.</p>
                      <Button onClick={handleOpenNewTab}>Download PDF</Button>
                    </div>
                  </object>
                </div>
              </div>
            </>
          )}
        </div>

        {/* FOOTER ACTIONS */}
        {pdfUrl && (
          <div className="shrink-0 bg-white border-t p-4 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] z-20">
            <div className="max-w-2xl mx-auto">

              {/* MOBILE BUTTONS */}
              <div className="md:hidden w-full">
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleDownloadAndClose}
                  size="lg"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download & Go Back
                </Button>
                <p className="text-[10px] text-center text-gray-400 mt-2">
                  Opens external browser for file download
                </p>
              </div>

              {/* DESKTOP BUTTONS */}
              <div className="hidden md:flex w-full gap-3 justify-center">
                <Button variant="outline" onClick={handleOpenNewTab}>
                  <ExternalLink className="mr-2 h-4 w-4" /> Open in New Tab
                </Button>
              </div>

            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default PdfViewerPage;