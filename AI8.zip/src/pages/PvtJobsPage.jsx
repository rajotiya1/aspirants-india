import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import SEO from '@/components/SEO';
import { fetchStates } from '@/api/states';
import { useDebounce } from '@/hooks/useDebounce';
import JobList from '@/components/pvt_jobs/JobList';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import { Button } from '@/components/ui/button';

const SearchableSelect = ({ options, value, onSelect, placeholder }) => {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
        >
          {value
            ? options.find((option) => option.value === value)?.label
            : placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
        <Command>
          <CommandInput placeholder="Search..." />
          <CommandList>
            <CommandEmpty>No results found.</CommandEmpty>
            <CommandGroup>
              {options.map((option) => (
                <CommandItem
                  key={option.value}
                  value={option.value}
                  onSelect={(currentValue) => {
                    onSelect(currentValue === value ? "" : currentValue);
                    setOpen(false);
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === option.value ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {option.label}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

const jobCategories = ['Sitting', 'Field', 'Teaching'];

const PvtJobsPage = () => {
  const [jobsByCategory, setJobsByCategory] = useState({ Sitting: [], Field: [], Teaching: [] });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Sitting');
  
  const [keywords, setKeywords] = useState('');
  const [district, setDistrict] = useState('');
  const [state, setState] = useState('');
  
  const debouncedKeywords = useDebounce(keywords, 300);
  const debouncedDistrict = useDebounce(district, 300);

  const [stateOptions, setStateOptions] = useState([]);
  const { toast } = useToast();
  const swiperRef = useRef(null);
  const tabsRef = useRef(null);

  useEffect(() => {
    const getStates = async () => {
      try {
        const options = await fetchStates();
        setStateOptions(options);
      } catch (error) {
        console.error("Error fetching states:", error);
      }
    };
    getStates();
  }, []);
  
  const fetchJobs = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('private_jobs')
      .select('*')
      .order('created_at', { ascending: false });

    if (debouncedKeywords) {
      query = query.or(`job_name.ilike.%${debouncedKeywords}%,qualification.ilike.%${debouncedKeywords}%`);
    }
    if (debouncedDistrict) {
      query = query.ilike('district', `%${debouncedDistrict}%`);
    }
    if (state && state !== 'all') {
      query = query.eq('state', state);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching private jobs:', error);
      toast({
        variant: 'destructive',
        title: 'Jobs लोड नहीं हो सकीं',
        description: 'कृपया बाद में पुन: प्रयास करें।',
      });
      setJobsByCategory({ Sitting: [], Field: [], Teaching: [] });
    } else {
      const categorized = { Sitting: [], Field: [], Teaching: [] };
      data.forEach(job => {
        if (categorized[job.job_category]) {
          categorized[job.job_category].push(job);
        }
      });
      setJobsByCategory(categorized);
    }
    setLoading(false);
  }, [toast, debouncedKeywords, debouncedDistrict, state]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleTabChange = (value) => {
    const tabIndex = jobCategories.indexOf(value);
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slideTo(tabIndex);
    }
  };

  const handleSlideChange = (swiper) => {
    const newActiveTab = jobCategories[swiper.activeIndex];
    setActiveTab(newActiveTab);
    const activeButton = tabsRef.current?.children[swiper.activeIndex];
    if (activeButton) {
      activeButton.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  };

  return (
    <>
      <SEO
        title="Private Jobs | Aspirants India"
        description="Find the latest private sector job openings. Search and apply for private jobs across various industries."
        keywords="private jobs, pvt jobs, sitting jobs, field jobs, teaching jobs"
      />
      <div className="container mx-auto px-4 py-4 flex-grow flex flex-col">
        <Card className="p-4 mb-4 shadow-sm">
           <div className="flex flex-col gap-4">
             <Input
                type="text"
                placeholder="Keywords (e.g. Driver, Teacher)"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                className="w-full"
              />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <SearchableSelect
                options={stateOptions}
                value={state}
                onSelect={setState}
                placeholder="Select State"
              />
              <Input
                type="text"
                placeholder="District (e.g. Hisar)"
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="w-full"
              />
            </div>
          </div>
        </Card>

        <div className="p-2 bg-muted">
          <div ref={tabsRef} className="flex items-center space-x-2 overflow-x-auto no-scrollbar">
            {jobCategories.map((category, index) => (
              <button
                key={category}
                onClick={() => handleTabChange(category)}
                className={cn(
                  'shrink-0 whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition-all duration-200',
                  activeTab === category
                    ? 'bg-primary text-primary-foreground shadow-md'
                    : 'bg-background text-muted-foreground hover:bg-secondary'
                )}
              >
                {category} Job
              </button>
            ))}
          </div>
        </div>
          
          {loading ? (
            <div className="flex justify-center items-center h-64 flex-grow">
              <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
          ) : (
            <div className="flex-grow mt-4">
              <Swiper
                ref={swiperRef}
                onSlideChange={handleSlideChange}
                className="h-full"
              >
                {jobCategories.map(category => (
                  <SwiperSlide key={category}>
                    <motion.div
                      key={category}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className="h-full overflow-y-auto"
                    >
                      <JobList jobs={jobsByCategory[category]} />
                    </motion.div>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          )}
      </div>
    </>
  );
};

export default PvtJobsPage;