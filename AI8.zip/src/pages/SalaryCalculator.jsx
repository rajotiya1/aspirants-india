
import React, { useState, useEffect } from 'react';
import SEO from '@/components/SEO';
import SalaryForm from '@/components/salary/SalaryForm';
import SalaryResults from '@/components/salary/SalaryResults';
import { Button } from '@/components/ui/button';
import { ChevronLeft, Calculator } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SalaryCalculator = () => {
  const navigate = useNavigate();
  
  // State for form inputs
  const [formData, setFormData] = useState({
    basic: 0,
    daPercent: 50,
    hraPercent: 18,
    ta: 0,
    others: 0,
    pf: 0,
    pt: 0,
    it: 0,
    deductions: 0
  });

  // State for calculated results
  const [results, setResults] = useState({
    basic: 0,
    daAmount: 0,
    hraAmount: 0,
    gross: 0,
    totalDeductions: 0,
    net: 0,
    annual: 0,
    daPercent: 0,
    hraPercent: 0,
    ta: 0,
    others: 0,
    pf: 0,
    pt: 0,
    it: 0,
    deductions: 0
  });

  // Presets for quick filling
  const presets = {
    central: { daPercent: 50, hraPercent: 27 }, // 7th CPC X City
    state_x: { daPercent: 46, hraPercent: 24 },
    state_y: { daPercent: 46, hraPercent: 16 },
    bank: { daPercent: 48.51, hraPercent: 10 }, // Approx
    custom: { daPercent: 0, hraPercent: 0 }
  };

  const handlePresetChange = (value) => {
    if (presets[value]) {
      setFormData(prev => ({
        ...prev,
        ...presets[value]
      }));
    }
  };

  const handleInputChange = (name, value) => {
    setFormData(prev => ({
      ...prev,
      [name]: value === '' ? 0 : value
    }));
  };

  // Real-time calculation effect
  useEffect(() => {
    const basic = parseFloat(formData.basic) || 0;
    const daPercent = parseFloat(formData.daPercent) || 0;
    const hraPercent = parseFloat(formData.hraPercent) || 0;
    const ta = parseFloat(formData.ta) || 0;
    const others = parseFloat(formData.others) || 0;
    const pf = parseFloat(formData.pf) || 0;
    const pt = parseFloat(formData.pt) || 0;
    const it = parseFloat(formData.it) || 0;
    const otherDeductions = parseFloat(formData.deductions) || 0;

    const daAmount = (basic * daPercent) / 100;
    const hraAmount = (basic * hraPercent) / 100;

    const gross = basic + daAmount + hraAmount + ta + others;
    const totalDeductions = pf + pt + it + otherDeductions;
    const net = Math.max(0, gross - totalDeductions);
    const annual = net * 12;

    setResults({
      basic,
      daPercent,
      hraPercent,
      daAmount,
      hraAmount,
      ta,
      others,
      pf,
      pt,
      it,
      deductions: otherDeductions,
      gross,
      totalDeductions,
      net,
      annual
    });
  }, [formData]);

  return (
    <div className="min-h-screen bg-slate-50 pb-10">
      <SEO 
        title="Government Salary Calculator | 7th Pay Commission"
        description="Calculate your in-hand salary with our free Government Salary Calculator. Supports 7th Pay Commission, State Govt, and Bank salary structures."
      />
      
      {/* Header */}
      <div className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ChevronLeft className="w-6 h-6 text-slate-600" />
            </Button>
            <div className="flex items-center gap-2 text-slate-800 font-bold text-lg">
              <Calculator className="w-6 h-6 text-primary" />
              <h1>Salary Calculator</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Input Form Section */}
          <div className="lg:col-span-7 order-2 lg:order-1">
            <SalaryForm 
              values={formData} 
              onChange={handleInputChange} 
              onPresetChange={handlePresetChange}
            />
          </div>

          {/* Results Section */}
          <div className="lg:col-span-5 order-1 lg:order-2">
            <div className="sticky top-24">
               <SalaryResults results={results} />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default SalaryCalculator;
