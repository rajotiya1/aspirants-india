import React, { useState, useMemo, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, ChevronDown, ChevronUp } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";
import SEO from "@/components/SEO";
import { useBadges } from "@/contexts/BadgeContext";

const Result = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState(null);

  const { toast } = useToast();
  const { markAsSeen } = useBadges();

  useEffect(() => {
    markAsSeen("result");
  }, [markAsSeen]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const { data: results, error } = await supabase
        .from("results")
        .select("*")
        .order("created_at", { ascending: false }); // latest first

      if (error) {
        toast({
          title: "Error fetching results",
          description: error.message,
          variant: "destructive",
        });
      } else {
        setData(results || []);
      }
      setLoading(false);
    };
    fetchData();
  }, [toast]);

  // search filter
  const filteredData = useMemo(() => {
    if (!searchTerm) return data;
    return data.filter(
      (item) =>
        (item.heading || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.description || "").toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, data]);

  const toggleRow = (id) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <>
      <SEO
        title="Exam Results"
        description="Check the latest results for various government exams. Search for your exam result and get direct links to download."
        keywords="exam results, sarkari result, government exam results, job results"
      />

      <div className="space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card>
            <CardHeader>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search for a result..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardHeader>

            <CardContent className="divide-y">
              {loading ? (
                <div className="text-center py-8 text-blue-600">Loading...</div>
              ) : filteredData.length > 0 ? (
                filteredData.map((item) => (
                  <div key={item.id} className="py-3">
                    {/* Heading Row with Date */}
                    <div
                      onClick={() => toggleRow(item.id)}
                      className="cursor-pointer flex justify-between items-center font-bold text-base text-blue-800 hover:bg-gray-100 px-2 py-2 rounded"
                    >
                      <div className="flex flex-col w-full">
                        <div className="flex justify-between items-center">
                          {item.heading}
                          {openId === item.id ? (
                            <ChevronUp className="h-5 w-5 text-gray-600" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-gray-600" />
                          )}
                        </div>
                        {/* 👇 Date Line */}
                        <div className="text-sm text-gray-500 mt-1">
                          Updated on:{" "}
                          {new Date(item.created_at).toLocaleDateString(
                            "en-IN",
                            {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                            }
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Expanded Content */}
                    {openId === item.id && (
                      <motion.div
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        className="mt-2 px-2 text-gray-700"
                      >
                        <p>{item.description}</p>
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700"
                        >
                          View Result
                        </a>
                      </motion.div>
                    )}
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No results found.
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </>
  );
};

export default Result;