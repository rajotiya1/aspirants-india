import React from 'react';
import SEO from '@/components/SEO';
import SpecialJobListing from '@/components/special-jobs/SpecialJobListing';

const ForeignJobsPage = () => {
  return (
    <>
      <SEO
        title="Foreign Jobs"
        description="Explore international job opportunities. Find and apply for jobs abroad."
        ogTitle="Foreign Jobs | Aspirants India"
        ogDescription="Your gateway to finding jobs in foreign countries."
      />
      <div className="flex-1">
        <h1 className="text-3xl font-bold text-center my-6 text-foreground">Foreign Jobs</h1>
        <SpecialJobListing
          tableName="foreign_jobs"
          pageTitle="Foreign Jobs"
          badgeKey="foreign_jobs"
        />
      </div>
    </>
  );
};

export default ForeignJobsPage;