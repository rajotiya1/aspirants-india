import React from "react";
import OnlineTests from "@/pages/OnlineTests";

const SpecialBatch1 = () => {
  const batchCategories = [
    {
      name: "Static GK",                     // UI Title
      tableName: "special_batch_1_static_gk", // Supabase Table
      shortName: "Static GK"              // Leaderboard key
    }
  ];

  return <OnlineTests externalCategories={batchCategories} />;
};

export default SpecialBatch1;