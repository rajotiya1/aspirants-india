
import React, { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import ResumeForm from "@/components/resume/ResumeForm";
import ResumePreview from "@/components/resume/ResumePreview";
import TemplateSelector from "@/components/resume/TemplateSelector";
import PDFExport from "@/components/resume/PDFExport";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SEO from "@/components/SEO";
import AppShell from "@/app/AppShell"; // ✔ FIXED IMPORT

const ResumeBuilder = () => {
  const navigate = useNavigate();
  const [activeTemplate, setActiveTemplate] = useState("modern");

  const [resumeData, setResumeData] = useState({
    personal: {
      name: "",
      title: "",
      email: "",
      phone: "",
      address: "",
      linkedin: "",
    },
    summary: "",
    education: [],
    experience: [],
    skills: "",
    projects: [],
    languages: "",
    hobbies: "",
    photo: null,
  });

  return (
    <>
      <SEO
        title="AI Resume Builder - Create Professional CV"
        description="Build your professional resume in minutes with our easy-to-use builder. Choose from modern templates and export to PDF instantly."
      />

      <AppShell>
        {/* Changed h-screen to h-full to work within AppShell's flex container */}
        <div className="flex flex-col h-full bg-background overflow-hidden">

          <Tabs defaultValue="edit" className="flex flex-col h-full">

            {/* Top Header */}
            <div className="shrink-0 bg-white/90 backdrop-blur-md border-b shadow-sm z-30">
              <div className="px-4 py-2 flex items-center justify-between max-w-7xl mx-auto">
                
                {/* Back btn */}
                <button
                  onClick={() => navigate(-1)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-600" />
                </button>

                {/* Tabs */}
                <TabsList className="flex-1 max-w-[400px] mx-4 grid grid-cols-2 bg-slate-100">
                  <TabsTrigger value="edit">Edit Details</TabsTrigger>
                  <TabsTrigger value="preview">Preview & Download</TabsTrigger>
                </TabsList>

                <PDFExport
                  targetId="resume-preview-content"
                  fileName={`${resumeData.personal.name || "resume"}_CV`}
                  size="sm"
                  className="bg-blue-600 text-white hover:bg-blue-700"
                />
              </div>
            </div>

            {/* Scrollable main area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 bg-muted/50">
              <div className="max-w-5xl mx-auto pb-32">

                <TabsContent value="edit" className="animate-in fade-in-50 mt-0">
                  
                  <section className="space-y-6">
                    <h2 className="text-sm font-semibold uppercase text-muted-foreground">
                      1. Choose Template
                    </h2>
                    <TemplateSelector
                      activeTemplate={activeTemplate}
                      onChange={setActiveTemplate}
                    />
                  </section>

                  <section className="mt-6">
                    <h2 className="text-sm font-semibold uppercase text-muted-foreground">
                      2. Enter Details
                    </h2>
                    <ResumeForm data={resumeData} updateData={setResumeData} />
                  </section>
                </TabsContent>

                <TabsContent value="preview" className="animate-in fade-in-50 mt-0">
                  <div className="flex flex-col gap-4 items-center">
                    <h2 className="text-lg font-semibold">Preview Resume</h2>
                    <p className="text-sm text-muted-foreground">
                      Review before downloading.
                    </p>

                    <ResumePreview
                      id="resume-preview-content"
                      data={resumeData}
                      template={activeTemplate}
                    />
                  </div>
                </TabsContent>

              </div>
            </div>
          </Tabs>
        </div>
      </AppShell>
    </>
  );
};

export default ResumeBuilder;
