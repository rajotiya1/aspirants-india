
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import {
  Loader2, Info, CalendarDays, Award, CreditCard, BookOpen,
  CheckCircle, FileText, Globe, FileSignature, BookMarked, ArrowLeft
} from 'lucide-react';
import SEO from '@/components/SEO';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { normalizeUrl } from '@/lib/utils';

const ensureDevanagariFont = () => {
  const id = 'gf-noto-devanagari';
  if (!document.getElementById(id)) {
    const link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href =
      'https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;600&display=swap';
    document.head.appendChild(link);
  }
};

const ENGLISH_WORDS = new Set([
  'bssc','ssc','upsc','bpsc','rrb','ibps','psc','railway','govt','government',
  'office','attendant','advertisement','advt','no','post','posts','vacancy','vacancies',
  'exam','examination','pre','preliminary','main','mains','result','results',
  'admit','card','answer','key','cutoff','syllabus','apply','online','official','website',
  'notification','pdf','last','date','age','limit','fee','structure','qualification',
  'eligibility','selection','process','category','categories','general','male','female',
  'bc','ebc','sc','st','level','pay','matrix','clerk','stenographer','ldc',
  'typing','english','test','form','start','extended','staff','commission',
  'january','february','march','april','may','june','july','august','september','october','november','december'
]);

const ENGLISH_STYLE =
  "font-family: Inter, Arial, 'Helvetica Neue', Segoe UI, Roboto, 'Noto Sans', sans-serif";
const HINDI_STYLE =
  "font-family: 'Noto Sans Devanagari', Hind, Mukta, 'Nirmala UI', Mangal, sans-serif";

const escapeHTML = (s) =>
  String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

const isEnglishToken = (tok) => {
  if (!tok) return false;
  const t = tok.toLowerCase();
  if (/[\u0900-\u097F]/.test(t)) return false;
  if (/^[\d₹.,:/%-]+$/.test(t)) return true;
  if (/^\d{1,2}[-/]\d{1,2}[-/]\d{2,4}$/.test(t)) return true;
  if (ENGLISH_WORDS.has(t)) return true;
  return false;
};

const toMixedHTML = (text) => {
  if (!text) return '';
  const tokens = text.match(/\s+|[^\s]+/g) || [text];
  return tokens
    .map((tok) => {
      if (/^\s+$/.test(tok)) return tok;
      const safe = escapeHTML(tok);
      const style = isEnglishToken(tok) ? ENGLISH_STYLE : HINDI_STYLE;
      return `<span style="${style}">${safe}</span>`;
    })
    .join('');
};

const DetailSection = ({ title, content, icon: Icon }) => {
  if (!content) return null;

  const renderContent = () => {
    if (typeof content === 'string') {
      return (
        <p
          className="text-gray-700 whitespace-pre-wrap text-justify"
          dangerouslySetInnerHTML={{ __html: toMixedHTML(content) }}
        />
      );
    }
    if (typeof content === 'object' && content !== null) {
      const entries = Array.isArray(content)
        ? content.flatMap((obj) => Object.entries(obj))
        : Object.entries(content);

      return (
        <ul className="list-disc list-inside text-gray-700 space-y-1">
          {entries.map(([key, value], idx) => (
            <li
              key={idx}
              dangerouslySetInnerHTML={{
                __html: `<span style="font-weight:600; ${ENGLISH_STYLE}">${escapeHTML(
                  key
                )}:</span> ${toMixedHTML(value)}`
              }}
            />
          ))}
        </ul>
      );
    }
    return null;
  };

  return (
    <Card className="rounded-2xl shadow-md border-l-4 border-indigo-500 hover:shadow-lg transition">
      <CardHeader className="bg-gray-50">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold text-indigo-700">
          {Icon && <Icon className="w-5 h-5 text-indigo-500" />} {title}
        </CardTitle>
      </CardHeader>
      <CardContent>{renderContent()}</CardContent>
    </Card>
  );
};

const DirectLinks = ({ links }) => {
  if (!links) return null;

  const linkItems = [
    { label: 'Apply Online', url: links.apply_online_url, icon: FileSignature },
    { label: 'Official Website', url: links.official_website, icon: Globe },
    { label: 'Official Notification (PDF)', url: links.notification_pdf, icon: FileText },
    { label: 'Syllabus (PDF)', url: links.syllabus_pdf, icon: BookOpen },
    { label: 'Study Material (PDF)', url: links.study_material_pdf, icon: BookMarked },
  ].filter((item) => item.url);

  if (linkItems.length === 0) return null;

  return (
    <Card className="mt-10 border-t-4 border-indigo-500 shadow-md">
      <CardHeader className="bg-gray-50">
        <CardTitle className="text-xl font-bold text-indigo-700">👉 Direct Links</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {linkItems.map((item, idx) => (
          <a
            key={idx}
            href={normalizeUrl(item.url)}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full text-center py-3 rounded-lg bg-indigo-600 text-white font-medium shadow hover:bg-indigo-700 transition"
          >
            <div className="flex items-center justify-center gap-2">
              <item.icon className="w-5 h-5 text-white" />
              {item.label}
            </div>
          </a>
        ))}
      </CardContent>
    </Card>
  );
};

const JobDetail = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [jobDetail, setJobDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => { ensureDevanagariFont(); }, []);

  useEffect(() => {
    const fetchJobDetail = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('job_details')
          .select('*')
          .eq('slug', slug)
          .single();

        if (error) throw error;
        setJobDetail(data);
      } catch (err) {
        setError('Job details not found.');
        console.error('Error fetching job details:', err);
      } finally {
        setLoading(false);
      }
    };
    if (slug) fetchJobDetail();
  }, [slug]);

  if (loading) {
    return (
      <div className="flex flex-col justify-center items-center h-screen gap-3">
        <Loader2 className="w-16 h-16 animate-spin text-indigo-600" />
        <p className="text-gray-600">Loading Job Details...</p>
      </div>
    );
  }

  if (error || !jobDetail) {
    return (
      <div className="text-center py-10">
        <h1 className="text-2xl font-bold text-red-600">Error</h1>
        <p className="text-gray-500">{error || 'Job details not found.'}</p>
      </div>
    );
  }

  const schemaData = {
    '@context': 'https://schema.org',
    '@type': 'JobPosting',
    title: jobDetail.title,
    description: jobDetail.full_detail || `Details for ${jobDetail.title}`,
    datePosted: jobDetail.created_at,
    validThrough: jobDetail.important_dates?.['application_end'] || '',
    employmentType: 'FULL_TIME',
    hiringOrganization: { '@type': 'Organization', name: 'Aspirants India' },
    jobLocation: { '@type': 'Place', address: { '@type': 'PostalAddress', addressCountry: 'IN' } },
    qualifications: jobDetail.qualification_eligibility,
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 py-8 px-4">
      <SEO
        title={jobDetail.title}
        description={
          jobDetail.full_detail?.substring(0, 160) ||
          `Find all details about the ${jobDetail.title} recruitment.`
        }
        schemaData={schemaData}
      />

      <header className="max-w-3xl mx-auto mb-6 flex items-center">
        <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Button>
      </header>

      <h1 className="text-4xl font-extrabold text-center mb-6 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
        {jobDetail.title}
      </h1>

      <div className="space-y-6 max-w-3xl mx-auto">
        <DetailSection title="👉 Full Detail" content={jobDetail.full_detail} icon={Info} />
        <DetailSection title="👉 Total Vacancy" content={jobDetail.total_vacancy} icon={FileText} />
        <DetailSection title="👉 Important Dates" content={jobDetail.important_dates} icon={CalendarDays} />
        <DetailSection title="👉 Age Limit & Relaxation" content={jobDetail.age_limit} icon={Award} />
        <DetailSection title="👉 Fee Structure" content={jobDetail.fee_structure} icon={CreditCard} />
        <DetailSection title="👉 Qualification + Eligibility" content={jobDetail.qualification_eligibility} icon={BookOpen} />
        <DetailSection title="👉 Selection Process" content={jobDetail.selection_process} icon={CheckCircle} />
        <DetailSection title="👉 Salary / Pay Structure" content={jobDetail.salary_structure} icon={CreditCard} />
        <DetailSection title="👉 Exam Pattern / Schedule" content={jobDetail.exam_pattern} icon={CalendarDays} />
        <DetailSection title="👉 Syllabus" content={jobDetail.syllabus} icon={BookOpen} />
        <DetailSection title="👉 Study Material" content={jobDetail.study_material} icon={BookMarked} />
        <DetailSection title="👉 How to Apply" content={jobDetail.how_to_apply} icon={FileSignature} />

        <DirectLinks links={jobDetail} />

        <DetailSection title="👉 Extra Facts" content={jobDetail.extra_facts} icon={Info} />
      </div>
    </div>
  );
};

export default JobDetail;
