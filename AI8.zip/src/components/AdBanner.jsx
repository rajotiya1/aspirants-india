import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { motion } from 'framer-motion';

const AdBanner = ({ location, className }) => {
  const [ad, setAd] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAd = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('advertisements')
        .select('*')
        .eq('location', location)
        .eq('is_active', true)
        .limit(1);

      if (error) {
        console.error(`Error fetching ad for location ${location}:`, error);
      } else if (data && data.length > 0) {
        setAd(data[0]);
      } else {
        setAd(null);
      }
      setLoading(false);
    };

    fetchAd();
  }, [location]);

  if (loading) {
    return (
      <div className={`bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-lg flex items-center justify-center text-slate-500 text-sm animate-pulse ${className}`}>
        Loading Ad...
      </div>
    );
  }

  if (!ad) {
    return (
      <div className={`bg-slate-800/50 border-2 border-dashed border-slate-700 rounded-lg flex items-center justify-center text-slate-500 text-sm ${className}`}>
        Ad Space ({location})
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className={className}
    >
      <a href={ad.destination_url} target="_blank" rel="noopener noreferrer" title={ad.name}>
        <img src={ad.image_url} alt={ad.name} className="w-full h-full object-cover rounded-lg" />
      </a>
    </motion.div>
  );
};

export default AdBanner;