import React, { useRef, useEffect, useState, Suspense } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const LoadingFallback = () => (
  <div className="w-full h-full flex items-center justify-center bg-background">
    <Loader2 className="animate-spin text-primary h-8 w-8" />
  </div>
);

const PillsTabBar = ({ tabs, activeIndex, onTabClick, tabsRef }) => (
  <div className="p-2 bg-muted">
    <div
      ref={tabsRef}
      className="flex items-center space-x-2 overflow-x-auto no-scrollbar"
    >
      {tabs.map((tab, index) => {
        const isActive = activeIndex === index;
        return (
          <button
            key={tab.path}
            onClick={() => onTabClick(index)}
            className={cn(
              'shrink-0 whitespace-nowrap rounded-md px-4 py-1.5 text-sm font-medium transition-all duration-200 border border-transparent',
              isActive
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'bg-background text-muted-foreground hover:bg-secondary hover:text-foreground'
            )}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  </div>
);

const DefaultTabBar = ({ tabs, activeIndex, onTabClick, tabsRef }) => (
  <div className="border-b border-border bg-card">
    <div
      ref={tabsRef}
      className="flex items-center overflow-x-auto no-scrollbar"
    >
      {tabs.map((tab, index) => {
        const isActive = activeIndex === index;
        return (
          <button
            key={tab.path}
            onClick={() => onTabClick(index)}
            className={cn(
              'relative shrink-0 whitespace-nowrap px-4 py-3 text-sm font-medium transition-colors duration-200',
              isActive
                ? 'text-primary'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {tab.label}
            {isActive && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-full" />
            )}
          </button>
        );
      })}
    </div>
  </div>
);

const SwipeView = ({ tabs, basepath, children, usePillsStyle = false }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const swiperRef = useRef(null);
  const tabsRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
  const currentPath = location.pathname;
  const segments = currentPath.split("/").filter(Boolean);
  const lastSegment = segments[segments.length - 1]; // e.g. "states"

  const foundIndex = tabs.findIndex(tab => tab.path === lastSegment);

  if (foundIndex !== -1 && foundIndex !== activeIndex) {
    setActiveIndex(foundIndex);
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slideTo(foundIndex, 0);
    }
  } else if (foundIndex === -1) {
    // default to first tab
    if (activeIndex !== 0) {
      setActiveIndex(0);
      if (swiperRef.current && swiperRef.current.swiper) {
        swiperRef.current.swiper.slideTo(0, 0);
      }
    }
  }
}, [location.pathname, tabs, activeIndex]);

  useEffect(() => {
    if (tabsRef.current) {
      const activeButton = tabsRef.current.children[activeIndex];
      if (activeButton) {
        activeButton.scrollIntoView({
          behavior: 'smooth',
          inline: 'center',
          block: 'nearest',
        });
      }
    }
  }, [activeIndex]);

  const handleTabClick = (index) => {
    if (swiperRef.current && swiperRef.current.swiper) {
      swiperRef.current.swiper.slideTo(index);
    }
  };

  const handleSlideChange = (swiper) => {
    const newIndex = swiper.activeIndex;
    if (newIndex !== activeIndex) {
      navigate(`${basepath}/${tabs[newIndex].path}`, { replace: true });
    }
  };

  const ActiveComponent = tabs[activeIndex]?.component || (() => null);
  const TabBarComponent = usePillsStyle ? PillsTabBar : DefaultTabBar;

  return (
    <div className="flex flex-col h-full bg-background">
      <header className="flex-shrink-0 z-10">
        <TabBarComponent
          tabs={tabs}
          activeIndex={activeIndex}
          onTabClick={handleTabClick}
          tabsRef={tabsRef}
        />
      </header>
      <main className="flex-grow overflow-hidden">
        <Swiper
          ref={swiperRef}
          onSlideChange={handleSlideChange}
          initialSlide={activeIndex}
          className="h-full"
          autoHeight={false}
        >
          {tabs.map((tab, index) => (
            <SwiperSlide key={tab.path} className="overflow-y-auto">
              {Math.abs(activeIndex - index) <= 1 ? (
                <Suspense fallback={<LoadingFallback />}>
                  {children ? children(tab.component) : React.createElement(tab.component)}
                </Suspense>
              ) : (
                <div />
              )}
            </SwiperSlide>
          ))}
        </Swiper>
      </main>
    </div>
  );
};

export default SwipeView;