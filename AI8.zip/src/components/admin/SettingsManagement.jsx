import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Loader2, Save, Upload, PlusCircle, Trash2 } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';

const SettingsManagement = () => {
    const { toast } = useToast();
    const [settings, setSettings] = useState({});
    const [pages, setPages] = useState([]);
    const [loading, setLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const fileInputRef = useRef(null);
    const [editingPage, setEditingPage] = useState(null);
    const [isPageDialogOpen, setIsPageDialogOpen] = useState(false);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const settingsPromise = supabase.from('settings').select('*').eq('id', 1).single();
            const pagesPromise = supabase.from('pages').select('*').order('title');

            const [settingsResult, pagesResult] = await Promise.all([settingsPromise, pagesPromise]);

            if (settingsResult.error && settingsResult.error.code !== 'PGRST116') {
                toast({ title: 'Error fetching settings', description: settingsResult.error.message, variant: 'destructive' });
            } else {
                setSettings(settingsResult.data || { id: 1 });
            }

            if (pagesResult.error) {
                toast({ title: 'Error fetching pages', description: pagesResult.error.message, variant: 'destructive' });
            } else {
                setPages(pagesResult.data || []);
            }
        } catch (error) {
            toast({ title: 'Error', description: 'Failed to load data.', variant: 'destructive' });
        } finally {
            setLoading(false);
        }
    }, [toast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setSettings(prev => ({ ...prev, [id]: value }));
    };
    
    const handlePageInputChange = (e) => {
        const { id, value } = e.target;
        let newSlug = editingPage.slug;
        if (id === 'title' && !editingPage.id) { // Auto-generate slug for new pages only
            newSlug = value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
        }
        if (id === 'slug') {
            newSlug = value.toLowerCase().replace(/[^a-z0-9-]+/g, '');
        }
        setEditingPage(prev => ({ ...prev, [id]: value, slug: newSlug }));
    };

    const handleLogoUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setIsUploading(true);
        const fileExt = file.name.split('.').pop();
        const fileName = `logo.${fileExt}`;
        const filePath = `public/${fileName}`;

        const { error: uploadError } = await supabase.storage.from('logos').upload(filePath, file, { upsert: true });

        if (uploadError) {
            toast({ title: 'Logo upload failed', description: uploadError.message, variant: 'destructive' });
            setIsUploading(false);
            return;
        }

        const { data } = supabase.storage.from('logos').getPublicUrl(filePath);
        
        const newLogoUrl = `${data.publicUrl}?t=${new Date().getTime()}`;
        
        const { error: updateError } = await supabase.from('settings').upsert({ id: 1, logo_url: newLogoUrl }, { onConflict: 'id' });
        
        if (updateError) {
             toast({ title: 'Failed to save logo URL', description: updateError.message, variant: 'destructive' });
        } else {
            setSettings(prev => ({ ...prev, logo_url: newLogoUrl }));
            toast({ title: 'Logo uploaded and saved successfully!' });
        }
        setIsUploading(false);
    };

    const handleSaveSettings = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        const { id, created_at, updated_at, ...updateData } = settings;
        
        const { error } = await supabase.from('settings').upsert({ id: 1, ...updateData }, { onConflict: 'id' });
        if (error) {
            toast({ title: 'Error saving settings', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: 'Website settings have been updated.' });
            await fetchData();
        }
        setIsSubmitting(false);
    };

    const handleSavePage = async () => {
        if (!editingPage?.title || !editingPage?.slug) {
            toast({ title: 'Error', description: 'Title and Slug are required.', variant: 'destructive' });
            return;
        }
        setIsSubmitting(true);
        const { error } = await supabase.from('pages').upsert(editingPage, { onConflict: 'slug' });
         if (error) {
            toast({ title: 'Error saving page', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: `Page '${editingPage.title}' has been saved.` });
            setIsPageDialogOpen(false);
            setEditingPage(null);
            await fetchData();
        }
        setIsSubmitting(false);
    }

    const handleDeletePage = async (pageId) => {
        if (!window.confirm("Are you sure you want to delete this page?")) return;
        
        const { error } = await supabase.from('pages').delete().eq('id', pageId);
        if (error) {
            toast({ title: 'Error deleting page', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Page deleted.'});
            await fetchData();
        }
    };
    
    const openNewPageDialog = () => {
        setEditingPage({ title: '', slug: '', content: '' });
        setIsPageDialogOpen(true);
    };
    
    const openEditPageDialog = (page) => {
        setEditingPage(page);
        setIsPageDialogOpen(true);
    };

    const brandingFields = [
        { id: 'website_name', label: 'Website Name' },
        { id: 'tagline', label: 'Tagline' },
    ];
    
    const socialFields = [
        { id: 'facebook_url', label: 'Facebook URL' },
        { id: 'twitter_url', label: 'Twitter URL' },
        { id: 'instagram_url', label: 'Instagram URL' },
        { id: 'linkedin_url', label: 'LinkedIn URL' },
    ];

    if (loading) return <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin" /></div>;

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-card border-border">
                <CardHeader>
                    <CardTitle as="h2" className="text-2xl text-blue-400">Website Branding</CardTitle>
                    <CardDescription>Manage your website's name, tagline, and logo.</CardDescription>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleSaveSettings} className="space-y-6">
                        <div className="flex items-center gap-6 p-4 border border-border rounded-lg bg-background">
                            <Avatar className="w-20 h-20">
                                <AvatarImage src={settings.logo_url} key={settings.logo_url} />
                                <AvatarFallback>Logo</AvatarFallback>
                            </Avatar>
                            <div className="space-y-2">
                                <Label>Upload Logo</Label>
                                <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
                                  {isUploading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Upload className="mr-2 h-4 w-4" />}
                                   Change Logo
                                </Button>
                                <Input id="logo_upload" type="file" onChange={handleLogoUpload} accept="image/*" className="hidden" ref={fileInputRef}/>
                            </div>
                        </div>
                        
                        {brandingFields.map(field => (
                            <div key={field.id} className="space-y-2">
                                <Label htmlFor={field.id}>{field.label}</Label>
                                <Input id={field.id} value={settings[field.id] || ''} onChange={handleInputChange} className="bg-input border-border" />
                            </div>
                        ))}
                        
                        <h3 className="text-lg font-semibold border-t border-border pt-4">Social Media Links</h3>
                        {socialFields.map(field => (
                             <div key={field.id} className="space-y-2">
                                <Label htmlFor={field.id}>{field.label}</Label>
                                <Input id={field.id} value={settings[field.id] || ''} onChange={handleInputChange} className="bg-input border-border" placeholder="https://..."/>
                            </div>
                        ))}

                        <Button type="submit" disabled={isSubmitting || isUploading} className="w-full mt-4">
                            {(isSubmitting) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            <Save className="mr-2 h-4 w-4" /> Save Branding Settings
                        </Button>
                    </form>
                </CardContent>
            </Card>

            <Card className="bg-card border-border">
                <CardHeader>
                    <CardTitle as="h2" className="text-2xl text-blue-400">Site Pages</CardTitle>
                    <CardDescription>Manage content for pages like About Us, Privacy, etc.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2">
                        {pages.map(page => (
                             <div key={page.id} className="flex items-center justify-between p-3 bg-background rounded-md">
                                <div>
                                    <p className="font-medium text-white">{page.title}</p>
                                    <p className="text-sm text-slate-400">/page/{page.slug}</p>
                                </div>
                                <div className="flex gap-2">
                                    <Button variant="outline" size="sm" onClick={() => openEditPageDialog(page)}>Edit</Button>
                                    <Button variant="destructive" size="icon" onClick={() => handleDeletePage(page.id)}><Trash2 className="h-4 w-4" /></Button>
                                </div>
                             </div>
                        ))}
                    </div>
                </CardContent>
                <CardFooter>
                    <Button onClick={openNewPageDialog} className="w-full">
                        <PlusCircle className="mr-2 h-4 w-4" /> Add New Page
                    </Button>
                </CardFooter>
            </Card>

            <Dialog open={isPageDialogOpen} onOpenChange={setIsPageDialogOpen}>
                <DialogContent className="max-w-3xl bg-[#062E65] border-slate-700 text-white">
                    <DialogHeader>
                        <DialogTitle>{editingPage?.id ? 'Edit' : 'Create'} Page</DialogTitle>
                        <DialogDescription>
                            {editingPage?.id ? `Editing the '${editingPage.title}' page.` : 'Create a new page for your site.'}
                        </DialogDescription>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div>
                            <Label htmlFor="title">Page Title</Label>
                            <Input id="title" value={editingPage?.title || ''} onChange={handlePageInputChange} className="bg-input border-border"/>
                        </div>
                        <div>
                            <Label htmlFor="slug">Page Slug (URL)</Label>
                            <Input id="slug" value={editingPage?.slug || ''} onChange={handlePageInputChange} className="bg-input border-border" disabled={!!editingPage?.id} />
                            <p className="text-xs text-slate-400 mt-1">URL will be: /page/{editingPage?.slug}</p>
                        </div>
                        <div>
                            <Label htmlFor="content">Content (HTML allowed)</Label>
                            <Textarea id="content" value={editingPage?.content || ''} onChange={handlePageInputChange} rows={15} className="bg-input border-border"/>
                        </div>
                    </div>
                    <DialogFooter>
                        <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
                        <Button onClick={handleSavePage} disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Page
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default SettingsManagement;