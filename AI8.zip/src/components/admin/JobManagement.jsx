import React, { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Trash2, Loader2, Edit, Download } from 'lucide-react';
import { formatDate } from '@/lib/utils';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const jobInitialState = { name_of_post: '', qualification: '', date_of_post: new Date().toISOString().split('T')[0], last_date: '', authority: '', no_of_post: '', direct_link: '', state: '', detail: '', pdf_url: '', category_id: '' };

const JobManagement = () => {
  const { toast } = useToast();
  const [newJob, setNewJob] = useState(jobInitialState);
  const [jobs, setJobs] = useState([]);
  const [jobCategories, setJobCategories] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [isSubmittingJob, setIsSubmittingJob] = useState(false);
  const [editingJob, setEditingJob] = useState(null);

  const fetchJobCategories = useCallback(async () => {
    const { data, error } = await supabase.from('job_categories').select('*').order('id');
    if (error) {
        toast({title: 'Error fetching categories', description: error.message, variant: 'destructive'});
    } else {
        setJobCategories(data);
        if (data.length > 0) {
            setNewJob(prev => ({...prev, category_id: data[0].id}));
        }
    }
  }, [toast]);

  useEffect(() => {
    fetchJobCategories();
  }, [fetchJobCategories]);

  const handleJobInputChange = (e) => {
    const { id, value } = e.target;
    (editingJob ? setEditingJob : setNewJob)((prev) => ({ ...prev, [id]: value }));
  };
  
  const handleCategoryChange = (value) => {
      const id = parseInt(value, 10);
      (editingJob ? setEditingJob : setNewJob)((prev) => ({ ...prev, category_id: id }));
  }

  const handleAddJob = async (e) => {
    e.preventDefault();
    if (!newJob.category_id) {
        toast({ title: "Error", description: "Please select a job category.", variant: "destructive"});
        return;
    }
    setIsSubmittingJob(true);
    const jobData = { ...newJob, no_of_post: parseInt(newJob.no_of_post, 10) || null };
    const { error } = await supabase.from('jobs').insert(jobData);
    if (error) {
      toast({ title: 'Error adding job', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: 'New job has been added.' });
      setNewJob(prev => ({...jobInitialState, category_id: prev.category_id}));
      fetchJobsByDate(selectedDate);
    }
    setIsSubmittingJob(false);
  };

  const handleUpdateJob = async (e) => {
    e.preventDefault();
    setIsSubmittingJob(true);
    const {created_at, job_categories, ...jobData} = editingJob;
    jobData.no_of_post = parseInt(jobData.no_of_post, 10) || null;
     
    const { error } = await supabase.from('jobs').update(jobData).eq('id', editingJob.id);
    if (error) {
        toast({ title: 'Error updating job', description: error.message, variant: 'destructive' });
    } else {
        toast({ title: 'Success!', description: 'Job has been updated.' });
        setEditingJob(null);
        fetchJobsByDate(selectedDate);
    }
    setIsSubmittingJob(false);
  };

  const fetchJobsByDate = useCallback(async (isoDate) => {
    if (!isoDate) return;
    setLoadingJobs(true);
    const { data, error } = await supabase.from('jobs').select('*, job_categories(name)').eq('date_of_post', isoDate).order('created_at', { ascending: false });
    if (error) {
      toast({ title: 'Error fetching jobs', description: error.message, variant: 'destructive' });
      setJobs([]);
    } else {
      setJobs(data);
    }
    setLoadingJobs(false);
  }, [toast]);
  
  useEffect(() => {
    fetchJobsByDate(selectedDate);
  }, [selectedDate, fetchJobsByDate]);

  const handleDeleteJob = async (jobId) => {
    const { error: deleteSavedError } = await supabase.from('user_saved_jobs').delete().eq('job_id', jobId);
    if (deleteSavedError) {
        toast({ title: 'Error cleaning up saved jobs', description: deleteSavedError.message, variant: 'destructive' });
    }
    
    const { error } = await supabase.from('jobs').delete().eq('id', jobId);
    if (error) {
      toast({ title: 'Error deleting job', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: 'Job has been deleted.' });
      setJobs((prevJobs) => prevJobs.filter((job) => job.id !== jobId));
    }
  };
  
  const JobForm = ({ job, handler, categoryHandler, submitHandler, isSubmitting, buttonText }) => (
    <form onSubmit={submitHandler} className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-2"><Label htmlFor="name_of_post">Name of Post</Label><Input id="name_of_post" value={job.name_of_post} onChange={handler} required /></div>
      <div className="space-y-2"><Label htmlFor="category_id">Category</Label>
        <Select onValueChange={categoryHandler} value={job.category_id ? String(job.category_id) : ""}>
            <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
            <SelectContent>{jobCategories.map(cat => <SelectItem key={cat.id} value={String(cat.id)}>{cat.name}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="space-y-2"><Label htmlFor="qualification">Qualification</Label><Input id="qualification" value={job.qualification} onChange={handler} /></div>
      <div className="space-y-2"><Label htmlFor="date_of_post">Date of Post</Label><Input id="date_of_post" type="date" value={job.date_of_post} onChange={handler} required /></div>
      <div className="space-y-2"><Label htmlFor="last_date">Last Date</Label><Input id="last_date" type="date" value={job.last_date} onChange={handler} required /></div>
      <div className="space-y-2"><Label htmlFor="authority">Authority</Label><Input id="authority" value={job.authority} onChange={handler} /></div>
      <div className="space-y-2"><Label htmlFor="no_of_post">Number of Posts</Label><Input id="no_of_post" type="number" value={job.no_of_post || ''} onChange={handler} /></div>
      <div className="space-y-2"><Label htmlFor="state">State</Label><Input id="state" value={job.state} onChange={handler} /></div>
      <div className="space-y-2"><Label htmlFor="direct_link">Direct Link</Label><Input id="direct_link" type="url" value={job.direct_link} onChange={handler} /></div>
      <div className="space-y-2"><Label htmlFor="pdf_url">PDF URL</Label><Input id="pdf_url" type="url" value={job.pdf_url} onChange={handler} /></div>
      <div className="md:col-span-2 space-y-2"><Label htmlFor="detail">Job Detail</Label><Input id="detail" value={job.detail} onChange={handler} /></div>
      <div className="md:col-span-2"><Button type="submit" disabled={isSubmitting} className="w-full">{isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}{buttonText}</Button></div>
    </form>
  );

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader><CardTitle as="h2" className="text-2xl">Add New Job</CardTitle><CardDescription>Fill out the form to post a new job listing.</CardDescription></CardHeader>
        <CardContent>
          <JobForm job={newJob} handler={handleJobInputChange} categoryHandler={handleCategoryChange} submitHandler={handleAddJob} isSubmitting={isSubmittingJob} buttonText="Add Job" />
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle as="h2" className="text-2xl">Manage Existing Jobs</CardTitle><CardDescription>Search for jobs by date and manage them.</CardDescription></CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6"><Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} /></div>
          <div className="overflow-x-auto"><Table><TableHeader><TableRow><TableHead>Name of Post</TableHead><TableHead>Category</TableHead><TableHead>Last Date</TableHead><TableHead>Authority</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader><TableBody>
            {loadingJobs ? <TableRow><TableCell colSpan={5} className="text-center py-8"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
            : jobs.length > 0 ? jobs.map((job) => (<TableRow key={job.id}><TableCell className="font-medium">{job.name_of_post}</TableCell><TableCell>{job.job_categories?.name}</TableCell><TableCell>{formatDate(job.last_date)}</TableCell><TableCell>{job.authority}</TableCell>
            <TableCell className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setEditingJob(job)}><Edit className="h-4 w-4"/></Button>
              <Button asChild variant="outline" size="sm" disabled={!job.pdf_url}><a href={job.pdf_url} target="_blank" rel="noopener noreferrer"><Download className="h-4 w-4"/></a></Button>
              <Button variant="destructive" size="sm" onClick={() => handleDeleteJob(job.id)}><Trash2 className="h-4 w-4" /></Button>
            </TableCell></TableRow>))
            : <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No jobs found for the selected date.</TableCell></TableRow>}
          </TableBody></Table></div>
        </CardContent>
      </Card>
      
      {editingJob && (
        <Dialog open={!!editingJob} onOpenChange={(open) => !open && setEditingJob(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader><DialogTitle>Edit Job</DialogTitle></DialogHeader>
            <JobForm job={editingJob} handler={handleJobInputChange} categoryHandler={handleCategoryChange} submitHandler={handleUpdateJob} isSubmitting={isSubmittingJob} buttonText="Update Job" />
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingJob(null)}>Cancel</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default JobManagement;