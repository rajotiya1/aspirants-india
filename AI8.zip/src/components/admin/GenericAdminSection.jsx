import React, { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Trash2, Loader2, PlusCircle } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';

const defaultColumns = [
    { id: 'description', label: 'Description', type: 'text' },
    { id: 'url', label: 'URL', type: 'url' },
];

const GenericAdminSection = ({ title, tableName, columns = defaultColumns, displayColumn = 'description' }) => {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  
  const initialItemState = columns.reduce((acc, col) => ({ ...acc, [col.id]: '' }), {});
  const [newItem, setNewItem] = useState(initialItemState);
  
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(tableName).select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: `Error fetching ${title}`, description: error.message, variant: 'destructive' });
    } else {
      setItems(data);
    }
    setLoading(false);
  }, [tableName, toast, title]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setNewItem(prev => ({ ...prev, [id]: value }));
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const itemToInsert = { ...newItem };
    columns.forEach(col => {
        if (col.type === 'number') {
            itemToInsert[col.id] = parseInt(itemToInsert[col.id], 10) || null;
        }
    });

    const { error } = await supabase.from(tableName).insert(itemToInsert);
    if (error) {
      toast({ title: `Error adding ${title}`, description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: `New ${title} has been added.` });
      setNewItem(initialItemState);
      fetchData();
    }
    setIsSubmitting(false);
  };

  const handleDeleteItem = async (id) => {
    const { error } = await supabase.from(tableName).delete().eq('id', id);
    if (error) {
      toast({ title: `Error deleting ${title}`, description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: `${title} has been deleted.` });
      fetchData();
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-card border border-border">
        <CardHeader>
          <CardTitle as="h2" className="text-xl text-blue-400">Add New {title}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddItem} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {columns.map(col => (
                <div key={col.id} className="space-y-2">
                    <Label htmlFor={col.id}>{col.label}</Label>
                    {col.type === 'textarea' ? (
                        <Textarea id={col.id} value={newItem[col.id]} onChange={handleInputChange} required className="bg-input border-border" />
                    ) : (
                        <Input id={col.id} type={col.type || 'text'} value={newItem[col.id]} onChange={handleInputChange} required className="bg-input border-border" />
                    )}
                </div>
              ))}
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <PlusCircle className="h-4 w-4 mr-2" />}
              Add {title}
            </Button>
          </form>
        </CardContent>
      </Card>
      <Card className="bg-card border border-border">
        <CardHeader><CardTitle as="h2" className="text-xl text-green-400">Manage {title}</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow className="border-border hover:bg-transparent"><TableHead>{displayColumn}</TableHead><TableHead>Action</TableHead></TableRow></TableHeader>
            <TableBody>
              {loading ? <TableRow><TableCell colSpan={2} className="text-center py-8"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
              : items.map(item => (
                <TableRow key={item.id} className="border-border">
                  <TableCell className="font-medium">{item[displayColumn]}</TableCell>
                  <TableCell><Button variant="destructive" size="sm" onClick={() => handleDeleteItem(item.id)}><Trash2 className="h-4 w-4" /></Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default GenericAdminSection;