import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

const JobDetailManagement = () => {
  const { toast } = useToast();
  const [jobs, setJobs] = useState([]);
  const [selectedJobId, setSelectedJobId] = useState('');
  const [jobDetail, setJobDetail] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchJobsWithoutDetails = useCallback(async () => {
    const { data: jobsWithDetails } = await supabase.from('job_details').select('job_id');
    const jobIdsWithDetails = jobsWithDetails.map(jd => jd.job_id);

    const { data, error } = await supabase
      .from('jobs')
      .select('id, name_of_post, date_of_post')
      .not('id', 'in', `(${jobIdsWithDetails.join(',')})`)
      .order('date_of_post', { ascending: false });

    if (error) {
      toast({ title: 'Error fetching jobs', description: error.message, variant: 'destructive' });
    } else {
      setJobs(data);
    }
  }, [toast]);

  useEffect(() => {
    fetchJobsWithoutDetails();
  }, [fetchJobsWithoutDetails]);

  const handleJobSelect = async (jobId) => {
    if (!jobId) {
      setSelectedJobId('');
      setJobDetail(null);
      return;
    }
    setSelectedJobId(jobId);
    setLoading(true);
    const selectedJob = jobs.find(j => j.id === parseInt(jobId));
    const slug = selectedJob.name_of_post.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-') + '-' + new Date(selectedJob.date_of_post).getFullYear();

    setJobDetail({
      job_id: jobId,
      slug: slug,
      title: selectedJob.name_of_post,
      full_detail: '',
      important_dates: JSON.stringify({ "Application Start": "", "Last Date": "" }, null, 2),
      age_limits: '',
      fee_structure: '',
      qualification_eligibility: '',
      selection_process: '',
      extra_facts: '',
    });
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setJobDetail(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      let importantDatesParsed;
      try {
        importantDatesParsed = JSON.parse(jobDetail.important_dates);
      } catch (jsonError) {
        toast({ title: 'Invalid JSON', description: 'Important Dates must be valid JSON.', variant: 'destructive' });
        setLoading(false);
        return;
      }

      const { error } = await supabase.from('job_details').insert({
        ...jobDetail,
        important_dates: importantDatesParsed,
      });

      if (error) throw error;

      toast({ title: 'Success', description: 'Job details created successfully.' });
      setJobDetail(null);
      setSelectedJobId('');
      fetchJobsWithoutDetails();
    } catch (error) {
      toast({ title: 'Error creating job details', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage A to Z Job Details</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <Label htmlFor="job-select">Select a Job to Add Details</Label>
          <select
            id="job-select"
            value={selectedJobId}
            onChange={(e) => handleJobSelect(e.target.value)}
            className="w-full p-2 border rounded-md"
            disabled={loading}
          >
            <option value="">-- Select a Job --</option>
            {jobs.map(job => (
              <option key={job.id} value={job.id}>{job.name_of_post}</option>
            ))}
          </select>
        </div>

        {loading && <div className="flex justify-center"><Loader2 className="animate-spin" /></div>}

        {jobDetail && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <h3 className="text-lg font-semibold">{jobDetail.title}</h3>
            <div><Label>Slug (auto-generated)</Label><Input type="text" value={jobDetail.slug} readOnly /></div>
            <div><Label>Full Detail</Label><Textarea name="full_detail" value={jobDetail.full_detail} onChange={handleInputChange} /></div>
            <div><Label>Important Dates (JSON)</Label><Textarea name="important_dates" value={jobDetail.important_dates} onChange={handleInputChange} rows={4} /></div>
            <div><Label>Age Limits</Label><Textarea name="age_limits" value={jobDetail.age_limits} onChange={handleInputChange} /></div>
            <div><Label>Fee Structure</Label><Textarea name="fee_structure" value={jobDetail.fee_structure} onChange={handleInputChange} /></div>
            <div><Label>Qualification + Eligibility</Label><Textarea name="qualification_eligibility" value={jobDetail.qualification_eligibility} onChange={handleInputChange} /></div>
            <div><Label>Selection Process</Label><Textarea name="selection_process" value={jobDetail.selection_process} onChange={handleInputChange} /></div>
            <div><Label>Extra Facts</Label><Textarea name="extra_facts" value={jobDetail.extra_facts} onChange={handleInputChange} /></div>
            <Button type="submit" disabled={loading}>
              {loading ? <Loader2 className="animate-spin mr-2" /> : null}
              Create Job Detail
            </Button>
          </form>
        )}
      </CardContent>
    </Card>
  );
};

export default JobDetailManagement;