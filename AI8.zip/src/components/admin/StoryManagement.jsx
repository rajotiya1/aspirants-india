import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Check, X, Trash2, Edit, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

const StoryManagement = () => {
    const { toast } = useToast();
    const [stories, setStories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedStory, setSelectedStory] = useState(null);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchStories = useCallback(async () => {
        setLoading(true);
        const { data, error } = await supabase.from('stories')
            .select('*')
            .order('created_at', { ascending: false });
        if (error) {
            toast({ title: 'Error fetching stories', description: error.message, variant: 'destructive' });
        } else {
            setStories(data);
        }
        setLoading(false);
    }, [toast]);

    useEffect(() => {
        fetchStories();
    }, [fetchStories]);

    const handleApprovalToggle = async (story) => {
        const { error } = await supabase.from('stories').update({ approved: !story.approved }).eq('id', story.id);
        if (error) {
            toast({ title: 'Error updating story status', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: `Story has been ${!story.approved ? 'approved' : 'unapproved'}.` });
            fetchStories();
        }
    };

    const handleDeleteStory = async (storyId) => {
        const { error } = await supabase.from('stories').delete().eq('id', storyId);
        if (error) {
            toast({ title: 'Error deleting story', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: 'Story has been deleted.' });
            fetchStories();
        }
    };

    const openEditModal = (story) => {
        setSelectedStory(story);
        setIsEditModalOpen(true);
    };
    
    const handleUpdateStory = async (e) => {
        e.preventDefault();
        if (!selectedStory) return;
        setIsSubmitting(true);

        const { data: updatedStory, error } = await supabase
            .from('stories')
            .update({ 
                title: selectedStory.title,
                content: selectedStory.content,
                tips: selectedStory.tips,
                author_name: selectedStory.author_name
            })
            .eq('id', selectedStory.id)
            .select()
            .single();

        setIsSubmitting(false);

        if (error) {
            toast({ title: 'Error updating story', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Story updated successfully!' });
            setIsEditModalOpen(false);
            fetchStories();
        }
    };

    return (
        <>
            <Card className="bg-gray-900/50 border border-gray-700">
                <CardHeader>
                    <CardTitle as="h2" className="text-2xl text-blue-400">Manage Success Stories</CardTitle>
                    <CardDescription>Review, edit, approve, and delete user-submitted stories.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="hover:bg-transparent border-gray-700">
                                    <TableHead>Title</TableHead>
                                    <TableHead>Author</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {loading ? (
                                    <TableRow><TableCell colSpan={4} className="text-center py-8"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
                                ) : stories.length > 0 ? stories.map(story => (
                                    <TableRow key={story.id} className="border-gray-700">
                                        <TableCell className="font-medium max-w-xs truncate">{story.title}</TableCell>
                                        <TableCell>{story.author_name || 'Anonymous'}</TableCell>
                                        <TableCell>
                                            <span className={`px-2 py-1 rounded-full text-xs ${story.approved ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                                                {story.approved ? 'Approved' : 'Pending Review'}
                                            </span>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex gap-2 justify-end">
                                                <Button variant="outline" size="sm" onClick={() => openEditModal(story)}>
                                                    <Edit className="h-4 w-4 mr-2" /> Edit
                                                </Button>
                                                <Button variant={story.approved ? "secondary" : "default"} size="sm" onClick={() => handleApprovalToggle(story)}>
                                                    {story.approved ? <X className="h-4 w-4 mr-2" /> : <Check className="h-4 w-4 mr-2" />}
                                                    {story.approved ? 'Un-approve' : 'Approve'}
                                                </Button>
                                                <Button variant="destructive" size="sm" onClick={() => handleDeleteStory(story.id)}>
                                                    <Trash2 className="h-4 w-4" />
                                                </Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                )) : (
                                    <TableRow><TableCell colSpan={4} className="text-center py-8">No stories submitted yet.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
                <DialogContent className="max-w-3xl bg-gray-900 border-gray-700 text-white">
                    <DialogHeader>
                        <DialogTitle>Edit Story</DialogTitle>
                        <DialogDescription>Make changes to the story before publishing.</DialogDescription>
                    </DialogHeader>
                    {selectedStory && (
                        <form onSubmit={handleUpdateStory} className="space-y-4 py-4">
                            <div>
                                <Label htmlFor="edit-title">Title</Label>
                                <Input id="edit-title" value={selectedStory.title} onChange={(e) => setSelectedStory({...selectedStory, title: e.target.value})} className="bg-gray-800 border-gray-600" />
                            </div>
                            <div>
                                <Label htmlFor="edit-author">Author Name</Label>
                                <Input id="edit-author" value={selectedStory.author_name || ''} onChange={(e) => setSelectedStory({...selectedStory, author_name: e.target.value})} className="bg-gray-800 border-gray-600" />
                            </div>
                            <div>
                                <Label htmlFor="edit-content">Story Content</Label>
                                <Textarea id="edit-content" value={selectedStory.content} onChange={(e) => setSelectedStory({...selectedStory, content: e.target.value})} className="bg-gray-800 border-gray-600" rows={10} />
                            </div>
                             <div>
                                <Label htmlFor="edit-tips">Top 3 Tips</Label>
                                <Textarea id="edit-tips" value={selectedStory.tips || ''} onChange={(e) => setSelectedStory({...selectedStory, tips: e.target.value})} className="bg-gray-800 border-gray-600" rows={4} />
                            </div>
                            <DialogFooter>
                                <DialogClose asChild>
                                    <Button type="button" variant="outline">Cancel</Button>
                                </DialogClose>
                                <Button type="submit" disabled={isSubmitting}>
                                    {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                    Save Changes
                                </Button>
                            </DialogFooter>
                        </form>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
};

export default StoryManagement;