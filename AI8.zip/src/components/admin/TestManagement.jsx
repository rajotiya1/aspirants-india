import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Trash2, Loader2, PlusCircle, Edit, BookOpen } from 'lucide-react';
import { formatDate } from '@/lib/utils';

const testConfig = {
    'Daily Current Affairs': ['India', 'Haryana', 'Rajasthan', 'UP', 'Bihar'],
    'SSC': ['English', 'Math', 'Reasoning', 'Complete Practice Paper'],
    'UPSC': ['English', 'Math', 'Reasoning', 'Complete Practice Paper'],
    'Haryana': ['English', 'Math', 'Reasoning', 'Complete Practice Paper'],
    'Center': ['English', 'Math', 'Reasoning', 'Complete Practice Paper'],
};

const initialQuestionState = { question_text: '', option_a: '', option_b: '', option_c: '', option_d: '', correct_answer: 'A', explanation: '' };

const TestManagement = () => {
    const { toast } = useToast();
    const [mainCategory, setMainCategory] = useState('Daily Current Affairs');
    const [subCategory, setSubCategory] = useState('India');
    const [tests, setTests] = useState([]);
    const [loadingTests, setLoadingTests] = useState(false);
    
    const [managingTest, setManagingTest] = useState(null);
    const [questions, setQuestions] = useState([]);
    const [loadingQuestions, setLoadingQuestions] = useState(false);
    
    const [isQuestionDialogOpen, setIsQuestionDialogOpen] = useState(false);
    const [editingQuestion, setEditingQuestion] = useState(null);
    const [newQuestion, setNewQuestion] = useState(initialQuestionState);
    const [isSubmittingQuestion, setIsSubmittingQuestion] = useState(false);

    const [isTestDialogOpen, setIsTestDialogOpen] = useState(false);
    const [newTestDate, setNewTestDate] = useState(new Date().toISOString().split('T')[0]);
    const [newTestTitle, setNewTestTitle] = useState('');
    const [isSubmittingTest, setIsSubmittingTest] = useState(false);

    const fetchTests = useCallback(async () => {
        if (!mainCategory || !subCategory) return;
        setLoadingTests(true);
        const { data, error } = await supabase
            .from('tests')
            .select('*')
            .eq('category', mainCategory)
            .eq('sub_category', subCategory)
            .order('test_date', { ascending: false });
        
        if (error) {
            toast({ title: 'Error fetching tests', description: error.message, variant: 'destructive' });
        } else {
            setTests(data);
        }
        setLoadingTests(false);
    }, [mainCategory, subCategory, toast]);

    useEffect(() => {
        fetchTests();
    }, [fetchTests]);

    useEffect(() => {
        if (mainCategory) {
            setSubCategory(testConfig[mainCategory][0]);
        }
    }, [mainCategory]);

    const handleAddTest = async (e) => {
        e.preventDefault();
        setIsSubmittingTest(true);
        const { error } = await supabase.from('tests').insert({
            category: mainCategory,
            sub_category: subCategory,
            test_date: newTestDate,
            title: newTestTitle || `${subCategory} Test - ${formatDate(newTestDate)}`
        });
        if (error) {
            toast({ title: 'Error adding test', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: 'New test created.' });
            fetchTests();
            setIsTestDialogOpen(false);
            setNewTestTitle('');
            setNewTestDate(new Date().toISOString().split('T')[0]);
        }
        setIsSubmittingTest(false);
    };

    const handleDeleteTest = async (testId) => {
        const { error } = await supabase.from('tests').delete().eq('id', testId);
        if (error) {
            toast({ title: 'Error deleting test', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: 'Test deleted.' });
            fetchTests();
        }
    };

    const openQuestionManager = async (test) => {
        setManagingTest(test);
        setLoadingQuestions(true);
        const { data, error } = await supabase.from('questions').select('*').eq('test_id', test.id);
        if (error) {
            toast({ title: 'Error fetching questions', description: error.message, variant: 'destructive' });
            setQuestions([]);
        } else {
            setQuestions(data);
        }
        setLoadingQuestions(false);
    };

    const handleQuestionSubmit = async (e) => {
        e.preventDefault();
        setIsSubmittingQuestion(true);
        const questionData = editingQuestion ? { ...editingQuestion } : { ...newQuestion };
        
        const dataToSubmit = {
            test_id: managingTest.id,
            question_text: questionData.question_text,
            option_a: questionData.option_a,
            option_b: questionData.option_b,
            option_c: questionData.option_c,
            option_d: questionData.option_d,
            correct_answer: questionData.correct_answer,
            explanation: questionData.explanation,
        };

        const { error } = editingQuestion
            ? await supabase.from('questions').update(dataToSubmit).eq('id', editingQuestion.id)
            : await supabase.from('questions').insert(dataToSubmit);

        if (error) {
            toast({ title: 'Error saving question', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: `Question ${editingQuestion ? 'updated' : 'added'}.` });
            openQuestionManager(managingTest); // Refresh questions
            setIsQuestionDialogOpen(false);
            setEditingQuestion(null);
            setNewQuestion(initialQuestionState);
        }
        setIsSubmittingQuestion(false);
    };

    const handleDeleteQuestion = async (questionId) => {
        const { error } = await supabase.from('questions').delete().eq('id', questionId);
        if (error) {
            toast({ title: 'Error deleting question', description: error.message, variant: 'destructive' });
        } else {
            toast({ title: 'Success!', description: 'Question deleted.' });
            openQuestionManager(managingTest); // Refresh questions
        }
    };

    const openAddQuestionDialog = () => {
        setEditingQuestion(null);
        setNewQuestion(initialQuestionState);
        setIsQuestionDialogOpen(true);
    };

    const openEditQuestionDialog = (question) => {
        setEditingQuestion(question);
        setIsQuestionDialogOpen(true);
    };

    return (
        <div className="space-y-8">
            <Card className="bg-gray-900/50 border border-gray-700">
                <CardHeader>
                    <CardTitle className="text-2xl text-blue-400">Manage Online Tests</CardTitle>
                    <CardDescription>Create and manage date-wise tests and their questions.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col md:flex-row gap-4 items-end">
                    <div className="flex-1 space-y-2">
                        <Label>Main Category</Label>
                        <Select value={mainCategory} onValueChange={setMainCategory}>
                            <SelectTrigger className="bg-gray-800 border-gray-600"><SelectValue /></SelectTrigger>
                            <SelectContent>{Object.keys(testConfig).map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="flex-1 space-y-2">
                        <Label>Sub Section</Label>
                        <Select value={subCategory} onValueChange={setSubCategory}>
                            <SelectTrigger className="bg-gray-800 border-gray-600"><SelectValue /></SelectTrigger>
                            <SelectContent>{testConfig[mainCategory].map(sub => <SelectItem key={sub} value={sub}>{sub}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <Dialog open={isTestDialogOpen} onOpenChange={setIsTestDialogOpen}>
                        <DialogTrigger asChild><Button><PlusCircle className="mr-2 h-4 w-4" /> Create New Test</Button></DialogTrigger>
                        <DialogContent className="bg-gray-900 border-gray-700 text-white">
                            <DialogHeader><DialogTitle>Create New Test for {mainCategory} - {subCategory}</DialogTitle></DialogHeader>
                            <form onSubmit={handleAddTest} className="space-y-4">
                                <div><Label htmlFor="test_date">Test Date</Label><Input id="test_date" type="date" value={newTestDate} onChange={e => setNewTestDate(e.target.value)} required className="bg-gray-800 border-gray-600" /></div>
                                <div><Label htmlFor="test_title">Test Title (Optional)</Label><Input id="test_title" type="text" value={newTestTitle} onChange={e => setNewTestTitle(e.target.value)} placeholder={`e.g., ${subCategory} Special`} className="bg-gray-800 border-gray-600" /></div>
                                <DialogFooter><Button type="submit" disabled={isSubmittingTest}>{isSubmittingTest ? <Loader2 className="animate-spin" /> : 'Create Test'}</Button></DialogFooter>
                            </form>
                        </DialogContent>
                    </Dialog>
                </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border border-gray-700">
                <CardHeader><CardTitle className="text-xl text-green-400">Tests for: {mainCategory} - {subCategory}</CardTitle></CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader><TableRow className="hover:bg-transparent border-gray-700"><TableHead>Date</TableHead><TableHead>Title</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
                        <TableBody>
                            {loadingTests ? <TableRow><TableCell colSpan={3} className="text-center py-8"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
                            : tests.map(test => (
                                <TableRow key={test.id} className="border-gray-700">
                                    <TableCell>{formatDate(test.test_date)}</TableCell>
                                    <TableCell>{test.title}</TableCell>
                                    <TableCell className="flex gap-2">
                                        <Dialog onOpenChange={(open) => open && openQuestionManager(test)}>
                                            <DialogTrigger asChild><Button variant="outline" size="sm"><BookOpen className="h-4 w-4 mr-2" />Manage Questions</Button></DialogTrigger>
                                        </Dialog>
                                        <Button variant="destructive" size="sm" onClick={() => handleDeleteTest(test.id)}><Trash2 className="h-4 w-4" /></Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            {managingTest && (
                <DialogContent className="max-w-4xl h-[90vh] flex flex-col bg-gray-900 border-gray-700 text-white">
                    <DialogHeader>
                        <DialogTitle className="text-blue-400">Questions for: {managingTest.title}</DialogTitle>
                        <Button onClick={openAddQuestionDialog} size="sm" className="absolute top-4 right-16"><PlusCircle className="mr-2 h-4 w-4" /> Add Question</Button>
                    </DialogHeader>
                    <div className="flex-grow overflow-y-auto pr-4">
                        {loadingQuestions ? <Loader2 className="mx-auto h-8 w-8 animate-spin" /> :
                            questions.length > 0 ? questions.map(q => (
                                <div key={q.id} className="p-3 mb-2 bg-gray-800/50 rounded-lg border border-gray-700">
                                    <p className="font-semibold">{q.question_text}</p>
                                    <div className="text-xs text-gray-400 mt-1">Correct: {q.correct_answer}</div>
                                    <div className="flex gap-2 mt-2">
                                        <Button variant="outline" size="sm" onClick={() => openEditQuestionDialog(q)}><Edit className="h-3 w-3 mr-1" />Edit</Button>
                                        <Button variant="destructive" size="sm" onClick={() => handleDeleteQuestion(q.id)}><Trash2 className="h-3 w-3 mr-1" />Delete</Button>
                                    </div>
                                </div>
                            )) : <p className="text-center text-gray-400 py-8">No questions yet for this test.</p>
                        }
                    </div>
                    <DialogFooter><DialogClose asChild><Button variant="outline">Close</Button></DialogClose></DialogFooter>
                </DialogContent>
            )}

            <Dialog open={isQuestionDialogOpen} onOpenChange={setIsQuestionDialogOpen}>
                <DialogContent className="max-w-2xl bg-gray-900 border-gray-700 text-white">
                    <DialogHeader><DialogTitle className="text-blue-400">{editingQuestion ? 'Edit Question' : 'Add New Question'}</DialogTitle></DialogHeader>
                    <form onSubmit={handleQuestionSubmit} className="space-y-4">
                        <div><Label>Question</Label><Textarea name="question_text" value={editingQuestion?.question_text || newQuestion.question_text} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, question_text: e.target.value}) : setNewQuestion({...newQuestion, question_text: e.target.value})} required className="bg-gray-800 border-gray-600" /></div>
                        <div><Label>Option A</Label><Input name="option_a" value={editingQuestion?.option_a || newQuestion.option_a} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, option_a: e.target.value}) : setNewQuestion({...newQuestion, option_a: e.target.value})} required className="bg-gray-800 border-gray-600" /></div>
                        <div><Label>Option B</Label><Input name="option_b" value={editingQuestion?.option_b || newQuestion.option_b} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, option_b: e.target.value}) : setNewQuestion({...newQuestion, option_b: e.target.value})} required className="bg-gray-800 border-gray-600" /></div>
                        <div><Label>Option C</Label><Input name="option_c" value={editingQuestion?.option_c || newQuestion.option_c} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, option_c: e.target.value}) : setNewQuestion({...newQuestion, option_c: e.target.value})} required className="bg-gray-800 border-gray-600" /></div>
                        <div><Label>Option D</Label><Input name="option_d" value={editingQuestion?.option_d || newQuestion.option_d} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, option_d: e.target.value}) : setNewQuestion({...newQuestion, option_d: e.target.value})} required className="bg-gray-800 border-gray-600" /></div>
                        <div><Label>Correct Answer</Label>
                            <Select value={editingQuestion?.correct_answer || newQuestion.correct_answer} onValueChange={(val) => editingQuestion ? setEditingQuestion({...editingQuestion, correct_answer: val}) : setNewQuestion({...newQuestion, correct_answer: val})}>
                                <SelectTrigger className="bg-gray-800 border-gray-600"><SelectValue /></SelectTrigger>
                                <SelectContent>{['A', 'B', 'C', 'D'].map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div><Label>Explanation</Label><Textarea name="explanation" value={editingQuestion?.explanation || newQuestion.explanation} onChange={(e) => editingQuestion ? setEditingQuestion({...editingQuestion, explanation: e.target.value}) : setNewQuestion({...newQuestion, explanation: e.target.value})} className="bg-gray-800 border-gray-600" /></div>
                        <DialogFooter><Button type="submit" disabled={isSubmittingQuestion}>{isSubmittingQuestion ? <Loader2 className="animate-spin" /> : 'Save Question'}</Button></DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default TestManagement;