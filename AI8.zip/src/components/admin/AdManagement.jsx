import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Loader2, PlusCircle, ToggleLeft, ToggleRight } from 'lucide-react';

const AdManagement = () => {
  const { toast } = useToast();
  const [ads, setAds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newAd, setNewAd] = useState({
    name: '',
    destination_url: '',
    location: 'sidebar_1',
    image_file: null,
  });

  const fetchAds = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('advertisements').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: 'Error fetching ads', description: error.message, variant: 'destructive' });
    } else {
      setAds(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchAds();
  }, [fetchAds]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setNewAd(prev => ({ ...prev, [id]: value }));
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setNewAd(prev => ({ ...prev, image_file: e.target.files[0] }));
    }
  };

  const handleAddAd = async (e) => {
    e.preventDefault();
    if (!newAd.image_file) {
      toast({ title: 'No image selected', description: 'Please select an image file to upload.', variant: 'destructive' });
      return;
    }
    setIsSubmitting(true);

    const file = newAd.image_file;
    const filePath = `public/${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage.from('ads').upload(filePath, file);

    if (uploadError) {
      toast({ title: 'Image upload failed', description: uploadError.message, variant: 'destructive' });
      setIsSubmitting(false);
      return;
    }

    const { data: { publicUrl } } = supabase.storage.from('ads').getPublicUrl(filePath);

    const { error: insertError } = await supabase.from('advertisements').insert({
      name: newAd.name,
      destination_url: newAd.destination_url,
      location: newAd.location,
      image_url: publicUrl,
    });

    if (insertError) {
      toast({ title: 'Error adding ad', description: insertError.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: 'New ad has been added.' });
      setNewAd({ name: '', destination_url: '', location: 'sidebar_1', image_file: null });
      document.getElementById('image_file').value = '';
      fetchAds();
    }
    setIsSubmitting(false);
  };

  const handleDeleteAd = async (ad) => {
    const { error: deleteDbError } = await supabase.from('advertisements').delete().eq('id', ad.id);
    if (deleteDbError) {
      toast({ title: 'Error deleting ad from database', description: deleteDbError.message, variant: 'destructive' });
      return;
    }

    const filePath = ad.image_url.split('/ads/')[1];
    if (filePath) {
      const { error: deleteStorageError } = await supabase.storage.from('ads').remove([filePath]);
      if (deleteStorageError) {
        toast({ title: 'Error deleting ad image from storage', description: deleteStorageError.message, variant: 'destructive' });
      }
    }

    toast({ title: 'Success!', description: 'Ad has been deleted.' });
    fetchAds();
  };

  const toggleAdStatus = async (ad) => {
    const { error } = await supabase.from('advertisements').update({ is_active: !ad.is_active }).eq('id', ad.id);
    if (error) {
      toast({ title: 'Error updating ad status', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success!', description: 'Ad status updated.' });
      fetchAds();
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900/50 border border-gray-700">
        <CardHeader><CardTitle>Add New Advertisement</CardTitle><CardDescription>Upload banners and set their placement.</CardDescription></CardHeader>
        <CardContent>
          <form onSubmit={handleAddAd} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label htmlFor="name">Ad Name / Title</Label><Input id="name" value={newAd.name} onChange={handleInputChange} required className="bg-gray-800 border-gray-600" /></div>
              <div><Label htmlFor="destination_url">Destination URL</Label><Input id="destination_url" type="url" value={newAd.destination_url} onChange={handleInputChange} required className="bg-gray-800 border-gray-600" /></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label htmlFor="location">Location</Label>
                <Select onValueChange={(value) => setNewAd(p => ({ ...p, location: value }))} value={newAd.location}>
                  <SelectTrigger className="bg-gray-800 border-gray-600"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="top_banner">Top Banner</SelectItem>
                    <SelectItem value="sidebar_1">Sidebar 1</SelectItem>
                    <SelectItem value="sidebar_2">Sidebar 2</SelectItem>
                    <SelectItem value="sidebar_3">Sidebar 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label htmlFor="image_file">Image File</Label><Input id="image_file" type="file" onChange={handleFileChange} accept="image/*" required className="bg-gray-800 border-gray-600" /></div>
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <PlusCircle className="mr-2 h-4 w-4" />} Add Ad
            </Button>
          </form>
        </CardContent>
      </Card>
      <Card className="bg-gray-900/50 border border-gray-700">
        <CardHeader><CardTitle>Manage Advertisements</CardTitle></CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow className="hover:bg-transparent border-gray-700"><TableHead>Preview</TableHead><TableHead>Name</TableHead><TableHead>Location</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {loading ? <TableRow><TableCell colSpan={5} className="text-center py-8"><Loader2 className="mx-auto h-8 w-8 animate-spin" /></TableCell></TableRow>
                : ads.map(ad => (
                  <TableRow key={ad.id} className="border-gray-700">
                    <TableCell><img-replace src={ad.image_url} alt="Ad preview" className="h-16 w-32 object-contain rounded-md bg-gray-700" /></TableCell>
                    <TableCell className="font-medium">{ad.name}</TableCell>
                    <TableCell>{ad.location}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => toggleAdStatus(ad)}>
                        {ad.is_active ? <ToggleRight className="h-6 w-6 text-green-500" /> : <ToggleLeft className="h-6 w-6 text-gray-500" />}
                      </Button>
                    </TableCell>
                    <TableCell><Button variant="destructive" size="sm" onClick={() => handleDeleteAd(ad)}><Trash2 className="h-4 w-4" /></Button></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdManagement;