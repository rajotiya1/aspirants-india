import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Edit, Trash2, Trophy, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useTargetUserId } from '@/hooks/useTargetUserId';
import { motion } from 'framer-motion';

const preMainsOptions = ["Passed", "Failed"];
const interviewOptions = ["Faced", "Not Faced", "Not Required"];
const finalResultOptions = ["Selected", "Not Selected"];

const AchievementField = ({ label, children }) => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-1 md:gap-4 items-start">
    <Label className="md:text-right text-sm font-semibold uppercase text-muted-foreground pt-2">{label}</Label>
    <div className="md:col-span-2">{children}</div>
  </div>
);

const AchievementsTab = () => {
  const { user } = useAuth();
  const targetUserId = useTargetUserId();
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [currentAchievement, setCurrentAchievement] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const { toast } = useToast();

  const isOwnProfile = user?.id === targetUserId;

  const fetchAchievements = useCallback(async () => {
    if (!targetUserId) {
        setLoading(false);
        return;
    };
    setLoading(true);

    try {
      const { data, error } = await supabase.from('job_achievements').select('*').eq('user_id', targetUserId).order('held_on_year', { ascending: false });
      if (error) {
        throw error;
      } else {
        setAchievements(data || []);
      }
    } catch (error) {
      toast({ title: 'Error fetching achievements', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    if (targetUserId) {
        fetchAchievements();
    }
  }, [fetchAchievements, targetUserId]);

  const handleOpenDialog = (achievement = null) => {
    setIsEditing(!!achievement);
    setCurrentAchievement(achievement || { 
      exam_name: '', 
      held_on_year: '', 
      pre_status: null, 
      mains_status: null, 
      interview_status: null, 
      final_result: null, 
      experience: '' 
    });
    setOpenDialog(true);
  };

  const handleSave = async () => {
    if (!targetUserId) return;
    const achievementToSave = { ...currentAchievement, user_id: targetUserId };
    
    let query;
    if (isEditing) {
      query = supabase.from('job_achievements').update(achievementToSave).eq('id', currentAchievement.id);
    } else {
      delete achievementToSave.id;
      query = supabase.from('job_achievements').insert(achievementToSave);
    }
    const { error } = await query;
    if (error) {
      toast({ title: 'Error saving achievement', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: `Achievement ${isEditing ? 'updated' : 'added'}.` });
      setOpenDialog(false);
      fetchAchievements();
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this entry?")) return;
    const { error } = await supabase.from('job_achievements').delete().eq('id', id);
    if (error) {
      toast({ title: 'Error deleting achievement', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Achievement deleted.' });
      fetchAchievements();
    }
  };

  const handleDialogInputChange = (key, value) => {
    setCurrentAchievement(prev => ({ ...prev, [key]: value }));
  };

  if (loading) {
    return <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <div className="space-y-6 p-4">
      {isOwnProfile && (
        <div className="text-right">
          <Button onClick={() => handleOpenDialog()}><Plus className="w-4 h-4 mr-2" />Add New Achievement</Button>
        </div>
      )}
      {achievements.length > 0 ? (
        <div className="space-y-4">
          {achievements.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-card border rounded-lg shadow-sm overflow-hidden"
            >
              <div className="p-4 flex justify-between items-start bg-secondary/30">
                 <div className="flex items-center gap-3">
                  <div className="bg-primary/10 text-primary p-2 rounded-full">
                    <Award className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">{item.exam_name}</h3>
                </div>
                {isOwnProfile && (
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleOpenDialog(item)}><Edit className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(item.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                )}
              </div>
              <div className="p-4 grid grid-cols-1 gap-y-4">
                  <AchievementField label="Year"><p>{item.held_on_year || '-'}</p></AchievementField>
                  <AchievementField label="Pre-Exam"><p>{item.pre_status || '-'}</p></AchievementField>
                  <AchievementField label="Mains"><p>{item.mains_status || '-'}</p></AchievementField>
                  <AchievementField label="Interview"><p>{item.interview_status || '-'}</p></AchievementField>
                  <AchievementField label="Final Result"><p className="font-bold">{item.final_result || '-'}</p></AchievementField>
                  <AchievementField label="Your Experience">
                    <p className="text-sm text-muted-foreground whitespace-pre-wrap">{item.experience || 'No experience notes added.'}</p>
                  </AchievementField>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
         <div className="text-center py-16 text-muted-foreground bg-secondary/20 rounded-lg">
          <Trophy className="mx-auto w-12 h-12 mb-4" />
          <p className="font-semibold">No achievements added yet.</p>
          {isOwnProfile && <p className="text-sm mt-1">Click 'Add New Achievement' to get started.</p>}
        </div>
      )}

      {currentAchievement && (
        <Dialog open={openDialog} onOpenChange={setOpenDialog}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>{isEditing ? 'Edit' : 'Add'} Govt Job Achievement</DialogTitle>
              <DialogDescription>
                Fill in the details of the government job exam you attempted.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <AchievementField label="Exam/Job Name">
                <Input id="exam_name" value={currentAchievement.exam_name} onChange={(e) => handleDialogInputChange('exam_name', e.target.value)} />
              </AchievementField>
              <AchievementField label="Year">
                <Input id="held_on_year" type="number" value={currentAchievement.held_on_year} onChange={(e) => handleDialogInputChange('held_on_year', e.target.value)} />
              </AchievementField>
              <AchievementField label="Pre-Exam">
                 <Select value={currentAchievement.pre_status || ""} onValueChange={(value) => handleDialogInputChange('pre_status', value)}>
                    <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                    <SelectContent>
                      {preMainsOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                  </Select>
              </AchievementField>
              <AchievementField label="Mains">
                <Select value={currentAchievement.mains_status || ""} onValueChange={(value) => handleDialogInputChange('mains_status', value)}>
                  <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                  <SelectContent>
                    {preMainsOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                  </SelectContent>
                </Select>
              </AchievementField>
              <AchievementField label="Interview">
                 <Select value={currentAchievement.interview_status || ""} onValueChange={(value) => handleDialogInputChange('interview_status', value)}>
                  <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                  <SelectContent>
                    {interviewOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                  </SelectContent>
                </Select>
              </AchievementField>
              <AchievementField label="Final Result">
                <Select value={currentAchievement.final_result || ""} onValueChange={(value) => handleDialogInputChange('final_result', value)}>
                  <SelectTrigger><SelectValue placeholder="Select Status" /></SelectTrigger>
                  <SelectContent>
                    {finalResultOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                  </SelectContent>
                </Select>
              </AchievementField>
              <AchievementField label="Your Experience">
                <Textarea id="experience" value={currentAchievement.experience} onChange={(e) => handleDialogInputChange('experience', e.target.value)} placeholder="Write any notes or your experience here..." />
              </AchievementField>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpenDialog(false)}>Cancel</Button>
              <Button onClick={handleSave}>Save changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default AchievementsTab;