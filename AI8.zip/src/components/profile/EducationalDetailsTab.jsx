import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Edit, Trash2, BookOpen, GraduationCap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useTargetUserId } from '@/hooks/useTargetUserId';
import { motion } from 'framer-motion';

const DetailRow = ({ label, value }) => (
  <div className="flex flex-col sm:flex-row sm:items-center">
    <p className="w-full sm:w-1/3 text-sm font-semibold uppercase text-muted-foreground">{label}</p>
    <p className="w-full sm:w-2/3 text-foreground">{value || '-'}</p>
  </div>
);

const EducationalDetailsTab = () => {
  const { user } = useAuth();
  const targetUserId = useTargetUserId();
  const [details, setDetails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [currentDetail, setCurrentDetail] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const { toast } = useToast();

  const isOwnProfile = user?.id === targetUserId;

  const fetchDetails = useCallback(async () => {
    if (!targetUserId) {
        setLoading(false);
        return;
    };
    setLoading(true);

    try {
      const { data, error } = await supabase.from('educational_details').select('*').eq('user_id', targetUserId).order('year_of_passing', { ascending: false });
      if (error) {
        throw error;
      } else {
        setDetails(data || []);
      }
    } catch (error) {
      toast({ title: 'Error fetching educational details', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    if (targetUserId) {
        fetchDetails();
    }
  }, [fetchDetails, targetUserId]);

  const handleOpenDialog = (detail = null) => {
    setIsEditing(!!detail);
    setCurrentDetail(detail || { class_degree: '', year_of_passing: '', board_university: '', school_college: '', passing_division: '' });
    setOpenDialog(true);
  };

  const handleSave = async () => {
    if (!targetUserId) return;
    const detailToSave = { ...currentDetail, user_id: targetUserId };
    let query;
    if (isEditing) {
      query = supabase.from('educational_details').update(detailToSave).eq('id', currentDetail.id);
    } else {
      delete detailToSave.id;
      query = supabase.from('educational_details').insert(detailToSave);
    }
    const { error } = await query;
    if (error) {
      toast({ title: 'Error saving details', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: `Educational detail ${isEditing ? 'updated' : 'added'}.` });
      setOpenDialog(false);
      fetchDetails();
    }
  };
  
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this entry?")) return;
    const { error } = await supabase.from('educational_details').delete().eq('id', id);
    if (error) {
      toast({ title: 'Error deleting detail', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Success', description: 'Educational detail deleted.' });
      fetchDetails();
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }
  
  return (
    <div className="space-y-6 p-4">
      {isOwnProfile && (
        <div className="text-right">
          <Button onClick={() => handleOpenDialog()}><Plus className="w-4 h-4 mr-2" />Add New Detail</Button>
        </div>
      )}
      {details.length > 0 ? (
        <div className="space-y-4">
          {details.map((detail, index) => (
            <motion.div
              key={detail.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="bg-card border rounded-lg shadow-sm overflow-hidden"
            >
              <div className="p-4 flex justify-between items-start bg-secondary/30">
                <div className="flex items-center gap-3">
                  <div className="bg-primary/10 text-primary p-2 rounded-full">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">{detail.class_degree}</h3>
                </div>
                {isOwnProfile && (
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleOpenDialog(detail)}><Edit className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => handleDelete(detail.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                )}
              </div>
              <div className="p-4 grid grid-cols-1 gap-y-3">
                <DetailRow label="Year" value={detail.year_of_passing} />
                <DetailRow label="Board/University" value={detail.board_university} />
                <DetailRow label="School/College" value={detail.school_college} />
                <DetailRow label="Division" value={detail.passing_division} />
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
         <div className="text-center py-16 text-muted-foreground bg-secondary/20 rounded-lg">
          <BookOpen className="mx-auto w-12 h-12 mb-4" />
          <p className="font-semibold">No educational details added yet.</p>
          {isOwnProfile && <p className="text-sm mt-1">Click 'Add New Detail' to get started.</p>}
        </div>
      )}

      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{isEditing ? 'Edit' : 'Add'} Educational Detail</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="class_degree" className="text-right">Class/Degree</Label>
              <Input id="class_degree" value={currentDetail?.class_degree || ''} onChange={(e) => setCurrentDetail({...currentDetail, class_degree: e.target.value})} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="year_of_passing" className="text-right">Year</Label>
              <Input id="year_of_passing" type="number" value={currentDetail?.year_of_passing || ''} onChange={(e) => setCurrentDetail({...currentDetail, year_of_passing: e.target.value})} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="board_university" className="text-right">Board/Univ.</Label>
              <Input id="board_university" value={currentDetail?.board_university || ''} onChange={(e) => setCurrentDetail({...currentDetail, board_university: e.target.value})} className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="school_college" className="text-right">School/College</Label>
              <Input id="school_college" value={currentDetail?.school_college || ''} onChange={(e) => setCurrentDetail({...currentDetail, school_college: e.target.value})} className="col-span-3" />
            </div>
             <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="passing_division" className="text-right">Division</Label>
              <Input id="passing_division" value={currentDetail?.passing_division || ''} onChange={(e) => setCurrentDetail({...currentDetail, passing_division: e.target.value})} className="col-span-3" />
            </div>
          </div>
          <DialogFooter>
             <Button variant="outline" onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EducationalDetailsTab;