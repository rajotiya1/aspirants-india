import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Trash2, Image as ImageIcon, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AnimatePresence, motion } from 'framer-motion';
import { useTargetUserId } from '@/hooks/useTargetUserId';

const PhotosTab = () => {
  const { user } = useAuth();
  const targetUserId = useTargetUserId();
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [page, setPage] = useState(0);
  const { toast } = useToast();

  const isOwnProfile = user?.id === targetUserId;
  const BUCKET_NAME = 'user_photos';

  const fetchPhotos = useCallback(async () => {
    if (!targetUserId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_photos')
        .select('*')
        .eq('user_id', targetUserId)
        .order('created_at');

      if (error) throw error;
      setPhotos(data || []);
    } catch (error) {
      toast({
        title: 'Error fetching photos',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    if (targetUserId) {
      fetchPhotos();
    } else {
      setLoading(false);
    }
  }, [fetchPhotos, targetUserId]);

  const handlePhotoUpload = async (e) => {
    if (photos.length >= 5) {
      toast({
        title: 'Upload limit reached',
        description: 'You can only upload a maximum of 5 photos.',
        variant: 'destructive'
      });
      return;
    }

    const file = e.target.files[0];
    if (!file || !targetUserId) return;

    setIsUploading(true);
    const fileExt = file.name.split('.').pop();
    const fileName = `${targetUserId}/${Date.now()}.${fileExt}`;

    try {
      const { error: uploadError } = await supabase.storage
        .from(BUCKET_NAME)
        .upload(fileName, file);
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from(BUCKET_NAME)
        .getPublicUrl(fileName);

      const { error: insertError } = await supabase
        .from('user_photos')
        .insert({ user_id: targetUserId, photo_url: publicUrl });
      if (insertError) throw insertError;

      toast({ title: 'Success', description: 'Photo uploaded successfully.' });
      fetchPhotos();
    } catch (error) {
      toast({
        title: 'Upload failed',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async (photoId, photoUrl) => {
    if (!window.confirm('Are you sure you want to delete this photo?')) return;
    if (!targetUserId) return;

    const path = new URL(photoUrl).pathname.split(`/${BUCKET_NAME}/`)[1];

    try {
      const { error: storageError } = await supabase.storage
        .from(BUCKET_NAME)
        .remove([path]);
      if (storageError) throw storageError;

      const { error: dbError } = await supabase
        .from('user_photos')
        .delete()
        .eq('id', photoId);
      if (dbError) throw dbError;

      toast({ title: 'Success', description: 'Photo deleted.' });
      setPage(0);
      fetchPhotos();
    } catch (error) {
      toast({
        title: 'Delete failed',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const paginate = (newDirection) => {
    if (photos.length === 0) return;
    setPage((p) => (p + newDirection + photos.length) % photos.length);
  };

  const variants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-10">
        <Loader2 className="w-8 h-8 animate-spin text-blue-400" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {isOwnProfile && (
        <div className="text-right">
          <Button asChild disabled={isUploading || photos.length >= 5}>
            <label>
              {isUploading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Plus className="w-4 h-4 mr-2" />
              )}
              Upload Photo
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handlePhotoUpload}
              />
            </label>
          </Button>
        </div>
      )}

      {photos.length > 0 ? (
        <Card className="relative w-full aspect-video overflow-hidden glass-effect">
          <AnimatePresence initial={false} custom={page}>
            <motion.img
              key={page}
              src={photos[page].photo_url}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: 'spring', stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
              className="absolute h-full w-full object-contain"
            />
          </AnimatePresence>
          <div className="absolute top-1/2 left-2 transform -translate-y-1/2">
            <Button onClick={() => paginate(-1)} size="icon" variant="secondary">
              <ChevronLeft />
            </Button>
          </div>
          <div className="absolute top-1/2 right-2 transform -translate-y-1/2">
            <Button onClick={() => paginate(1)} size="icon" variant="secondary">
              <ChevronRight />
            </Button>
          </div>
          {isOwnProfile && (
            <div className="absolute bottom-2 right-2">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => handleDelete(photos[page].id, photos[page].photo_url)}
              >
                <Trash2 className="w-4 h-4 mr-2" /> Delete
              </Button>
            </div>
          )}
        </Card>
      ) : (
        <div className="text-center py-10 text-gray-400">
          <ImageIcon className="mx-auto w-12 h-12 mb-4" />
          <p>No photos uploaded yet.</p>
        </div>
      )}
    </div>
  );
};

export default PhotosTab;