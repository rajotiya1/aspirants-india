import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Lock } from 'lucide-react';

const ProfileContentLock = ({ sectionName, profileOwnerName }) => {
  return (
    <div className="p-4">
      <Card className="text-center">
        <CardContent className="pt-10 flex flex-col items-center justify-center min-h-[300px]">
          <Lock className="w-12 h-12 text-primary mb-4" />
          <h3 className="text-xl font-semibold text-foreground">Content Locked</h3>
          <p className="text-muted-foreground mt-2">
            The {sectionName} for {profileOwnerName} are private or friends-only.
          </p>
          <p className="text-muted-foreground text-sm">
            Send a friend request to view this content if it's set to "Friends Only".
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfileContentLock;