import React, { useEffect, useState, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Briefcase, Trash2, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Table, TableHead, TableHeader, TableRow, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { motion } from "framer-motion";

const SavedJobsTab = ({ userId }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [savedJobs, setSavedJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  const isOwnProfile = user?.id === userId;

  const fetchSavedJobs = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("user_saved_jobs")
        .select("*, app_jobs(title, qualification, last_date)")
        .eq("user_id", userId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      setSavedJobs(data || []);
    } catch (err) {
      toast({ title: "Error fetching saved jobs", description: err.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [userId, toast]);

  useEffect(() => {
    fetchSavedJobs();
  }, [fetchSavedJobs]);

  const handleRemove = async (id) => {
    const { error } = await supabase.from("user_saved_jobs").delete().eq("id", id);
    if (error)
      toast({ title: "Error removing job", description: error.message, variant: "destructive" });
    else {
      setSavedJobs((prev) => prev.filter((j) => j.id !== id));
      toast({ title: "Removed", description: "Job removed successfully." });
    }
  };

  if (loading)
    return <div className="flex justify-center items-center py-10"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  if (!savedJobs.length)
    return (
      <Card className="text-center py-10">
        <Briefcase className="mx-auto w-10 h-10 text-muted-foreground" />
        <p className="mt-2 text-sm text-muted-foreground">
          {isOwnProfile ? "You haven't saved any jobs yet." : "No public saved jobs available."}
        </p>
      </Card>
    );

  return (
    <motion.div className="overflow-x-auto" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Post</TableHead>
            <TableHead>Qualification</TableHead>
            <TableHead>Last Date</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {savedJobs.map((job) => (
            <TableRow key={job.id}>
              <TableCell>{job.app_jobs?.title || "Untitled"}</TableCell>
              <TableCell>{job.app_jobs?.qualification || "-"}</TableCell>
              <TableCell>{job.app_jobs?.last_date || "-"}</TableCell>
              <TableCell className="text-right">
                {isOwnProfile ? (
                  <Button variant="destructive" size="icon" onClick={() => handleRemove(job.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                ) : (
                  <Eye className="w-4 h-4 text-muted-foreground" />
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </motion.div>
  );
};

export default SavedJobsTab;