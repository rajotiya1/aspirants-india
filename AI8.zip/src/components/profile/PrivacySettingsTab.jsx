import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, ShieldCheck, Lock, Users, Globe } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useDebounce } from '@/hooks/useDebounce';

const privacyOptions = [
  { value: 'public', label: 'Public', icon: Globe },
  { value: 'friends', label: 'Friends Only', icon: Users },
  { value: 'private', label: 'Private (Only Me)', icon: Lock },
];

const privacyItems = [
  { key: 'profile_pic', label: 'Profile Picture' },
  { key: 'stylish_pic', label: 'Stylish Picture' },
  { key: 'saved_jobs', label: 'Saved Jobs' },
  { key: 'educational_detail', label: 'Educational Detail' },
  { key: 'test_performance', label: 'Test Performance' },
  { key: 'govt_job_achievements', label: 'Govt Job Achievements' },
];

const defaultSettings = privacyItems.reduce((acc, item) => {
  acc[item.key] = 'friends';
  return acc;
}, {});

const PrivacySettingRow = ({ item, value, onChange }) => (
  <div className="flex items-center justify-between p-3 border-b last:border-b-0">
    <span className="font-medium text-foreground">{item.label}</span>
    <Select value={value} onValueChange={(newValue) => onChange(item.key, newValue)}>
      <SelectTrigger className="w-[180px]">
        <SelectValue placeholder="Select privacy" />
      </SelectTrigger>
      <SelectContent>
        {privacyOptions.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            <div className="flex items-center gap-2">
              <option.icon className="w-4 h-4 text-muted-foreground" />
              <span>{option.label}</span>
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  </div>
);

const PrivacySettingsTab = () => {
  const { user, refreshProfile } = useAuth();
  const [settings, setSettings] = useState(null);
  const [lastSaved, setLastSaved] = useState(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const isInitialLoad = useRef(true);

  const debouncedSettings = useDebounce(settings, 1200);

  // 🧩 Load settings once
  useEffect(() => {
    if (user) {
      const userSettings = user.privacy_settings || {};
      setSettings({ ...defaultSettings, ...userSettings });
      setLastSaved(JSON.stringify({ ...defaultSettings, ...userSettings }));
      setLoading(false);
    }
  }, [user]);

  const handleSettingChange = (key, value) => {
    isInitialLoad.current = false;
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  // 💾 Save settings only if changed
  const saveSettings = useCallback(
    async (newSettings) => {
      if (!user || !newSettings) return;

      const currentJSON = JSON.stringify(newSettings);
      if (currentJSON === lastSaved) return; // No actual change

      const { error } = await supabase
        .from('profiles')
        .update({ privacy_settings: newSettings })
        .eq('id', user.id);

      if (error) {
        toast({ title: 'Error saving settings', description: error.message, variant: 'destructive' });
      } else {
        setLastSaved(currentJSON);
        toast({ title: 'Settings Saved', description: 'Your privacy settings have been updated.' });
        await refreshProfile();
      }
    },
    [user, lastSaved, toast, refreshProfile]
  );

  // 🧠 Run saver only when necessary
  useEffect(() => {
    if (debouncedSettings && !loading && !isInitialLoad.current) {
      saveSettings(debouncedSettings);
    }
  }, [debouncedSettings, saveSettings, loading]);

  if (loading || !settings) {
    return (
      <div className="flex justify-center items-center h-full pt-10">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="p-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldCheck /> Privacy Settings
          </CardTitle>
          <CardDescription>
            Control who can see your profile information. Changes are saved automatically.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg overflow-hidden">
            {privacyItems.map((item) => (
              <PrivacySettingRow
                key={item.key}
                item={item}
                value={settings[item.key] || 'friends'}
                onChange={handleSettingChange}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrivacySettingsTab;