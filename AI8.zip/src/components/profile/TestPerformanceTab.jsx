import React, { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { useTargetUserId } from "@/hooks/useTargetUserId";
import { useToast } from "@/components/ui/use-toast";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Loader2, CalendarDays } from "lucide-react";
import { motion } from "framer-motion";
import { formatDate } from "@/lib/utils";

// ⭐ Import category name mapping
import { getCategoryName } from "@/data/categoryNames";

const TestPerformanceTab = () => {
  const targetUserId = useTargetUserId();
  const { user } = useAuth();
  const { toast } = useToast();
  const [performance, setPerformance] = useState([]);
  const [loading, setLoading] = useState(true);
  const isOwnProfile = user?.id === targetUserId;

  const fetchPerformance = useCallback(async () => {
    if (!targetUserId) {
      setLoading(false);
      return;
    }
    setLoading(true);

    try {
      const { data, error } = await supabase
        .from("daily_leaderboard")
        .select("*")
        .eq("user_id", targetUserId)
        .order("date", { ascending: false });

      if (error) throw error;
      setPerformance(data || []);
    } catch (error) {
      console.error("Error fetching performance:", error);
      toast({
        title: "Error fetching test performance",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [targetUserId, toast]);

  useEffect(() => {
    if (targetUserId) fetchPerformance();
  }, [fetchPerformance, targetUserId]);

  if (loading) {
    return (
      <div className="flex justify-center items-center py-10">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  if (performance.length === 0) {
    return (
      <Card className="glass-effect p-4 border-0 shadow-none">
        <div className="text-center py-10 text-gray-400">
          <CalendarDays className="mx-auto w-12 h-12 mb-4" />
          <p>
            {isOwnProfile
              ? "आपने अभी तक कोई टेस्ट नहीं दिया है।"
              : "इस यूज़र का कोई टेस्ट परफॉर्मेंस डेटा उपलब्ध नहीं है।"}
          </p>
        </div>
      </Card>
    );
  }

  // Group by date
  const grouped = performance.reduce((acc, item) => {
    const date = item.date.split("T")[0];
    if (!acc[date]) acc[date] = [];
    acc[date].push(item);
    return acc;
  }, {});

  return (
    <div className="space-y-8">
      {Object.entries(grouped).map(([date, items], index) => (
        <motion.div
          key={date}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <h2 className="text-lg font-semibold text-primary mb-3 border-b border-gray-300 pb-1">
            📅 {formatDate(date)}
          </h2>

          <Card className="glass-effect border-white/20 shadow-none border-0 p-4">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exam Name</TableHead>
                    <TableHead className="text-center">Right</TableHead>
                    <TableHead className="text-center">Wrong</TableHead>
                    <TableHead className="text-center">Rank</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {items.map((item) => (
                    <TableRow key={item.id}>
<TableCell className="font-medium">
  {getCategoryName(item.category)}
</TableCell>

                      <TableCell className="text-center text-green-500 font-bold">
                        {item.correct}
                      </TableCell>

                      <TableCell className="text-center text-red-500 font-bold">
                        {item.wrong}
                      </TableCell>

                      <TableCell className="text-center font-bold">
                        #{item.rank}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  );
};

export default TestPerformanceTab;