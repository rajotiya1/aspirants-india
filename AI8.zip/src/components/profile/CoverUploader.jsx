import React, { useState, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Loader2, Camera, Trash2 } from 'lucide-react';

// ✅ Moderate image before upload
const moderateImage = async (base64Image) => {
  const cleanBase64 = base64Image.split(',')[1];
  const { data, error } = await supabase.functions.invoke('moderate-image', {
    body: { image: cleanBase64 },
  });

  if (error) {
    throw new Error(`Moderation check failed: ${error.message}`);
  }

  if (data?.isExplicit) {
    throw new Error('This image cannot be used. Please upload a safe and appropriate photo.');
  }

  return true;
};

const CoverUploader = ({ profile, onUploadComplete }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // ✅ Handle Upload
  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file || !user) return;

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const base64Image = reader.result;
      setIsUploading(true);

      try {
        await moderateImage(base64Image);

        const filePath = `${user.id}/${Date.now()}`;
        const { error: uploadError } = await supabase.storage.from('stylish_pic').upload(filePath, file);
        if (uploadError) throw uploadError;

        if (profile.stylish_pic_url) {
          const oldFilePath = profile.stylish_pic_url.split('/').slice(-2).join('/');
          await supabase.storage.from('stylish_pic').remove([oldFilePath]);
        }

        const { data: publicUrlData } = supabase.storage.from('stylish_pic').getPublicUrl(filePath);

        const { error: dbError } = await supabase
          .from('profiles')
          .update({ stylish_pic_url: publicUrlData.publicUrl, updated_at: new Date().toISOString() })
          .eq('id', user.id);

        if (dbError) throw dbError;

        toast({ title: 'Cover photo updated!' });
        onUploadComplete();
      } catch (error) {
        toast({ title: 'Upload Failed', description: error.message, variant: 'destructive' });
      } finally {
        setIsUploading(false);
        event.target.value = null;
      }
    };
  };

  // ✅ Handle Delete
  const handleDelete = async () => {
    if (!profile.stylish_pic_url || !user) return;
    setIsDeleting(true);
    try {
      const filePath = profile.stylish_pic_url.split('/').slice(-2).join('/');
      const { error: deleteError } = await supabase.storage.from('stylish_pic').remove([filePath]);
      if (deleteError) throw deleteError;

      const { error: dbError } = await supabase
        .from('profiles')
        .update({ stylish_pic_url: null, updated_at: new Date().toISOString() })
        .eq('id', user.id);
      if (dbError) throw dbError;

      toast({ title: 'Cover photo removed.' });
      onUploadComplete();
    } catch (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <div className="relative group h-[140px] sm:h-[180px] md:h-[240px] bg-secondary rounded-b-lg shadow-lg overflow-hidden">
      {/* ✅ Cover Image */}
      {profile.stylish_pic_url ? (
        <img
          src={`${profile.stylish_pic_url}?t=${new Date(profile.updated_at).getTime()}`}
          alt="Cover"
          className="w-full h-full object-cover object-center"
          style={{ objectPosition: 'center center' }}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-indigo-200">
          <span className="text-indigo-400 font-medium">No cover image</span>
        </div>
      )}

      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-b-lg pointer-events-none" />

      {/* Upload/Delete buttons */}
      {user && user.id === profile.id && (
        <div className="absolute top-2 right-2 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            size="icon"
            variant="secondary"
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
          >
            {isUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
          </Button>
          {profile.stylish_pic_url && (
            <Button
              size="icon"
              variant="destructive"
              onClick={() => setShowDeleteConfirm(true)}
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            </Button>
          )}
        </div>
      )}

      {/* Hidden input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
        disabled={isUploading}
      />

      {/* Delete confirmation dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete your cover photo.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={isDeleting}>
              {isDeleting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default CoverUploader;