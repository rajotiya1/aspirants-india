import React, { useState, useRef } from 'react';
import Cropper from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Loader2 } from 'lucide-react';

const moderateImage = async (base64Image) => {
  const cleanBase64 = base64Image.split(',')[1];
  const { data, error } = await supabase.functions.invoke('moderate-image', {
    body: { image: cleanBase64 },
  });

  if (error) {
    throw new Error(`Moderation check failed: ${error.message}`);
  }

  if (data?.isExplicit) {
    throw new Error('This image cannot be used. Please upload a safe and appropriate photo.');
  }

  return true;
};

const AvatarEditor = ({ src, onSave, onCancel }) => {
  const { user, refreshProfile } = useAuth();
  const cropperRef = useRef(null);
  const [zoom, setZoom] = useState(0.1);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleZoom = (value) => {
    const cropper = cropperRef.current?.cropper;
    if (cropper) {
      cropper.zoomTo(value[0]);
      setZoom(value[0]);
    }
  };
  
  const dataURLtoBlob = async (dataurl) => {
    const res = await fetch(dataurl);
    return await res.blob();
  }

  const handleSave = async () => {
    if (typeof cropperRef.current?.cropper === 'undefined' || !user) {
      return;
    }
    
    setIsUploading(true);
    
    const oldPath = user.avatar_path;
    const fileExtension = 'webp';
    const newPath = `${user.id}/${Date.now()}.${fileExtension}`;
    let uploadedPath = null;

    try {
      const canvas = cropperRef.current.cropper.getCroppedCanvas({
        width: 256,
        height: 256,
        imageSmoothingQuality: 'high',
      });

      const dataUrl = canvas.toDataURL('image/webp', 0.9);
      
      await moderateImage(dataUrl);
      
      const blob = await dataURLtoBlob(dataUrl);

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(newPath, blob, { contentType: 'image/webp', upsert: false });

      if (uploadError) throw new Error(`Upload failed: ${uploadError.message}`);
      uploadedPath = newPath;

      const { error: dbError } = await supabase
        .from('profiles')
        .update({ avatar_path: newPath, updated_at: new Date().toISOString() })
        .eq('id', user.id);

      if (dbError) throw new Error(`Database update failed: ${dbError.message}`);

      if (oldPath && oldPath !== newPath) {
        const { error: deleteError } = await supabase.storage.from('avatars').remove([oldPath]);
        if (deleteError) {
          console.error("Failed to delete old avatar:", deleteError);
          toast({ title: 'Old avatar cleanup failed', description: 'Your new avatar is saved, but we couldn’t remove the old one.', variant: 'default' });
        }
      }
            
      await refreshProfile();
      toast({ title: 'Avatar updated!', description: 'Your new profile picture has been saved.' });
      if (onSave) onSave();

    } catch (err) {
      toast({ title: 'Update failed', description: err.message, variant: 'destructive' });
      
      if (uploadedPath) {
        await supabase.storage.from('avatars').remove([uploadedPath]);
      }
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={!!src} onOpenChange={(open) => !open && onCancel()}>
      <DialogContent className="glass-effect border-white/20">
        <DialogHeader>
          <DialogTitle>Edit Profile Picture</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="w-full h-80 bg-slate-800">
            <Cropper
              ref={cropperRef}
              src={src}
              style={{ height: '100%', width: '100%' }}
              viewMode={1}
              aspectRatio={1}
              minCropBoxHeight={50}
              minCropBoxWidth={50}
              background={false}
              responsive={true}
              autoCropArea={1}
              checkOrientation={false}
              guides={true}
              ready={() => handleZoom([zoom])}
            />
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm">Zoom</span>
            <Slider
              value={[zoom]}
              onValueChange={handleZoom}
              min={0.1}
              max={2}
              step={0.01}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={handleSave} disabled={isUploading}>
            {isUploading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AvatarEditor;