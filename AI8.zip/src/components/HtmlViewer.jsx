
import React from 'react';
import { Helmet } from 'react-helmet-async';

const HtmlViewer = ({ src, title = "Content Viewer" }) => {
  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={`Viewing content for ${title}`} />
      </Helmet>
      <iframe
        src={src}
        title={title}
        style={{ width: '100%', height: '100vh', border: 'none', background: 'white' }}
      ></iframe>
    </>
  );
};

export default HtmlViewer;
