
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ArrowDown, Wallet } from 'lucide-react';

const ResultRow = ({ label, value, type = 'neutral', isBold = false, subtext, className }) => {
  const colorClass = {
    positive: 'text-green-600',
    negative: 'text-red-500',
    highlight: 'text-blue-600',
    neutral: 'text-slate-700'
  }[type];

  return (
    <div className={`flex justify-between items-baseline py-1 ${className}`}>
      <div className="truncate pr-2">
        <p className={`text-xs sm:text-sm ${isBold ? 'font-semibold' : 'font-medium text-slate-500'}`}>{label}</p>
        {subtext && <p className="text-[10px] text-slate-400 leading-none">{subtext}</p>}
      </div>
      <p className={`font-mono whitespace-nowrap ${isBold ? 'text-sm sm:text-base font-bold' : 'text-xs sm:text-sm font-medium'} ${colorClass}`}>
        {value}
      </p>
    </div>
  );
};

const SalaryResults = ({ results }) => {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-3 h-full">
      {/* Net Salary Highlight Card - Compact */}
      <Card className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border-none shadow-lg overflow-hidden relative">
        <div className="absolute top-0 right-0 w-20 h-20 bg-white/5 rounded-bl-full -mr-4 -mt-4 pointer-events-none" />
        <CardContent className="p-4 sm:p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-slate-400 text-[10px] sm:text-xs font-medium uppercase tracking-wider mb-0.5">
              <Wallet className="w-3 h-3 sm:w-3.5 sm:h-3.5" /> Net Monthly Salary
            </div>
            <div className="text-2xl sm:text-3xl font-bold text-green-400 tracking-tight leading-none">
              {formatCurrency(results.net)}
            </div>
          </div>
          <div className="text-right">
             <div className="text-[10px] sm:text-xs text-slate-400">Annual CTC</div>
             <div className="text-sm sm:text-base font-semibold text-slate-200">{formatCurrency(results.annual)}</div>
          </div>
        </CardContent>
      </Card>

      {/* Breakdown Card - Condensed */}
      <Card className="shadow-sm border-slate-200">
        <CardContent className="p-3 sm:p-4 space-y-3">
          
          {/* Earnings Grid */}
          <div>
            <h4 className="text-[10px] font-bold text-green-600 uppercase tracking-wider mb-2 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span> Earnings
            </h4>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              <ResultRow label="Basic Pay" value={formatCurrency(results.basic)} />
              <ResultRow label={`DA (${results.daPercent}%)`} value={formatCurrency(results.daAmount)} />
              <ResultRow label={`HRA (${results.hraPercent}%)`} value={formatCurrency(results.hraAmount)} />
              {(results.ta > 0 || results.others > 0) && (
                 <>
                   {results.ta > 0 && <ResultRow label="Transport" value={formatCurrency(results.ta)} />}
                   {results.others > 0 && <ResultRow label="Others" value={formatCurrency(results.others)} />}
                 </>
              )}
            </div>
            <div className="mt-2 pt-1 border-t border-slate-100 flex justify-between items-center">
              <span className="text-xs font-semibold text-slate-700">Gross Salary</span>
              <span className="text-sm font-bold text-blue-600 font-mono">{formatCurrency(results.gross)}</span>
            </div>
          </div>

          {/* Deductions Grid */}
          <div className="bg-red-50/50 rounded-md p-2.5 -mx-1 border border-red-100/50">
            <h4 className="text-[10px] font-bold text-red-600 uppercase tracking-wider mb-2 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span> Deductions
            </h4>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              <ResultRow label="PF / NPS" value={`-${formatCurrency(results.pf)}`} type="negative" />
              {results.it > 0 && <ResultRow label="Income Tax" value={`-${formatCurrency(results.it)}`} type="negative" />}
              {(results.pt > 0 || results.deductions > 0) && (
                 <ResultRow 
                     label="Other Ded." 
                     value={`-${formatCurrency(results.pt + results.deductions)}`} 
                     type="negative" 
                 />
              )}
            </div>
             <div className="mt-2 pt-1 border-t border-red-200/50 flex justify-between items-center">
                <div className="flex items-center gap-1 text-red-700 text-xs font-semibold">
                   Total Deductions
                </div>
                <span className="font-bold text-red-600 font-mono text-sm">-{formatCurrency(results.totalDeductions)}</span>
             </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
};

export default SalaryResults;
