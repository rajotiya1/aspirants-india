
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const SalaryForm = ({ values, onChange, onPresetChange }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    // Prevent negative numbers
    const numValue = parseFloat(value) >= 0 ? parseFloat(value) : '';
    onChange(name, numValue);
  };

  return (
    <Card className="h-full shadow-md border-slate-200">
      <CardHeader className="bg-slate-50 pb-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <CardTitle className="text-lg font-semibold text-slate-800">Salary Details</CardTitle>
          <div className="w-full md:w-48">
            <Select onValueChange={onPresetChange} defaultValue="custom">
              <SelectTrigger>
                <SelectValue placeholder="Select Template" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="central">Central Govt (7th CPC)</SelectItem>
                <SelectItem value="state_x">State Govt (X City)</SelectItem>
                <SelectItem value="state_y">State Govt (Y City)</SelectItem>
                <SelectItem value="bank">Bank PO/Clerk</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 pt-6">
        
        {/* Earnings Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-green-600 uppercase tracking-wider border-b border-green-100 pb-2">Earnings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="basic" className="text-slate-600">Basic Pay (₹)</Label>
              <Input
                type="number"
                id="basic"
                name="basic"
                value={values.basic || ''}
                onChange={handleChange}
                placeholder="e.g. 44900"
                className="font-medium"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="daPercent" className="text-slate-600">DA (%)</Label>
                <Input
                  type="number"
                  id="daPercent"
                  name="daPercent"
                  value={values.daPercent || ''}
                  onChange={handleChange}
                  placeholder="50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hraPercent" className="text-slate-600">HRA (%)</Label>
                <Input
                  type="number"
                  id="hraPercent"
                  name="hraPercent"
                  value={values.hraPercent || ''}
                  onChange={handleChange}
                  placeholder="27"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ta" className="text-slate-600">Transport Allowance (₹)</Label>
              <Input
                type="number"
                id="ta"
                name="ta"
                value={values.ta || ''}
                onChange={handleChange}
                placeholder="e.g. 3600"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="others" className="text-slate-600">Other Allowances (₹)</Label>
              <Input
                type="number"
                id="others"
                name="others"
                value={values.others || ''}
                onChange={handleChange}
                placeholder="Special pay, Bonus etc."
              />
            </div>
          </div>
        </div>

        {/* Deductions Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-red-600 uppercase tracking-wider border-b border-red-100 pb-2">Deductions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="pf" className="text-slate-600">Provident Fund / NPS (₹)</Label>
              <Input
                type="number"
                id="pf"
                name="pf"
                value={values.pf || ''}
                onChange={handleChange}
                placeholder="e.g. 5000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="it" className="text-slate-600">Income Tax (TDS) (₹)</Label>
              <Input
                type="number"
                id="it"
                name="it"
                value={values.it || ''}
                onChange={handleChange}
                placeholder="Monthly TDS"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pt" className="text-slate-600">Professional Tax (₹)</Label>
              <Input
                type="number"
                id="pt"
                name="pt"
                value={values.pt || ''}
                onChange={handleChange}
                placeholder="e.g. 200"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="deductions" className="text-slate-600">Other Deductions (₹)</Label>
              <Input
                type="number"
                id="deductions"
                name="deductions"
                value={values.deductions || ''}
                onChange={handleChange}
                placeholder="Loan recovery, Insurance etc."
              />
            </div>
          </div>
        </div>

      </CardContent>
    </Card>
  );
};

export default SalaryForm;
