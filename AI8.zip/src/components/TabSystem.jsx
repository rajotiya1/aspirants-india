import React, { useRef, useEffect, useState, Suspense, memo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const SkeletonLoader = () => (
  <div className="w-full h-full p-4 space-y-4">
    <div className="h-24 bg-muted rounded-lg animate-pulse"></div>
    <div className="h-10 bg-muted rounded-lg animate-pulse w-3/4"></div>
    <div className="space-y-2 pt-4">
      <div className="h-8 bg-muted rounded-lg animate-pulse"></div>
      <div className="h-8 bg-muted rounded-lg animate-pulse"></div>
      <div className="h-8 bg-muted rounded-lg animate-pulse"></div>
    </div>
  </div>
);

// ★★★★★ ONLY CHANGE DONE HERE → Page-specific tab centering
const TabBar = memo(({ tabs, activeIndex, onTabClick, tabsRef }) => (
  <div className="p-2 bg-muted sticky top-0 z-20">
    <div
      ref={tabsRef}
      className={cn(
        "flex items-center space-x-2 overflow-x-auto no-scrollbar",
        window.location.pathname.startsWith("/app/jobs") && "justify-center"
      )}
    >
      <AnimatePresence>
        {tabs.map((tab, index) => {
          const isActive = activeIndex === index;
          return (
            <button
              key={tab.path || tab.label}
              onClick={() => onTabClick(index)}
              className={cn(
                "relative shrink-0 whitespace-nowrap rounded-md px-4 py-1.5 text-sm font-medium transition-colors duration-200",
                isActive
                  ? "text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {isActive && (
                <motion.div
                  className="absolute inset-0 bg-primary rounded-md"
                  layoutId="active-pill-indicator"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{tab.label}</span>
            </button>
          );
        })}
      </AnimatePresence>
    </div>
  </div>
));

const normalize = (p = "") => (p ? p.replace(/\/$/, "") : "");

const TabSystem = ({ tabs = [], basepath = "/app/profile" }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const swiperRef = useRef(null);
  const tabsRef = useRef(null);
  const [activeIndex, setActiveIndex] = useState(0);

  // Detect active tab from URL
  useEffect(() => {
    const currentPath = normalize(location.pathname);
    const currentQuery = location.search || "";

    const foundIndex = (tabs || []).findIndex((tab) => {
      const tabFullPath = normalize(`${basepath}/${tab.path || ""}`);
      const [tabPath, tabQuery] = tabFullPath.split("?");

      const pathMatches =
        currentPath === tabPath || currentPath.startsWith(`${tabPath}/`);
      const queryMatches = tabQuery ? currentQuery === `?${tabQuery}` : true;

      return pathMatches && queryMatches;
    });

    let targetIndex = foundIndex !== -1 ? foundIndex : 0;

    if (
      (location.pathname === basepath || location.pathname === `${basepath}/`) &&
      !currentQuery
    ) {
      targetIndex = 0;
    }

    if (targetIndex !== activeIndex) {
      setActiveIndex(targetIndex);
    }
  }, [location.pathname, location.search, tabs, basepath, activeIndex]);

  // Sync swiper with activeIndex
  useEffect(() => {
    const swiper = swiperRef.current?.swiper;
    if (!swiper) return;

    if (!swiper.destroyed && swiper.activeIndex !== activeIndex) {
      swiper.slideTo(activeIndex, 0);
    }

    try {
      swiper.updateAutoHeight();
    } catch (e) { }
  }, [activeIndex]);

  // Auto-scroll active tab into center
  useEffect(() => {
    if (tabsRef.current) {
      const activeButton = tabsRef.current.children[activeIndex];
      if (activeButton) {
        activeButton.scrollIntoView({
          behavior: "smooth",
          inline: "center",
          block: "nearest",
        });
      }
    }
  }, [activeIndex]);

  // Image load → recalc height
  useEffect(() => {
    const observer = new MutationObserver(() => {
      try {
        swiperRef.current?.swiper?.updateAutoHeight();
      } catch (e) { }
    });

    const slidesContainer = document.querySelector(".swiper-wrapper");
    if (slidesContainer) {
      observer.observe(slidesContainer, {
        childList: true,
        subtree: true,
        attributes: true,
      });
    }

    const onImgLoad = () => {
      try {
        swiperRef.current?.swiper?.updateAutoHeight();
      } catch (e) { }
    };

    const imgs = document.querySelectorAll(".swiper-slide img");
    imgs.forEach((img) => img.addEventListener("load", onImgLoad));

    window.addEventListener("load", onImgLoad);

    return () => {
      observer.disconnect();
      imgs.forEach((img) => img.removeEventListener("load", onImgLoad));
      window.removeEventListener("load", onImgLoad);
    };
  }, []);

  const handleTabClick = (index) => {
    if (swiperRef.current?.swiper) {
      swiperRef.current.swiper.slideTo(index);
    }
  };

  const handleSlideChange = (swiper) => {
    const newIndex = swiper.activeIndex;

    if (newIndex !== activeIndex) {
      const newPath = tabs[newIndex]?.path;
      if (newPath) {
        const target = normalize(`${basepath}/${newPath}`);
        if (normalize(location.pathname) !== target) {
          navigate(target, { replace: true });
        }
      }
    }

    setActiveIndex(newIndex);
  };

  return (
    <div className="w-full bg-background flex flex-col">
      <header className="flex-shrink-0 z-20">
        <TabBar
          tabs={tabs}
          activeIndex={activeIndex}
          onTabClick={handleTabClick}
          tabsRef={tabsRef}
        />
      </header>

      <main className="w-full">
        <Swiper
          ref={swiperRef}
          onInit={(swiper) => {
            try {
              swiper.updateAutoHeight();
            } catch (e) { }
          }}
          onSlideChange={handleSlideChange}
          onSlideChangeTransitionEnd={() => {
            try {
              swiperRef.current?.swiper?.updateAutoHeight();
            } catch (e) { }
          }}
          initialSlide={activeIndex}
          className="w-full"
          autoHeight={true}
          touchEventsTarget="container"
        >
          {tabs.map((tab) => (
            <SwiperSlide
              key={tab.path || tab.label}
              className="w-full min-h-[50vh] overflow-visible bg-background pb-20"
            >
              <Suspense fallback={<SkeletonLoader />}>
                {tab.component}
              </Suspense>
            </SwiperSlide>
          ))}
        </Swiper>
      </main>
    </div>
  );
};

export default TabSystem;
