import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { User, MapPin, Building, BookOpen, Calendar, Users as UsersIcon, Loader2 } from 'lucide-react';

const RegistrationForm = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    state: '',
    qualification: '',
    age: '',
    gender: '',
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSelectChange = (name, value) => {
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const requiredFields = ['name', 'address', 'city', 'state', 'qualification', 'age', 'gender'];
    for (const field of requiredFields) {
      if (!formData[field]) {
        toast({ title: "Error", description: `Please fill in the ${field} field.`, variant: "destructive" });
        return;
      }
    }

    setLoading(true);

    const { error } = await supabase
      .from('profiles')
      .update({ ...formData, age: parseInt(formData.age, 10) })
      .eq('id', user.id);

    if (error) {
      setLoading(false);
      toast({ title: "Update Error", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Success!", description: "Your profile has been updated." });
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white">
      <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="w-full max-w-lg">
        <Card className="glass-effect border-white/20">
          <CardHeader className="text-center">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.3, type: "spring" }} className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle className="text-2xl gradient-text">Complete Your Profile</CardTitle>
            <CardDescription className="text-gray-300">Just a few more details to get you started.</CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2"><Label htmlFor="name" className="flex items-center space-x-2"><User className="w-4 h-4" /><span>Full Name</span></Label><Input id="name" name="name" value={formData.name} onChange={handleInputChange} placeholder="Enter your full name" className="glass-effect border-white/30" /></div>
                <div className="space-y-2"><Label htmlFor="qualification" className="flex items-center space-x-2"><BookOpen className="w-4 h-4" /><span>Qualification</span></Label><Input id="qualification" name="qualification" value={formData.qualification} onChange={handleInputChange} placeholder="e.g., B.Tech, M.A." className="glass-effect border-white/30" /></div>
              </div>
              <div className="space-y-2"><Label htmlFor="address" className="flex items-center space-x-2"><MapPin className="w-4 h-4" /><span>Address</span></Label><Input id="address" name="address" value={formData.address} onChange={handleInputChange} placeholder="Enter your address" className="glass-effect border-white/30" /></div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2"><Label htmlFor="city" className="flex items-center space-x-2"><Building className="w-4 h-4" /><span>City</span></Label><Input id="city" name="city" value={formData.city} onChange={handleInputChange} placeholder="City" className="glass-effect border-white/30" /></div>
                <div className="space-y-2"><Label htmlFor="state">State</Label><Input id="state" name="state" value={formData.state} onChange={handleInputChange} placeholder="State" className="glass-effect border-white/30" /></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2"><Label htmlFor="age" className="flex items-center space-x-2"><Calendar className="w-4 h-4" /><span>Age</span></Label><Input id="age" name="age" type="number" value={formData.age} onChange={handleInputChange} placeholder="Your age" className="glass-effect border-white/30" /></div>
                <div className="space-y-2"><Label htmlFor="gender" className="flex items-center space-x-2"><UsersIcon className="w-4 h-4" /><span>Gender</span></Label>
                  <Select onValueChange={(value) => handleSelectChange('gender', value)} value={formData.gender}>
                    <SelectTrigger className="w-full glass-effect border-white/30"><SelectValue placeholder="Select gender" /></SelectTrigger>
                    <SelectContent><SelectItem value="Male">Male</SelectItem><SelectItem value="Female">Female</SelectItem><SelectItem value="Other">Other</SelectItem></SelectContent>
                  </Select>
                </div>
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center gap-2" disabled={loading}>
                {loading ? <Loader2 className="h-5 w-5 animate-spin"/> : 'Save & Continue'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default RegistrationForm;