import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Loader2 } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { getAspirantCategoryCounts, getPublicApplicants, submitAspirantApplication, getSurveyCategories } from '@/services/aspirantsApi';

const CategoryButton = ({ category, count, gradientFrom, gradientTo }) => (
  <div className={`bg-gradient-to-br ${gradientFrom} ${gradientTo} text-white rounded-lg p-2 text-center shadow-md`}>
    <div className="font-bold text-sm">{category}</div>
    <div className="text-lg font-extrabold">{count}</div>
  </div>
);

const ApplicantTable = ({ applicants, loading }) => (
  <div className="bg-white/10 backdrop-blur-sm rounded-xl overflow-hidden">
    <div className="max-h-40 overflow-y-auto no-scrollbar">
      <table className="w-full text-sm text-left text-white">
        <thead className="text-xs text-white/80 uppercase bg-white/20 sticky top-0">
          <tr>
            <th scope="col" className="px-4 py-2">Name</th>
            <th scope="col" className="px-4 py-2">District</th>
            <th scope="col" className="px-4 py-2">State</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr><td colSpan="3" className="text-center p-4"><Loader2 className="animate-spin inline-block" /></td></tr>
          ) : applicants.length === 0 ? (
            <tr><td colSpan="3" className="text-center p-4">Be the first to apply!</td></tr>
          ) : (
            applicants.map((applicant, index) => (
              <tr key={index} className="border-b border-white/10 last:border-b-0">
                <td className="px-4 py-2 font-medium">{applicant.full_name}</td>
                <td className="px-4 py-2">{applicant.district}</td>
                <td className="px-4 py-2">{applicant.state}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  </div>
);

const AspirantJobModal = ({ job, isOpen, onClose }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [categories, setCategories] = useState([]);
  const [applicants, setApplicants] = useState([]);
  const [categoryCounts, setCategoryCounts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [loading, setLoading] = useState(false);
  const [isApplying, setIsApplying] = useState(false);

  const fetchData = async () => {
    if (!job?.id) return;
    setLoading(true);
    try {
      const [countsData, applicantsData] = await Promise.all([
        getAspirantCategoryCounts(job.id),
        getPublicApplicants(job.id),
      ]);
      setCategoryCounts(countsData || []);
      setApplicants(applicantsData || []);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error fetching data', description: error.message });
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    if (isOpen) {
      fetchData();
    }
  }, [isOpen, job?.id]);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const cats = await getSurveyCategories();
        setCategories(cats || []);
      } catch (error) {
         toast({ variant: 'destructive', title: 'Error loading categories', description: error.message });
      }
    };
    loadCategories();
  }, []);

  const handleApply = async () => {
    if (!selectedCategory) {
      toast({ variant: 'destructive', title: 'Please select a category' });
      return;
    }
    if (!user) {
      toast({ variant: 'destructive', title: 'You must be logged in to apply.' });
      return;
    }
    setIsApplying(true);
    try {
      await submitAspirantApplication({ userId: user.id, jobId: job.id, categoryId: selectedCategory });
      toast({ title: 'Success', description: 'You have successfully applied!' });
      await fetchData(); // Refresh data
    } catch (error) {
      toast({ variant: 'destructive', title: 'Application Failed', description: error.message });
    } finally {
      setIsApplying(false);
    }
  };


  const modalVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 0.9 },
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm p-4"
          initial="hidden"
          animate="visible"
          exit="exit"
          onClick={onClose}
        >
          <motion.div
            variants={modalVariants}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="relative w-full h-auto max-h-[90vh] sm:max-w-md bg-gradient-to-br from-indigo-800 via-purple-800 to-fuchsia-900 text-white p-6 rounded-3xl shadow-2xl flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white transition-colors z-10">
              <X size={24} />
            </button>

            <div className="flex-shrink-0">
              <h2 className="text-2xl font-bold mb-1">{job?.title}</h2>
              <h3 className="text-md text-white/80 mb-6">{job?.subtitle}</h3>
            </div>
            
            <div className="flex-grow overflow-y-auto no-scrollbar pr-2">
              <div className="grid grid-cols-3 gap-2 mb-6">
                {categoryCounts.map((cat) => (
                  <CategoryButton key={cat.category_id} category={cat.name} count={cat.count} gradientFrom={cat.gradient_from} gradientTo={cat.gradient_to} />
                ))}
              </div>

              <h4 className="font-semibold mb-2">Applicant List</h4>
              <div className="mb-4">
                <ApplicantTable applicants={applicants} loading={loading} />
              </div>
            </div>

            <div className="flex-shrink-0 mt-auto pt-4 space-y-4">
               <Select onValueChange={setSelectedCategory} value={selectedCategory?.toString()}>
                <SelectTrigger className="w-full bg-white/20 border-white/30 text-white rounded-xl focus:ring-cyan-400">
                  <SelectValue placeholder="Select your category" />
                </SelectTrigger>
                <SelectContent className="bg-purple-800 text-white border-purple-700">
                  {categories.map((cat) => (
                     <SelectItem key={cat.id} value={cat.id.toString()} className="focus:bg-purple-700">{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
             
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleApply}
                disabled={isApplying}
                className="w-full bg-gradient-to-r from-cyan-400 to-teal-400 text-white font-bold py-3 rounded-xl shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isApplying ? <Loader2 className="animate-spin inline-block" /> : 'Apply'}
              </motion.button>
            </div>

          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AspirantJobModal;