
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabase'; // Using correct supabase import
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowRight } from 'lucide-react';
const LatestArticles = () => {
  const {
    toast
  } = useToast();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const fetchArticles = async () => {
      setLoading(true);
      const {
        data,
        error
      } = await supabase.from('stories').select('title, slug, created_at, content').eq('approved', true).order('created_at', {
        ascending: false
      }).range(0, 9); 
      if (error) {
        toast({
          title: "Error fetching articles",
          description: error.message,
          variant: "destructive"
        });
      } else {
        setArticles(data);
      }
      setLoading(false);
    };
    fetchArticles();
  }, [toast]);
  const cardVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: i => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.05,
        duration: 0.3
      }
    })
  };
  return <section>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Govt-Job News/Articles/Stories</h2>
             {loading ? <div className="flex justify-center py-10">
                    <Loader2 className="w-8 h-8 animate-spin text-wavy-navy" />
                </div> : <div className="grid md:grid-cols-3 gap-6">
                    {articles.map((article, index) => <motion.div key={article.slug} custom={index} initial="hidden" animate="visible" variants={cardVariants}>
                            <Card className="h-full flex flex-col overflow-hidden hover:shadow-xl transition-shadow">
                                <CardHeader>
                                    <CardTitle className="text-lg leading-tight text-gray-800">{article.title}</CardTitle>
                                </CardHeader>
                                <CardContent className="flex-grow">
                                    <p className="text-sm text-gray-500 line-clamp-3">
                                        {article.content.substring(0, 100).replace(/<[^>]+>/g, '')}...
                                    </p>
                                </CardContent>
                                <div className="p-4 pt-0 mt-auto">
                                    <Button asChild variant="link" className="p-0 text-wavy-navy">
                                        <Link to={`/stories/${article.slug}`}>Read More <ArrowRight className="w-4 h-4 ml-1" /></Link>
                                    </Button>
                                </div>
                            </Card>
                        </motion.div>)}
                </div>}
        </section>;
};
export default LatestArticles;
