import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const KeepAliveContext = createContext();

export const useKeepAlive = () => useContext(KeepAliveContext);

export const KeepAliveProvider = ({ children }) => {
  const [cache, setCache] = useState({});
  const location = useLocation();
  const currentPath = location.pathname + location.search;

  const addCache = (key, component) => {
    if (!cache[key]) {
      setCache(prev => ({ ...prev, [key]: { component, timestamp: Date.now() } }));
    }
  };

  const removeCache = (key) => {
    setCache(prev => {
      const newCache = { ...prev };
      delete newCache[key];
      return newCache;
    });
  };

  return (
    <KeepAliveContext.Provider value={{ cache, addCache, removeCache, currentPath }}>
      {children}
      {Object.entries(cache).map(([key, { component }]) => (
        <div key={key} style={{ display: key === currentPath ? 'block' : 'none' }} className="h-full w-full">
          {component}
        </div>
      ))}
    </KeepAliveContext.Provider>
  );
};

export const withKeepAlive = (Component, { cacheKey } = {}) => {
  return (props) => {
    const { addCache, cache } = useKeepAlive();
    const location = useLocation();
    
    let key;
    if (cacheKey) {
      if (typeof cacheKey === 'function') {
        key = cacheKey(props);
      } else {
        key = cacheKey;
      }
    } else {
      key = location.pathname + location.search;
    }

    useEffect(() => {
      if (!cache[key]) {
        addCache(key, <Component {...props} />);
      }
    }, [key, addCache, cache, props]);

    return null;
  };
};