import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Facebook, Instagram, Send, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const FooterLink = ({ to, children }) => (
  <Link
    to={to}
    className="text-gray-600 hover:text-primary transition-colors duration-200 text-sm font-medium"
  >
    {children}
  </Link>
);

const SocialLink = ({ href, icon: Icon, colorClass, children }) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    className={`flex items-center gap-2 text-sm font-medium ${colorClass} transition-colors duration-200`}
  >
    <Icon className="h-5 w-5" />
    {children}
  </a>
);

const Footer = () => {
  const { toast } = useToast();
  const [pages, setPages] = useState([]);

  useEffect(() => {
    const fetchFooterData = async () => {
      const { data: pagesData } = await supabase
        .from('pages')
        .select('title, slug')
        .order('title');

      if (pagesData) setPages(pagesData);
    };

    fetchFooterData();
  }, []);

  const handleNewsletterSubmit = (e) => {
    e.preventDefault();
    toast({
      title: 'Subscribed!',
      description: 'Thanks for subscribing to our newsletter.',
    });
    e.target.reset();
  };

  const getPageUrl = (slug) => `/page/${slug}`;

  const companyLinks = pages.filter((p) =>
    ['about us', 'contact us'].includes(p.title.toLowerCase())
  );

  const legalLinksData = [
    { title: 'Privacy Policy', slug: 'privacy-policy' },
    { title: 'Disclaimer', slug: 'disclaimer' },
    { title: 'Terms and Conditions', slug: 'terms-and-conditions' },
  ];

  const socialLinks = [
    {
      href: 'https://instagram.com/aspirantsindiaofficial',
      icon: Instagram,
      name: 'Instagram',
      colorClass: 'text-pink-500 hover:text-pink-600',
    },
    {
      href: 'https://facebook.com/aspirantsindiaofficial',
      icon: Facebook,
      name: 'Facebook',
      colorClass: 'text-blue-600 hover:text-blue-700',
    },
    {
      href: 'https://youtube.com/@aspirantsindia',
      icon: Youtube,
      name: 'YouTube',
      colorClass: 'text-red-600 hover:text-red-700',
    },
    {
      href: 'https://t.me/aspirantsindia',
      icon: Send,
      name: 'Telegram',
      colorClass: 'text-sky-500 hover:text-sky-600',
    },
  ];

  return (
    <footer className="bg-gray-50 border-t mt-12">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">

          {/* Branding */}
          <div className="col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-3">
              <div>
                <h2 className="text-xl font-bold text-primary">Aspirants India</h2>
                <p className="text-xs text-gray-500 mt-1">
                  Your Gateway to Opportunity
                </p>
              </div>
            </Link>
          </div>

          {/* Company Links */}
          <div>
            <p className="font-semibold text-gray-800 uppercase tracking-wider text-sm mb-4">
              Company
            </p>
            <ul className="space-y-3">
              {companyLinks.map((p) => (
                <li key={p.slug}>
                  <FooterLink to={getPageUrl(p.slug)}>{p.title}</FooterLink>
                </li>
              ))}
              <li>
                <FooterLink to="/stories">Success Stories</FooterLink>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <p className="font-semibold text-gray-800 uppercase tracking-wider text-sm mb-4">
              Legal
            </p>
            <ul className="space-y-3">
              {legalLinksData.map((p) => (
                <li key={p.slug}>
                  <FooterLink to={getPageUrl(p.slug)}>{p.title}</FooterLink>
                </li>
              ))}
              <li>
                <FooterLink to="/sitemap.xml">Sitemap</FooterLink>
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <p className="font-semibold text-gray-800 uppercase tracking-wider text-sm mb-4">
              Follow Us
            </p>
            <ul className="space-y-3">
              {socialLinks.map((link) => (
                <li key={link.name}>
                  <SocialLink
                    href={link.href}
                    icon={link.icon}
                    colorClass={link.colorClass}
                  >
                    {link.name}
                  </SocialLink>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <p className="font-semibold text-gray-800 uppercase tracking-wider text-sm mb-4">
              Newsletter
            </p>
            <p className="text-sm text-gray-500 mb-4">
              Get the latest job updates straight to your inbox.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex">
              <Input
                type="email"
                placeholder="Your email"
                required
                className="rounded-r-none focus:ring-primary"
              />
              <Button type="submit" className="rounded-l-none">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>

        {/* Strong Copyright */}
        <div className="mt-12 pt-8 border-t text-center text-gray-500 text-sm">
          <p>
            Copyright© {new Date().getFullYear()} Aspirants India — Government Job
            Notifications, Online Practice Sets, and PDF Study Material Platform.
            All Rights Reserved. Unauthorized copying, scraping, or redistribution
            of content is strictly prohibited.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;