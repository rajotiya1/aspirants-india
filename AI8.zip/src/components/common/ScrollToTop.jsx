import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * 🔹 ScrollToTop Component
 * हर बार जब route बदलता है, window page के top पर scroll हो जाती है।
 * यह smooth behavior को हटाकर "instant" रखता है ताकि WebViewGold में भी flicker या lag न हो।
 * IMPORTANT: This now scrolls the `document.documentElement` (the `<html>` element),
 * which is correct for body-level scrolling.
 */
export default function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    // हर route change पर scroll reset
    document.documentElement.scrollTo({ top: 0, behavior: "instant" });
  }, [pathname]);

  return null; // कोई UI render नहीं करता
}