import React, { useRef } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Keyboard, Mousewheel } from 'swiper/modules';
import 'swiper/css';

const SwipeDeck = ({ items, renderItem, activeIndex, onSlideChange, onSwiper }) => {
  const swiperRef = useRef(null);

  return (
    <Swiper
      modules={[Keyboard, Mousewheel]}
      onSwiper={(swiper) => {
        swiperRef.current = swiper;
        if (onSwiper) onSwiper(swiper);
      }}
      onSlideChange={onSlideChange}
      initialSlide={activeIndex}
      className="h-full w-full"
      slidesPerView={1}
      keyboard={{ enabled: true }}
      mousewheel={{ forceToAxis: true }}
      watchSlidesProgress
      observer
      observeParents
    >
      {items.map((item, index) => (
        <SwiperSlide key={item.id || index} className="h-full bg-background">
          <div className="h-full w-full overflow-y-auto no-scrollbar pb-[var(--bottom-ad-h,92px)]">
            {renderItem(item, index)}
          </div>
        </SwiperSlide>
      ))}
    </Swiper>
  );
};

export default SwipeDeck;