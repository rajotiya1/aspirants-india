
import React from 'react';
import ExamCard from './ExamCard';
import { motion } from 'framer-motion';
import { Layers } from 'lucide-react';

const CategorySection = ({ categoryName, examsData }) => {
  return (
    <section className="mb-8 last:mb-20">
      <div className="flex items-center gap-3 mb-4 pl-1">
        <div className="h-8 w-1 bg-blue-600 rounded-full" />
        <h2 className="text-xl sm:text-2xl font-bold text-blue-900 flex items-center gap-2">
          {categoryName}
        </h2>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {Object.entries(examsData).map(([examName, resources], index) => (
          <motion.div
            key={examName}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <ExamCard examName={examName} resources={resources} />
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default CategorySection;
