
import React, { useState } from 'react';
import { ChevronDown, ChevronUp, FileText, Download, File, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

const ExamCard = ({ examName, resources }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleOpen = () => setIsOpen(!isOpen);

  const getFileIcon = (type) => {
    const t = type?.toLowerCase() || '';
    if (t.includes('pdf')) return <FileText className="w-4 h-4 text-red-500" />;
    if (t.includes('link')) return <ExternalLink className="w-4 h-4 text-blue-500" />;
    return <File className="w-4 h-4 text-slate-500" />;
  };

  return (
    <Card className="w-full border-slate-200 shadow-sm hover:shadow-md transition-shadow duration-200 overflow-hidden bg-white">
      <div 
        onClick={toggleOpen}
        className="flex items-center justify-between p-4 cursor-pointer bg-white hover:bg-slate-50 transition-colors select-none"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-50 rounded-lg">
            <FileText className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex flex-col">
            <h3 className="font-semibold text-slate-800 text-sm sm:text-base">{examName}</h3>
            <p className="text-xs text-slate-500">{resources?.length || 0} resources available</p>
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
          {isOpen ? <ChevronUp className="h-4 w-4 text-slate-500" /> : <ChevronDown className="h-4 w-4 text-slate-500" />}
        </Button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="border-t border-slate-100 bg-slate-50/50">
              {resources && resources.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {/* Header for larger screens */}
                  <div className="hidden sm:grid grid-cols-12 gap-4 px-4 py-2 text-xs font-medium text-slate-500 bg-slate-50">
                    <div className="col-span-7">Resource Title</div>
                    <div className="col-span-2 text-center">Type</div>
                    <div className="col-span-3 text-right">Action</div>
                  </div>

                  {resources.map((res, idx) => (
                    <div key={res.id || idx} className="px-4 py-3 sm:py-2 hover:bg-white transition-colors">
                      <div className="flex flex-col sm:grid sm:grid-cols-12 sm:gap-4 sm:items-center">
                        {/* Title & Mobile Layout */}
                        <div className="col-span-7 mb-2 sm:mb-0">
                          <div className="flex items-start gap-2">
                            <span className="mt-0.5 shrink-0">{getFileIcon(res.resource_type)}</span>
                            <div>
                              <p className="text-sm font-medium text-slate-700 line-clamp-2">{res.resource_title}</p>
                              {res.year && <p className="text-xs text-slate-400 mt-0.5 sm:hidden">Year: {res.year}</p>}
                            </div>
                          </div>
                        </div>

                        {/* Type Badge */}
                        <div className="col-span-2 flex items-center justify-start sm:justify-center mb-3 sm:mb-0">
                          <Badge variant="secondary" className="text-[10px] px-2 h-5 font-normal bg-slate-100 text-slate-600 border-slate-200">
                            {res.resource_type || 'PDF'}
                          </Badge>
                        </div>

                        {/* Download/Action Button */}
                        <div className="col-span-3 flex justify-end">
                          <Button 
                            size="sm" 
                            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white h-8 text-xs gap-2 shadow-sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (res.url) window.open(res.url, '_blank');
                            }}
                          >
                            <Download className="w-3 h-3" />
                            <span className="sm:inline">Download</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-500 flex flex-col items-center justify-center gap-2">
                   <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
                     <File className="w-5 h-5 text-slate-300" />
                   </div>
                   <p className="text-sm">No resources uploaded yet.</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
};

export default ExamCard;
