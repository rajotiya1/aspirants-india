import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useDebounce } from '@/hooks/useDebounce';

const PillTabs = ({ tabs, activeIndex, onTabClick }) => (
  <div role="tablist" className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm p-2 overflow-x-auto no-scrollbar">
    <div className="flex space-x-2 w-max">
      {tabs.map((tab, index) => (
        <button
          key={tab.path}
          role="tab"
          aria-selected={activeIndex === index}
          onClick={() => onTabClick(index)}
          className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors duration-200 whitespace-nowrap ${
            activeIndex === index
              ? 'bg-primary text-primary-foreground shadow'
              : 'bg-muted text-muted-foreground hover:bg-accent'
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  </div>
);

const SwipePager = ({ tabs, children, basepath }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const swiperRef = useRef(null);
  
  const getActiveIndex = () => {
    const currentPath = location.pathname;
    const activeTab = tabs.findIndex(tab => {
        const fullPath = `${basepath}/${tab.path}`.replace(/\/+/g, '/');
        return currentPath.startsWith(fullPath);
    });
    return activeTab === -1 ? 0 : activeTab;
  };

  const [activeIndex, setActiveIndex] = useState(getActiveIndex);
  const [direction, setDirection] = useState(0);
  const debouncedNavigate = useDebounce(navigate, 150);

  useEffect(() => {
    const newIndex = getActiveIndex();
    if (newIndex !== activeIndex) {
      setDirection(newIndex > activeIndex ? 1 : -1);
      setActiveIndex(newIndex);
    }
  }, [location.pathname, tabs]);

  const handleDragEnd = (event, info) => {
    const offset = info.offset.x;
    const velocity = info.velocity.x;

    if (offset > 100 || velocity > 500) {
      if (activeIndex > 0) {
        const newPath = `${basepath}/${tabs[activeIndex - 1].path}`.replace(/\/+/g, '/');
        debouncedNavigate(newPath);
      }
    } else if (offset < -100 || velocity < -500) {
      if (activeIndex < tabs.length - 1) {
        const newPath = `${basepath}/${tabs[activeIndex + 1].path}`.replace(/\/+/g, '/');
        debouncedNavigate(newPath);
      }
    }
  };

  const handleTabClick = (index) => {
    if (index !== activeIndex) {
      const newPath = `${basepath}/${tabs[index].path}`.replace(/\/+/g, '/');
      navigate(newPath);
    }
  };

  const variants = {
    enter: (direction) => ({
      x: direction > 0 ? '100%' : '-100%',
      opacity: 0,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? '100%' : '-100%',
      opacity: 0,
    }),
  };

  return (
    <div className="flex flex-col h-full" ref={swiperRef}>
      <PillTabs tabs={tabs} activeIndex={activeIndex} onTabClick={handleTabClick} />
      <div className="flex-1 relative overflow-hidden">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={location.pathname}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: 'spring', stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.2}
            onDragEnd={handleDragEnd}
            className="absolute w-full h-full overflow-y-auto"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SwipePager;