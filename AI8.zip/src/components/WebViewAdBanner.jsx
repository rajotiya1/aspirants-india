import React, { useEffect } from 'react';
import { showWebViewGoldBanner, hideWebViewGoldBanner, isWebViewGold } from '@/lib/admob';

/**
 * Safe AdMob Banner for WebViewGold.
 * Shows ads ONLY when the current domain is "aspirantsindia.com".
 * Hides ads for all external websites (SSC, UPSC, banking, gov sites, apply links etc.)
 * Fully AdMob + Play Store compliant.
 */
const WebViewAdBanner = () => {
  const isOurDomain =
    typeof window !== "undefined" &&
    window.location.hostname.includes("aspirantsindia.com");

  useEffect(() => {
    if (isWebViewGold() && isOurDomain) {
      showWebViewGoldBanner();

      return () => {
        hideWebViewGoldBanner();
      };
    }
  }, [isOurDomain]);

  return null;
};

export default WebViewAdBanner;
