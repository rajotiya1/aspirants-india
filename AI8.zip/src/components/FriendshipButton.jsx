import React from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, UserPlus, UserCheck, UserX, Clock } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

const FriendshipButton = ({ profileId, onStatusChange }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [friendship, setFriendship] = React.useState(null);
  const [loading, setLoading] = React.useState(true);

  const fetchStatus = React.useCallback(async () => {
    if (!user || user.id === profileId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    
    const { data, error } = await supabase
      .from('friendships')
      .select('*')
      .or(`and(requester_id.eq.${user.id},addressee_id.eq.${profileId}),and(requester_id.eq.${profileId},addressee_id.eq.${user.id})`)
      .maybeSingle();
    
    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching friendship status:', error);
    } else {
      setFriendship(data);
    }
    setLoading(false);
  }, [user, profileId]);

  React.useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);
  
  const handleAction = async (action) => {
    if (!user) return;
    
    let error;
    setLoading(true);
    
    try {
      if (action === 'add') {
        ({ error } = await supabase.from('friendships').insert({ 
          requester_id: user.id, 
          addressee_id: profileId, 
          status: 'pending' 
        }));
        if (!error) {
          toast({ title: "Friend request sent!", description: "Your friend request has been sent successfully." });
        }
      } else if (action === 'accept') {
        ({ error } = await supabase.from('friendships').update({ 
          status: 'accepted', 
          updated_at: new Date().toISOString() 
        }).eq('id', friendship.id));
        if (!error) {
          toast({ title: "Friend request accepted!", description: "You are now friends." });
        }
      } else if (action === 'cancel' || action === 'unfriend' || action === 'decline') {
        ({ error } = await supabase.from('friendships').delete().eq('id', friendship.id));
        if (!error) {
          const message = action === 'unfriend' ? 'Friend removed.' : 
                         action === 'decline' ? 'Friend request declined.' : 
                         'Friend request cancelled.';
          toast({ title: message });
        }
      }
      
      if (error) {
        console.error('Friendship action error:', error);
        toast({ title: "Error", description: error.message, variant: "destructive" });
      } else {
        await fetchStatus();
        if(onStatusChange) onStatusChange();
      }
    } catch (err) {
      console.error('Unexpected error:', err);
      toast({ title: "Error", description: "An unexpected error occurred", variant: "destructive" });
    }
    
    setLoading(false);
  };

  if (loading) return <Button disabled size="sm"><Loader2 className="w-4 h-4 animate-spin" /></Button>;
  if (!user || user.id === profileId) return null;

  if (!friendship) {
    return <Button size="sm" onClick={() => handleAction('add')}><UserPlus className="w-4 h-4 mr-2" />Add Friend</Button>;
  }

  if (friendship.status === 'pending') {
    if (friendship.requester_id === user.id) {
      return <Button size="sm" variant="outline" onClick={() => handleAction('cancel')}><Clock className="w-4 h-4 mr-2" />Request Sent</Button>;
    } else {
      return (
        <div className="flex gap-2">
          <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => handleAction('accept')}><UserCheck className="w-4 h-4 mr-2" />Accept</Button>
          <Button size="sm" variant="destructive" onClick={() => handleAction('decline')}><UserX className="w-4 h-4 mr-2" />Decline</Button>
        </div>
      );
    }
  }

  if (friendship.status === 'accepted') {
    return (
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button size="sm" variant="secondary"><UserCheck className="w-4 h-4 mr-2 text-green-400" />Friends</Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action will remove this user from your friends list. You will need to send a new friend request to connect again.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => handleAction('unfriend')} className="bg-destructive hover:bg-destructive/90">
              Unfriend
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  return <Button size="sm" onClick={() => handleAction('add')}><UserPlus className="w-4 h-4 mr-2" />Add Friend</Button>;
};

export default FriendshipButton;