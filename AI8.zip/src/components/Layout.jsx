import React, { useState, useEffect, Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import Footer from './Footer';
import SideDrawer from './SideDrawer';
import { Loader2 } from 'lucide-react';

const LoadingFallback = () => (
  <div className="w-full h-full flex items-center justify-center bg-background p-8">
    <Loader2 className="animate-spin text-primary h-10 w-10" />
  </div>
);

const Layout = () => {
  const [isWebView, setIsWebView] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const webViewCheck = /wv|android.*version\/|iphone.*safari/i.test(navigator.userAgent);
    setIsWebView(webViewCheck);
    setIsMounted(true);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {isMounted && isWebView && <SideDrawer />}
      <main className="flex-grow container mx-auto px-4 py-6">
        <Suspense fallback={<LoadingFallback />}>
          <Outlet />
        </Suspense>
      </main>
      {isMounted && !isWebView && <Footer />}
    </div>
  );
};

export default Layout;