import React, { useState, useEffect, Fragment } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { 
  LayoutDashboard, 
  Briefcase, 
  Users, 
  BookOpen, 
  Share2,
  FileText,
  Info,
  Phone,
  Shield,
  FileWarning,
  Instagram,
  Facebook,
  Youtube,
  Send,
  Menu,
  X
} from 'lucide-react';

const mainNavItems = [
  { to: '/app/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/app/jobs', icon: Briefcase, label: 'Govt Jobs' },
  { to: '/aspirants', icon: Users, label: 'Aspirants' },
  { to: '/tests', icon: BookOpen, label: 'Tests' },
  { to: '/partners', icon: Share2, label: 'Partners' },
];

const pageIconMap = {
  'about-us': Info,
  'contact-us': Phone,
  'privacy-policy': Shield,
  'disclaimer': FileWarning,
};

const socialLinks = [
    { href: 'https://instagram.com/aspirantsindiaofficial', icon: Instagram, name: 'Instagram' },
    { href: 'https://facebook.com/aspirantsindiaofficial', icon: Facebook, name: 'Facebook' },
    { href: 'https://youtube.com/@aspirantsindia', icon: Youtube, name: 'YouTube' },
    { href: 'https://t.me/aspirantsindia', icon: Send, name: 'Telegram' },
];


const NavItem = ({ to, icon: Icon, label, onClick }) => (
  <Link
    to={to}
    onClick={onClick}
    className="flex items-center p-3 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group"
  >
    <Icon className="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" />
    <span className="ml-3">{label}</span>
  </Link>
);

const SocialItem = ({ href, icon: Icon, name }) => (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center p-3 text-base font-normal text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700 group"
    >
      <Icon className="w-6 h-6 text-gray-500 transition duration-75 dark:text-gray-400 group-hover:text-gray-900 dark:group-hover:text-white" />
      <span className="ml-3">{name}</span>
    </a>
);

const SideDrawer = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [pages, setPages] = useState([]);
  const location = useLocation();

  useEffect(() => {
    const fetchPages = async () => {
      const { data } = await supabase.from('pages').select('slug, title').order('title');
      if (data) setPages(data);
    };
    fetchPages();
  }, []);
  
  useEffect(() => {
    if (isOpen) {
      setIsOpen(false);
    }
  }, [location]);

  const toggleDrawer = () => setIsOpen(!isOpen);

  return (
    <>
      <button onClick={toggleDrawer} className="fixed top-4 left-4 z-50 p-2 bg-background/80 backdrop-blur-sm rounded-full shadow-lg text-foreground">
        <Menu className="h-6 w-6" />
      </button>

      <AnimatePresence>
        {isOpen && (
          <Fragment>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-black/60 z-40"
              onClick={toggleDrawer}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 left-0 z-50 w-72 h-full transition-transform bg-white dark:bg-gray-800 shadow-2xl"
              aria-label="Sidebar"
            >
              <div className="h-full px-3 py-4 overflow-y-auto">
                <div className="flex items-center justify-between mb-6 px-2">
                    <Link to="/" className="flex items-center gap-2" onClick={toggleDrawer}>
                        <h2 className="text-xl font-bold text-gray-900 dark:text-white">Aspirants India</h2>
                    </Link>
                  <button onClick={toggleDrawer} className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                    <X className="w-6 h-6 text-gray-500" />
                  </button>
                </div>
                
                <ul className="space-y-2 font-medium">
                  {mainNavItems.map(item => <li key={item.label}><NavItem {...item} onClick={toggleDrawer} /></li>)}
                </ul>
                
                <div className="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700">
                  <span className="px-3 text-xs font-semibold text-gray-500 uppercase dark:text-gray-400">Information</span>
                  {pages.map(page => (
                    <li key={page.slug}>
                      <NavItem 
                        to={`/page/${page.slug}`} 
                        icon={pageIconMap[page.slug] || FileText} 
                        label={page.title}
                        onClick={toggleDrawer}
                      />
                    </li>
                  ))}
                </div>

                <div className="pt-4 mt-4 space-y-2 font-medium border-t border-gray-200 dark:border-gray-700">
                   <span className="px-3 text-xs font-semibold text-gray-500 uppercase dark:text-gray-400">Connect with us</span>
                   {socialLinks.map(link => (
                    <li key={link.name}><SocialItem {...link} /></li>
                  ))}
                </div>
              </div>
            </motion.div>
          </Fragment>
        )}
      </AnimatePresence>
    </>
  );
};

export default SideDrawer;