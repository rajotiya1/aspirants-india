import React, { useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

const ChipRow = ({ items, activeIndex, onChipClick }) => {
  const tabsContainerRef = useRef(null);

  useEffect(() => {
    if (tabsContainerRef.current) {
      const activeTab = tabsContainerRef.current.children[activeIndex];
      if (activeTab) {
        activeTab.scrollIntoView({
          behavior: 'smooth',
          inline: 'center',
          block: 'nearest',
        });
      }
    }
  }, [activeIndex]);

  return (
    <div ref={tabsContainerRef} className="flex items-center overflow-x-auto no-scrollbar px-2 py-2 border-b">
      {items.map((item, index) => (
        <button
          key={item.id || index}
          onClick={() => onChipClick(index)}
          className={cn(
            'flex-shrink-0 px-4 py-2 text-sm font-medium rounded-full transition-colors duration-200 ease-in-out focus:outline-none mx-1',
            activeIndex === index
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted text-muted-foreground hover:bg-primary/10'
          )}
        >
          {item.job_surveys.title}
        </button>
      ))}
    </div>
  );
};

export default ChipRow;