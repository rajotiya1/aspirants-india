import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { formatDate } from '@/lib/utils';
import { Users, Calendar, Award, FileText, ClipboardList, Trash2, Loader2 } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from '@/components/ui/button';

const CategoryBox = ({ category, count, gradient }) => (
  <div className={`flex-grow basis-1/5 p-2 rounded-lg text-white text-center shadow-inner-light ${gradient} min-w-[60px]`}>
    <p className="font-bold text-sm uppercase">{category}</p>
    <p className="font-extrabold text-lg">{count}</p>
  </div>
);

const InfoRow = ({ label, value, icon: Icon }) => (
  <div className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-xl border border-gray-200 shadow-sm">
    <div className="flex items-center">
      <Icon className="w-4 h-4 mr-3 text-blue-600" />
      <p className="font-medium text-sm text-gray-700">{label}</p>
    </div>
    <p className="font-bold text-sm text-gray-900">{value || 'Coming Soon'}</p>
  </div>
);

const AppliedJobCard = ({ jobData, onDelete }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const { 
    id: applicationId,
    asp_jobs: job, 
    asp_categories: userCategory, 
    category_counts, 
    total_applications, 
    job_details 
  } = jobData || {};

  const orderedCategories = useMemo(() => {
    if (!Array.isArray(category_counts)) return [];
    const order = ['UR', 'OBC', 'SC', 'ST', 'EWS', 'PwD'];
    const categoryMap = new Map(category_counts.map(c => [c.category_name, c]));
    
    return order.map(name => {
        return categoryMap.get(name) || { 
            category_id: name,
            category_name: name,
            applications_count: 0,
        };
    });

  }, [category_counts]);
  
  if (!job || !userCategory) {
    return null;
  }

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(applicationId);
    setIsDeleting(false);
  };

  const infoFields = [
    { label: 'Last Date', value: job_details?.last_date ? formatDate(job_details.last_date) : 'Coming Soon', icon: Calendar },
    { label: 'Admit Card', value: job_details?.admit_card, icon: FileText },
    { label: 'Date of Exam', value: job_details?.exam_date, icon: Calendar },
    { label: 'Answer Key', value: job_details?.answer_key, icon: ClipboardList },
    { label: 'Result', value: job_details?.result, icon: Award },
    { label: 'Final Result', value: job_details?.final_result, icon: Award },
  ];
  
  const categoryGradients = {
    UR: 'bg-gradient-to-br from-sky-500 to-cyan-400',
    OBC: 'bg-gradient-to-br from-blue-500 to-sky-400',
    SC: 'bg-gradient-to-br from-indigo-500 to-purple-400',
    ST: 'bg-gradient-to-br from-purple-500 to-fuchsia-400',
    EWS: 'bg-gradient-to-br from-teal-500 to-emerald-400',
    PwD: 'bg-gradient-to-br from-slate-500 to-gray-400',
  };

  return (
    <motion.div
      layout
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: -20, opacity: 0, transition: { duration: 0.3 } }}
      transition={{ duration: 0.4, ease: 'easeInOut' }}
      className="bg-gray-50 p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-lg relative"
    >
      {onDelete && (
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="absolute top-2 right-2 text-red-500 hover:bg-red-100 hover:text-red-700">
              {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently remove your application for this job survey. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Delete'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      <div className="text-center mb-4 pr-8">
        <h2 className="text-xl font-bold text-blue-600 tracking-wide">{job.job_name}</h2>
        <p className="text-sm text-gray-500 font-medium">Your category: {userCategory.name}</p>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {orderedCategories.map(cat => (
          <CategoryBox 
            key={cat.category_id} 
            category={cat.category_name} 
            count={cat.applications_count} 
            gradient={categoryGradients[cat.category_name] || 'bg-gray-500'}
          />
        ))}
      </div>

      <div className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-600 rounded-lg p-3 text-center mb-6 shadow-lg">
        <p className="font-bold text-white text-lg flex items-center justify-center">
            <Users className="w-5 h-5 mr-2" />
            Total Applications: {total_applications || 0}
        </p>
      </div>

      <div className="space-y-2">
        {infoFields.map(field => (
          <InfoRow key={field.label} {...field} />
        ))}
      </div>
    </motion.div>
  );
};

export default AppliedJobCard;