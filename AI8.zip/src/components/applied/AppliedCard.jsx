import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { getJobSurveyDetails, getUpdatesForJob } from '@/services/aspirantsApi';
import { Loader2, Bell, Users } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const AppliedCard = ({ application }) => {
  const [details, setDetails] = useState(null);
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchData = useCallback(async () => {
    if (!application) return;
    setLoading(true);
    try {
      const [detailsData, updatesData] = await Promise.all([
        getJobSurveyDetails(application.job_survey_id),
        getUpdatesForJob(application.job_survey_id, application.category_id)
      ]);
      setDetails(detailsData);
      setUpdates(updatesData);
    } catch (error) {
      toast({ title: "Error fetching card details", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [application, toast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading) {
    return (
      <Card className="m-4 flex justify-center items-center h-96">
        <Loader2 className="w-8 h-8 animate-spin" />
      </Card>
    );
  }

  if (!details) return null;

  const categoryCounts = details.job_category_counts.map(c => ({
      name: c.job_survey_categories.name,
      count: c.applicant_count
  })).sort((a, b) => b.count - a.count);

  const jobWideUpdates = updates.filter(u => u.category_id === null);
  const categorySpecificUpdates = updates.filter(u => u.category_id !== null);

  return (
    <Card className="m-4">
      <CardHeader>
        <CardTitle>{details.title}</CardTitle>
        <CardDescription>Your Category: <span className="font-semibold text-primary">{application.job_survey_categories.name}</span></CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="font-semibold mb-2 flex items-center gap-2"><Users className="w-5 h-5" /> Live Category Counts</h3>
          <Table>
            <TableHeader><TableRow><TableHead>Category</TableHead><TableHead className="text-right">Count</TableHead></TableRow></TableHeader>
            <TableBody>
              {categoryCounts.map(cat => (
                <TableRow key={cat.name}><TableCell>{cat.name}</TableCell><TableCell className="text-right">{cat.count}</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold mb-2 flex items-center gap-2"><Bell className="w-5 h-5" /> Job-wide Updates</h3>
            <div className="space-y-2">
              {jobWideUpdates.length > 0 ? jobWideUpdates.map(up => (
                <div key={up.id} className="text-sm p-2 border-l-2 border-blue-500 bg-blue-50 dark:bg-blue-900/20">
                  <p>{up.content}</p>
                  <p className="text-xs text-muted-foreground">{format(new Date(up.created_at), 'dd MMM yyyy')}</p>
                </div>
              )) : <p className="text-sm text-muted-foreground">No job-wide updates yet.</p>}
            </div>
          </div>
          <div>
            <h3 className="font-semibold mb-2 flex items-center gap-2"><Bell className="w-5 h-5 text-green-500" /> Category-specific Updates</h3>
            <div className="space-y-2">
              {categorySpecificUpdates.length > 0 ? categorySpecificUpdates.map(up => (
                <div key={up.id} className="text-sm p-2 border-l-2 border-green-500 bg-green-50 dark:bg-green-900/20">
                  <p>{up.content}</p>
                  <p className="text-xs text-muted-foreground">{format(new Date(up.created_at), 'dd MMM yyyy')}</p>
                </div>
              )) : <p className="text-sm text-muted-foreground">No updates for your category yet.</p>}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AppliedCard;