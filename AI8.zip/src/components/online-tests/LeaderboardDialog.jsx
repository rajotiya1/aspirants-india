import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Loader2, Star, Trophy, UserCircle2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';


const LeaderboardDialog = ({ open, onOpenChange, category, date, currentUserId }) => {
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const fetchLeaderboard = useCallback(async () => {
    if (!category || !date) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('daily_leaderboard')
        .select('*, profiles(id, name, avatar_path, city, state)')
        .eq('category', category)
        .eq('date', date)
        .order('rank', { ascending: true });

      if (error) throw error;

      const dataWithUrls = data.map(entry => {
        if (entry.profiles && entry.profiles.avatar_path) {
          const { data: urlData } = supabase.storage.from('avatars').getPublicUrl(entry.profiles.avatar_path);
          return {
            ...entry,
            profiles: {
              ...entry.profiles,
              avatar_url: urlData.publicUrl,
            }
          };
        }
        return entry;
      });

      setLeaderboardData(dataWithUrls || []);
    } catch (error) {
      toast({ title: "Error fetching leaderboard", description: error.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [category, date, toast]);

  useEffect(() => {
    if (open) {
      fetchLeaderboard();
    }
  }, [open, fetchLeaderboard]);
  
  const getRankColor = (rank) => {
    if (rank === 1) return 'bg-yellow-100 border-yellow-400';
    if (rank === 2) return 'bg-gray-200 border-gray-400';
    if (rank === 3) return 'bg-orange-200 border-orange-400';
    return 'border-gray-200';
  }
  
  const currentUserEntry = leaderboardData.find(entry => entry.user_id === currentUserId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white max-w-md w-full">
        <DialogHeader>
          <DialogTitle className="text-blue-600 text-center text-2xl flex items-center justify-center gap-2"><Trophy/> Leaderboard</DialogTitle>
          <DialogDescription className="text-center text-gray-500">
            Your Score on - {format(new Date(date + 'T00:00:00'), 'dd MMM yyyy')}
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[60vh] overflow-y-auto space-y-2 pr-2">
          {loading ? (
            <div className="flex justify-center items-center h-48"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
          ) : leaderboardData.length > 0 ? (
            leaderboardData.map((entry, index) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={cn(
                    "flex items-center p-3 rounded-lg border transition-all",
                    getRankColor(entry.rank),
                    entry.user_id === currentUserId && "ring-2 ring-blue-600"
                )}
              >
                <div className="flex items-center gap-4 flex-grow">
                    <div className="font-bold text-lg w-6 text-center text-gray-700">{entry.rank}</div>
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={entry.profiles?.avatar_url} />
                      <AvatarFallback className="bg-gray-200 text-gray-600">{entry.profiles?.name?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <div>
                        <p className="font-semibold text-gray-800">{entry.profiles?.name || 'Anonymous'}</p>
                        <p className="text-xs text-gray-500">{entry.profiles?.city || 'Unknown Location'}</p>
                    </div>
                </div>
                <div className="text-right">
                    <p className="font-bold text-lg text-green-600">{entry.correct}</p>
                    <p className="text-xs text-gray-500">Correct</p>
                </div>
              </motion.div>
            ))
          ) : (
            <div className="text-center py-10 text-gray-500">No one has taken this test yet.</div>
          )}
        </div>
         {currentUserEntry && (
             <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg text-center">
                <p className="text-blue-700 text-lg font-bold">Your Rank: #{currentUserEntry.rank}</p>
             </div>
         )}
      </DialogContent>
    </Dialog>
  );
};

export default LeaderboardDialog;