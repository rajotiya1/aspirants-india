import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import LeaderboardDialog from './LeaderboardDialog';
import { formatDate } from '@/lib/utils';

// ⭐ import category name mapping
import { getCategoryName } from "@/data/categoryNames";

const TestCategoryList = ({ testCategories, onStartTest, getLeaderboard }) => {
  const categories = Object.values(testCategories);

  if (categories.length === 0) {
    return (
      <div className="text-center py-10 text-slate-400">
        <p>No tests available at the moment.</p>
        <p>Please check back later!</p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
    >
      {categories.map((category) => (
        <div
          key={category.name}
          className="bg-slate-800/50 border border-slate-700 rounded-lg overflow-hidden flex flex-col"
        >
          <div className="bg-slate-900 p-2 text-center">
            
            {/* ⭐ Apply mapping here */}
            <h3 className="font-bold text-white text-base sm:text-lg">
              {getCategoryName(category.name)}
            </h3>

            <p className="text-xs text-slate-400 truncate">{category.description}</p>
          </div>

          <div className="flex-grow">
            <table className="w-full text-sm text-left">
              <tbody>
                {category.tests.map((test) => (
                  <tr key={test.id} className="border-b border-slate-700">
                    <td className="px-2 py-2 sm:px-3">{formatDate(test.test_date)}</td>
                    <td className="px-2 py-2 sm:px-3 text-right">
                      <Button
                        size="sm"
                        onClick={() => onStartTest(test)}
                        className="text-xs h-8 bg-blue-600 hover:bg-blue-700"
                      >
                        Start Test
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div>
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="bg-slate-900/70">
                  <th colSpan="2" className="p-2 font-bold text-center text-white text-base">
                    Leader Board
                  </th>
                </tr>
              </thead>

              <tbody>
                {category.tests.map((test) => (
                  <tr
                    key={`leaderboard-${test.id}`}
                    className="border-b border-slate-700 last:border-b-0"
                  >
                    <td className="px-2 py-2 sm:px-3">{formatDate(test.test_date)}</td>
                    <td className="px-2 py-2 sm:px-3 text-right">
                      <LeaderboardDialog
                        test={test}
                        getLeaderboard={getLeaderboard}
                        trigger={
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-xs h-8 border-slate-600 hover:bg-slate-700"
                          >
                            Your Rank
                          </Button>
                        }
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </motion.div>
  );
};

export default TestCategoryList;
