import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Send } from "lucide-react";
import { cn } from "@/lib/utils";

// Universal field fetcher
const getFieldValue = (q, baseName) => {
  const html = q[`${baseName}_html`];
  const text = q[`${baseName}_text`];
  const img = q[`${baseName}_image_url`];

  const items = [];
  if (html) items.push({ type: "html", value: html });
  if (text && !html) items.push({ type: "text", value: text });
  if (img) items.push({ type: "image", value: img });
  return items;
};

// Universal renderer
const renderValues = (fields) => {
  if (!fields || fields.length === 0) return null;

  return fields.map((f, idx) => {
    if (f.type === "html")
      return (
        <div
          key={idx}
          dangerouslySetInnerHTML={{ __html: f.value }}
          className="prose max-w-none text-black leading-relaxed [&>p]:m-0 [&>p]:inline-block"
        />
      );

    if (f.type === "text")
      return (
        <p key={idx} className="text-black font-semibold text-base m-0">
          {f.value}
        </p>
      );

    if (f.type === "image")
      return (
        <img
          key={idx}
          src={f.value}
          alt="Visual"
          className={cn(
            "rounded-md border border-gray-200 bg-gray-50 max-h-64 object-contain block",
            idx > 0 ? "mt-2" : "mt-0"
          )}
          onError={(e) => (e.target.style.display = "none")}
        />
      );

    return null;
  });
};

const TestRunner = ({ testData, onSubmit, onBack, initialAnswers = {}, onAnswerUpdate }) => {
  const { questions, category, date } = testData || { questions: [] };
  const [answers, setAnswers] = useState(initialAnswers);

  // Sync state if initialAnswers change (unlikely but good practice for re-mounts)
  useEffect(() => {
    if (Object.keys(initialAnswers).length > 0 && Object.keys(answers).length === 0) {
       setAnswers(initialAnswers);
    }
  }, [initialAnswers]); // Intentionally limited deps

  const handleAnswerChange = (questionId, value) => {
    const newAnswers = { ...answers, [questionId]: value };
    setAnswers(newAnswers);
    if (onAnswerUpdate) {
      onAnswerUpdate(newAnswers);
    }
  };

  const handleSubmit = () => {
    onSubmit({ answers, questions });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">

      {/* Header */}
      <div className="flex items-center justify-between sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 rounded-lg border border-gray-200 shadow-sm">
        <Button variant="outline" onClick={onBack}>
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Button>

        <div className="text-right">
          <h1 className="text-lg md:text-2xl font-bold text-blue-600 truncate max-w-[200px] md:max-w-none">
            {category?.name || "Online Test"}
          </h1>
          <p className="text-xs md:text-sm text-gray-500 font-medium">
            {date
              ? new Date(date + "T00:00:00").toLocaleDateString("en-GB", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })
              : ""}
          </p>
        </div>
      </div>

      {/* Questions Section */}
      <div className="space-y-8 px-1">
        {questions && questions.length > 0 ? (
          questions.map((q, index) => {
            const newSchemaQuestion =
              q.question_text || q.question_html || q.question_image_url;

            const newSchemaOption =
              q.option_a_text || q.option_a_html || q.option_a_image_url;

            return (
              <motion.div
                key={q.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="bg-white border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
                  <CardHeader className="bg-gray-50/50 border-b border-gray-100 pb-3">
                    <CardTitle className="text-base md:text-lg text-blue-600 font-bold flex justify-between">
                      <span>Question {index + 1}</span>
                      <span className="text-xs font-normal text-gray-400 bg-white px-2 py-1 rounded border">ID: {q.id?.slice(0,6)}</span>
                    </CardTitle>
                  </CardHeader>

                  <CardContent className="pt-6">

                    {/* QUESTION */}
                    <div className="mb-6 flow-root [&>:last-child]:mb-0">
                      {newSchemaQuestion ? (
                        renderValues(getFieldValue(q, "question"))
                      ) : (
                        <>
                          <p className="text-black font-bold text-base md:text-lg leading-relaxed">
                            {q.question || q.question_hindi}
                          </p>

                          {q.question_en && (
                            <p className="text-gray-600 italic font-medium text-sm mt-2 border-l-2 border-blue-200 pl-3">
                              {q.question_en}
                            </p>
                          )}

                          {q.chart_image_url && (
                            <img
                              src={q.chart_image_url}
                              alt="Question Diagram"
                              className="mt-4 rounded-lg border border-gray-200 bg-gray-50 max-h-80 object-contain shadow-sm"
                              onError={(e) => (e.target.style.display = "none")}
                            />
                          )}
                        </>
                      )}
                    </div>

                    {/* 🔥 STATEMENTS BLOCK */}
                    {(q.statement_1 || q.statement_2 || q.statement_3 || q.statement_4 || q.statement_5) && (
                      <div className="space-y-2 mb-6 p-4 bg-blue-50/50 rounded-lg border border-blue-100">
                        <p className="text-xs font-bold text-blue-500 uppercase tracking-wider mb-1">Statements</p>
                        {q.statement_1 && <p className="text-sm font-semibold">{q.statement_1}</p>}
                        {q.statement_2 && <p className="text-sm font-semibold">{q.statement_2}</p>}
                        {q.statement_3 && <p className="text-sm font-semibold">{q.statement_3}</p>}
                        {q.statement_4 && <p className="text-sm font-semibold">{q.statement_4}</p>}
                        {q.statement_5 && <p className="text-sm font-semibold">{q.statement_5}</p>}
                      </div>
                    )}

                    {/* OPTIONS */}
                    <RadioGroup
                      onValueChange={(value) => handleAnswerChange(q.id, value)}
                      value={answers[q.id] || ""}
                      className="gap-2"
                    >
                      {["A", "B", "C", "D"].map((opt) => {
                         const isSelected = answers[q.id] === opt;
                         return (
                          <div
                            key={opt}
                            onClick={() => handleAnswerChange(q.id, opt)}
                            className={cn(
                                "relative flex items-start p-1 md:p-2 rounded-xl cursor-pointer border-2 transition-all duration-200",
                                isSelected
                                ? "bg-blue-50/80 border-blue-500 shadow-sm"
                                : "border-transparent bg-gray-50 hover:bg-gray-100 hover:border-gray-200"
                            )}
                          >
                            {/* HIDE RADIO BUTTON */}
                            <RadioGroupItem value={opt} id={`${q.id}-${opt}`} className="hidden" />

                            <Label
                              htmlFor={`${q.id}-${opt}`}
                              className="text-black w-full cursor-pointer flex items-start gap-3"
                            >
                              <div className={cn(
                                  "flex items-center justify-center w-8 h-8 rounded-full shrink-0 text-sm font-bold transition-colors",
                                  isSelected ? "bg-blue-500 text-white" : "bg-white text-gray-500 border border-gray-200"
                              )}>
                                {opt}
                              </div>

                              <div className="flex-1 pt-1 [&>:first-child]:mt-0 text-base">
                                {newSchemaOption
                                  ? renderValues(getFieldValue(q, `option_${opt.toLowerCase()}`))
                                  : <span className="font-medium text-gray-800">{q[`option_${opt.toLowerCase()}`]}</span>}
                              </div>
                            </Label>
                          </div>
                        );
                      })}
                    </RadioGroup>

                  </CardContent>
                </Card>
              </motion.div>
            );
          })
        ) : (
          <div className="text-center py-10">
             <p className="text-gray-500">No questions available for this test.</p>
          </div>
        )}
      </div>

      {/* Submit Button */}
      <div className="sticky bottom-4 flex justify-center pt-4 pb-2 z-10">
        <div className="bg-white/90 backdrop-blur p-2 rounded-full shadow-lg border border-gray-100">
            <Button
            size="lg"
            onClick={handleSubmit}
            className="bg-green-600 hover:bg-green-700 text-white font-bold px-8 rounded-full shadow-md transition-transform active:scale-95"
            >
            <Send className="mr-2 h-5 w-5" />
            Submit Test
            </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default TestRunner;