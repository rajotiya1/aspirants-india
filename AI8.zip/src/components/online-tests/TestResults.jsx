import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  CheckCircle2,
  XCircle,
  SkipForward,
  Star,
  HelpCircle,
  MessageSquare,
  BookOpen,
  AlertTriangle,
} from "lucide-react";
import LeaderboardDialog from "./LeaderboardDialog";
import { useAuth } from "@/contexts/SupabaseAuthContext";

// Universal field fetcher
const getFieldValue = (q, baseName) => {
  const html = q[`${baseName}_html`];
  const text = q[`${baseName}_text`];
  const img = q[`${baseName}_image_url`];

  const items = [];
  if (html) items.push({ type: "html", value: html });
  if (text && !html) items.push({ type: "text", value: text });
  if (img) items.push({ type: "image", value: img });
  return items;
};

// Universal renderer
const renderValues = (fields) => {
  if (!fields || fields.length === 0) return null;

  return fields.map((f, idx) => {
    if (f.type === "html")
      return (
        <div
          key={idx}
          dangerouslySetInnerHTML={{ __html: f.value }}
          className="prose max-w-none text-black leading-relaxed"
        />
      );

    if (f.type === "text")
      return (
        <p key={idx} className="text-black font-semibold text-base">
          {f.value}
        </p>
      );

    if (f.type === "image")
      return (
        <img
          key={idx}
          src={f.value}
          alt="Visual"
          className="mt-3 rounded-md border border-gray-200 bg-gray-50 max-h-72 object-contain"
          onError={(e) => (e.target.style.display = "none")}
        />
      );

    return null;
  });
};

// Stat card
const StatCard = ({ icon, label, value, color }) => {
  const Icon = icon;
  return (
    <div className="p-3 rounded-md flex flex-col items-center justify-center text-center bg-gray-50 border border-gray-200 shadow-sm">
      <Icon className={`w-6 h-6 mb-1 ${color}`} />
      <p className="text-lg font-bold text-black">{value}</p>
      <p className="text-xs font-semibold text-gray-700">{label}</p>
    </div>
  );
};

const TestResults = ({ resultData, onBack }) => {
  const { user } = useAuth();
  const { result, questions, answers } = resultData || {};
  const [showRankDialog, setShowRankDialog] = useState(false);

  // 🔥 Auto scroll to top when this page loads
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  useEffect(() => {
    if (result) {
      const timer = setTimeout(() => {
        setShowRankDialog(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [result]);

  if (!result || !questions || !answers) {
    return (
      <Card className="bg-white border-red-500">
        <CardHeader>
          <CardTitle className="flex items-center text-red-600">
            <AlertTriangle className="mr-2" />
            Error Displaying Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p>There was a problem loading your test results. Please try again.</p>
          <Button onClick={onBack} variant="outline" size="sm" className="mt-4">
            Go Back
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      
      {showRankDialog && (
        <LeaderboardDialog
          open={showRankDialog}
          onOpenChange={setShowRankDialog}
          category={result.category}
          date={result.date}
          currentUserId={user.id}
        />
      )}

      {/* TOP RESULT SUMMARY */}
      <Card className="bg-white border-gray-200">
        <CardHeader className="flex flex-row items-center justify-between">
          <Button
            size="sm"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md"
            onClick={() => {
              window.location.href = `https://aspirantsindia.com/app/profile/tests/${user?.id}`;
            }}
          >
            Result Book
          </Button>

          <Button
            onClick={onBack}
            size="sm"
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md"
          >
            Back to All Tests
          </Button>
        </CardHeader>

        <CardContent className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <StatCard icon={HelpCircle} label="Total Questions" value={result.total_questions} color="text-blue-600" />
          <StatCard icon={MessageSquare} label="Attempted" value={result.attempted} color="text-indigo-600" />
          <StatCard icon={CheckCircle2} label="Correct" value={result.correct} color="text-green-600" />
          <StatCard icon={XCircle} label="Wrong" value={result.wrong} color="text-red-600" />
          <StatCard icon={SkipForward} label="Skipped" value={result.skipped} color="text-yellow-600" />
          <StatCard icon={Star} label="Overall Rank" value={`#${result.rank || "N/A"}`} color="text-amber-600" />
        </CardContent>
      </Card>

      {/* QUESTIONS REVIEW */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-blue-600">Review Your Answers</h2>

        {questions.map((q, index) => {
          const userAnswer = answers[q.id];
          const correctOptionKey = q.correct_answer_text ? "correct_answer_text" : "correct_option";
          const isCorrect = userAnswer === q[correctOptionKey];
          const isSkipped = !userAnswer;

          const newSchemaQuestion = q.question_text || q.question_html || q.question_image_url;
          const newSchemaOption = q.option_a_text || q.option_a_html || q.option_a_image_url;
          const newSchemaCorrectAnswer =
            q.correct_answer_text || q.correct_answer_html || q.correct_answer_image_url;
          const newSchemaDescription =
            q.description_text || q.description_html || q.description_image_url;

          return (
            <motion.div key={q.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}>
              <Card className="bg-white border-gray-200 overflow-hidden">

                <CardHeader className="pb-2">
                  <p className="text-blue-600 font-bold">Question {index + 1}</p>
                </CardHeader>

                <CardContent className="space-y-3">

                  {/* QUESTION */}
                  <div>
                    {newSchemaQuestion ? (
                      renderValues(getFieldValue(q, "question"))
                    ) : (
                      <>
                        <p className="text-black font-bold text-base">{q.question_hindi || q.question}</p>
                        {q.question_english && (
                          <p className="italic text-gray-700 text-sm">({q.question_english})</p>
                        )}
                      </>
                    )}
                  </div>

                  {/* 🔥 STATEMENTS BLOCK */}
                  {(q.statement_1 || q.statement_2 || q.statement_3 || q.statement_4) && (
                    <div className="space-y-1 text-black font-semibold leading-snug">
                      {q.statement_1 && <p>{q.statement_1}</p>}
                      {q.statement_2 && <p>{q.statement_2}</p>}
                      {q.statement_3 && <p>{q.statement_3}</p>}
                      {q.statement_4 && <p>{q.statement_4}</p>}
                    </div>
                  )}

                  {/* OPTIONS */}
                  {["A", "B", "C", "D"].map((opt) => {
                    const optionKey = `option_${opt.toLowerCase()}`;
                    const raw = q[optionKey];

                    const alreadyHasLabel =
                      typeof raw === "string" && /^[A-D]\./.test(raw.trim());

                    const isUser = userAnswer === opt;

                    const isRight = newSchemaCorrectAnswer
                      ? q.correct_answer_text === opt
                      : q.correct_option === opt;

                    return (
                      <div
                        key={opt}
                        className={`flex items-start p-3 rounded-md border font-bold ${
                          isRight
                            ? "bg-green-100 border-green-500"
                            : isUser
                            ? "bg-red-100 border-red-500"
                            : "border-gray-300"
                        }`}
                      >
                        {!alreadyHasLabel && <span className="mr-2">{opt}.</span>}

                        <div className="flex-1">
                          {newSchemaOption
                            ? renderValues(getFieldValue(q, optionKey))
                            : raw}
                        </div>
                      </div>
                    );
                  })}

                  {/* SUMMARY */}
                  <div className="pt-3 mt-3 border-t border-gray-300">
                    <div className="flex justify-between text-sm flex-wrap">
                      <p className="text-gray-700 mr-4">
                        Your Answer:
                        <span
                          className={`font-bold ml-2 ${
                            isSkipped
                              ? "text-yellow-600"
                              : isCorrect
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          {isSkipped ? "Skipped" : userAnswer}
                        </span>
                      </p>

                      <p className="text-gray-700">
                        Correct Answer:
                        <span className="font-bold text-green-600 ml-2">
                          {newSchemaCorrectAnswer
                            ? renderValues(getFieldValue(q, "correct_answer"))
                            : q.correct_option}
                        </span>
                      </p>
                    </div>

                    {(q.explanation || newSchemaDescription) && (
                      <div className="mt-3 p-3 bg-gray-100 rounded-md">
                        <p className="flex items-center text-blue-600 font-semibold mb-2">
                          <BookOpen className="w-4 h-4 mr-2" /> Explanation
                        </p>
                        <div className="text-gray-800 leading-relaxed whitespace-pre-line">
                          {newSchemaDescription
                            ? renderValues(getFieldValue(q, "description"))
                            : q.explanation}
                        </div>
                      </div>
                    )}
                  </div>

                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
};

export default TestResults;
