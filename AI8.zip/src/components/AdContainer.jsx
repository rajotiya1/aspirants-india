
import React from 'react';
import { cn } from '@/lib/utils';

const AdContainer = ({ position }) => {
  const isTop = position === 'top';
  
  return (
    <div
      className={cn(
        'h-[var(--ad-height)] bg-slate-100 flex-shrink-0 flex items-center justify-center text-sm text-slate-400',
        isTop ? 'border-b border-slate-200' : 'border-t border-slate-200'
      )}
      style={{'--ad-height': '50px'}} // Define the custom property here for consistent ad height
    >
      <span className="uppercase font-semibold tracking-wider">{position} AD</span>
    </div>
  );
};

export default AdContainer;
