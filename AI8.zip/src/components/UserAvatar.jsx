import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { User } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/utils';

const UserAvatar = ({ user, className }) => {
  if (!user) {
    return (
      <Avatar className={cn('w-7 h-7 md:w-8 md:h-8', className)}>
        <AvatarFallback className="bg-muted">
          <User className="w-4 h-4 text-muted-foreground" />
        </AvatarFallback>
      </Avatar>
    );
  }

  const getAvatarUrl = () => {
    if (!user.avatar_path) return null;
    
    try {
      const cacheBuster = user.updated_at 
        ? new Date(user.updated_at).getTime() 
        : Date.now();
      
      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(user.avatar_path);
      
      if (data?.publicUrl) {
        return `${data.publicUrl}?v=${cacheBuster}`;
      }
    } catch (error) {
      console.error('Error getting avatar URL:', error);
    }
    
    return null;
  };

  const avatarUrl = getAvatarUrl();
  const fallbackText = user.name 
    ? user.name.charAt(0).toUpperCase() 
    : (user.email ? user.email.charAt(0).toUpperCase() : 'U');

  return (
    <Avatar className={cn('w-7 h-7 md:w-8 md:h-8 ring-2 ring-offset-2 ring-offset-background ring-primary/50', className)}>
      {avatarUrl && (
        <AvatarImage 
          src={avatarUrl} 
          alt={user.name || 'User Avatar'}
          onError={(e) => {
            console.log('Avatar failed to load, using fallback');
            e.target.style.display = 'none';
          }}
        />
      )}
      <AvatarFallback className="bg-primary/10 text-primary font-semibold">
        {fallbackText}
      </AvatarFallback>
    </Avatar>
  );
};

export default UserAvatar;