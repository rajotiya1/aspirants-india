import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useBadges } from '@/contexts/BadgeContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Download, ChevronDown, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDebounce } from '@/hooks/useDebounce';

const JobRow = ({ job, isNew, onSelect, isSelected }) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="border-b"
    >
      <button
        onClick={() => onSelect(job.id)}
        className="w-full text-left p-4 hover:bg-secondary/50 transition-colors duration-200 flex items-center justify-between"
      >
        <div className="flex items-center">
          <span className="font-bold text-foreground mr-3">{job.title}</span>
          {isNew && <Badge variant="destructive">NEW</Badge>}
        </div>
        <ChevronDown className={`w-5 h-5 text-muted-foreground transition-transform duration-300 ${isSelected ? 'rotate-180' : ''}`} />
      </button>
      <AnimatePresence>
        {isSelected && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-secondary/30">
              <p className="text-muted-foreground whitespace-pre-wrap mb-4">{job.details}</p>
              {job.jpeg_url && (
                <Button asChild>
                  <a href={job.jpeg_url} download target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-4 w-4" />
                    Download JPEG
                  </a>
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const SpecialJobListing = ({ tableName, pageTitle, badgeKey }) => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJobId, setSelectedJobId] = useState(null);
  const { markAsSeen, badgeState } = useBadges();
  const debouncedSearchTerm = useDebounce(searchTerm, 300);

  useEffect(() => {
    markAsSeen(badgeKey);
  }, [badgeKey, markAsSeen]);

  useEffect(() => {
    const fetchJobs = async () => {
      setLoading(true);
      let query = supabase.from(tableName).select('*').order('created_at', { ascending: false });

      if (debouncedSearchTerm) {
        query = query.ilike('title', `%${debouncedSearchTerm}%`);
      }

      const { data, error } = await query;

      if (error) {
        console.error(`Error fetching ${tableName}:`, error);
        setError(`Failed to load ${pageTitle}. Please try again later.`);
      } else {
        setJobs(data);
      }
      setLoading(false);
    };

    fetchJobs();
  }, [tableName, pageTitle, debouncedSearchTerm]);

  const lastSeenTime = useMemo(() => {
    // A simple way to determine "new" is to check if the badge was showing.
    // This is not perfect but avoids complex timestamp logic on the client.
    // A more robust solution would involve getting last_seen_at from context.
    if (badgeState[badgeKey]) {
        // If badge is active, consider items from last 24 hours as potentially new
        return new Date(Date.now() - 24 * 60 * 60 * 1000);
    }
    return null;
  }, [badgeState, badgeKey]);

  const handleSelectJob = (id) => {
    setSelectedJobId(prevId => (prevId === id ? null : id));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-6 p-4 border border-dashed rounded-lg bg-amber-50 border-amber-300 text-amber-800">
        <p className="font-semibold">Disclaimer</p>
        <p className="text-sm">For Private/Foreign Jobs, aspirants themselves are fully responsible. The website does not provide any guarantee.</p>
      </div>

      <div className="mb-6">
        <Input
          type="text"
          placeholder="Search Jobs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-lg mx-auto"
        />
      </div>

      <div className="bg-card border rounded-lg shadow-sm overflow-hidden">
        {loading && (
          <div className="flex items-center justify-center p-10">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        )}
        {error && (
          <div className="flex flex-col items-center justify-center p-10 text-destructive">
            <AlertTriangle className="w-8 h-8 mb-2" />
            <p>{error}</p>
          </div>
        )}
        {!loading && !error && jobs.length === 0 && (
          <div className="text-center p-10 text-muted-foreground">
            <p>No {pageTitle} found.</p>
          </div>
        )}
        {!loading && !error && jobs.length > 0 && (
          <div>
            {jobs.map(job => (
              <JobRow
                key={job.id}
                job={job}
                isNew={lastSeenTime ? new Date(job.created_at) > lastSeenTime : false}
                onSelect={handleSelectJob}
                isSelected={selectedJobId === job.id}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SpecialJobListing;