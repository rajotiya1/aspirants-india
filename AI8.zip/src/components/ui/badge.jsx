import React from "react";

function Badge() {
  return null;
}

export { Badge };
