import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Menu, X, LogOut, User, Settings, Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import UserAvatar from '@/components/UserAvatar';
import { useBadges } from '@/contexts/BadgeContext';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const navLinks = [
  { to: '/dashboard', text: 'Dashboard' },
  { to: '/jobs', text: 'Jobs', badgeKey: 'jobs' },
  { to: '/tests', text: 'Tests' },
  { to: '/stories', text: 'Stories', badgeKey: 'stories' },
  { to: '/friends', text: 'Friends', badgeKey: 'friends' },
];

const MobileNavLink = ({ to, children, onClick, badgeKey }) => {
  const { badgeState } = useBadges();
  const showBadge = badgeState[badgeKey];
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        cn(
          "relative block py-3 px-4 text-lg font-medium transition-colors",
          isActive ? "text-primary bg-primary/10" : "text-foreground hover:bg-muted"
        )
      }
    >
      {children}
      {showBadge && <Badge variant="destructive" className="absolute top-1/2 -translate-y-1/2 right-4">NEW</Badge>}
    </NavLink>
  );
};

const DesktopNavLink = ({ to, children, badgeKey }) => {
  const { badgeState } = useBadges();
  const showBadge = badgeState[badgeKey];
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "relative text-sm font-semibold transition-colors px-3 py-2 rounded-md",
          isActive ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-primary"
        )
      }
    >
      {children}
      {showBadge && <span className="absolute -top-1 -right-1 block h-2.5 w-2.5 rounded-full bg-destructive ring-2 ring-background" />}
    </NavLink>
  );
};

const Header = () => {
  const { user, signOut } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 hidden md:flex">
          <Link to="/" className="mr-6 flex items-center space-x-2">
            <span className="text-xl font-bold text-foreground">DashBoard</span>
          </Link>
          <nav className="flex items-center space-x-2">
            {user && navLinks.map(link => (
              <DesktopNavLink key={link.to} to={link.to} badgeKey={link.badgeKey}>{link.text}</DesktopNavLink>
            ))}
          </nav>
        </div>

        <div className="md:hidden">
          <Button variant="ghost" size="icon" onClick={toggleMenu}>
            <Menu className="h-6 w-6" />
          </Button>
        </div>

        <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <UserAvatar user={user} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name || 'User'}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to={`/profile/${user.id}`}><User className="mr-2 h-4 w-4" />Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/settings"><Settings className="mr-2 h-4 w-4" />Settings</Link>
                </DropdownMenuItem>
                {user.is_admin && (
                  <DropdownMenuItem asChild>
                    <Link to="/admin"><Shield className="mr-2 h-4 w-4" />Admin Panel</Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={signOut}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild>
              <Link to="/">Log In</Link>
            </Button>
          )}
        </div>
      </div>

      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: '100vh' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm md:hidden"
            onClick={toggleMenu}
          >
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="fixed top-0 left-0 h-full w-64 bg-background border-r shadow-lg"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b">
                <Link to="/" className="flex items-center space-x-2" onClick={toggleMenu}>
                  <span className="font-bold">ASPIRANTS INDIA</span>
                </Link>
                <Button variant="ghost" size="icon" onClick={toggleMenu}>
                  <X className="h-6 w-6" />
                </Button>
              </div>
              <nav className="mt-6">
                {user && navLinks.map(link => (
                  <MobileNavLink key={link.to} to={link.to} onClick={toggleMenu} badgeKey={link.badgeKey}>{link.text}</MobileNavLink>
                ))}
              </nav>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;