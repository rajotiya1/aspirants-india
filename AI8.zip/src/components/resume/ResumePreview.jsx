
import React from 'react';
import ResumeTemplateModern from './ResumeTemplateModern';
import ResumeTemplateATS from './ResumeTemplateATS';
import { Card } from '@/components/ui/card';

const ResumePreview = ({ data, template, id }) => {
  return (
    <div className="bg-gray-100/50 rounded-xl p-4 border flex justify-center overflow-hidden">
      {/* 
          Container for scaling on small screens. 
          We use a fixed width container (A4 width approx 210mm ~ 794px)
          and scale it down to fit the screen.
      */}
      <div className="w-full overflow-x-auto lg:overflow-visible flex justify-center py-4">
        <div 
            className="origin-top transform scale-[0.45] sm:scale-[0.6] md:scale-[0.75] lg:scale-[0.85] xl:scale-100 transition-transform duration-300"
            style={{ 
                width: '210mm', 
                minHeight: '297mm',
                marginBottom: '-150px' // Counteract bottom margin caused by scaling
            }}
        >
            <div id={id} className="w-full h-full bg-white shadow-2xl">
                {template === 'modern' ? (
                    <ResumeTemplateModern data={data} />
                ) : (
                    <ResumeTemplateATS data={data} />
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default ResumePreview;
