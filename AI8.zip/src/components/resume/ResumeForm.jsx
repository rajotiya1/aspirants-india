
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Trash2, ChevronDown, ChevronUp, User, Briefcase, GraduationCap, Award, BookOpen, Layers, Wrench, Heart } from 'lucide-react';
import PhotoUpload from './PhotoUpload';

const Section = ({ title, icon: Icon, children, defaultOpen = false }) => {
    const [isOpen, setIsOpen] = React.useState(defaultOpen);
    return (
        <Card className="border shadow-sm mb-4 overflow-hidden">
            <div 
                className="flex items-center justify-between p-4 bg-gray-50/80 cursor-pointer hover:bg-gray-100 transition-colors"
                onClick={() => setIsOpen(!isOpen)}
            >
                <div className="flex items-center gap-2 font-semibold text-gray-800">
                    {Icon && <Icon className="w-5 h-5 text-primary" />}
                    {title}
                </div>
                {isOpen ? <ChevronUp className="w-4 h-4 text-gray-500" /> : <ChevronDown className="w-4 h-4 text-gray-500" />}
            </div>
            {isOpen && (
                <CardContent className="p-4 pt-0 mt-4 space-y-4 animate-in slide-in-from-top-2 duration-200">
                    {children}
                </CardContent>
            )}
        </Card>
    )
}

const ResumeForm = ({ data, updateData }) => {
  
  const handleChange = (section, field, value) => {
    updateData(prev => ({
        ...prev,
        [section]: typeof prev[section] === 'object' && !Array.isArray(prev[section])
            ? { ...prev[section], [field]: value }
            : value
    }));
  };

  const handleArrayChange = (section, index, field, value) => {
    updateData(prev => {
        const newArray = [...prev[section]];
        newArray[index] = { ...newArray[index], [field]: value };
        return { ...prev, [section]: newArray };
    });
  };

  const addItem = (section, initialItem) => {
    updateData(prev => ({
        ...prev,
        [section]: [...prev[section], initialItem]
    }));
  };

  const removeItem = (section, index) => {
    updateData(prev => ({
        ...prev,
        [section]: prev[section].filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="space-y-6">
      
      {/* Photo Section */}
      <Card>
          <CardHeader><CardTitle className="text-base">Profile Photo</CardTitle></CardHeader>
          <CardContent>
             <PhotoUpload 
                photo={data.photo} 
                onPhotoChange={(p) => updateData(prev => ({ ...prev, photo: p }))} 
             />
          </CardContent>
      </Card>

      {/* Personal Details */}
      <Section title="Personal Details" icon={User} defaultOpen={true}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
                <Label>Full Name</Label>
                <Input value={data.personal.name} onChange={e => handleChange('personal', 'name', e.target.value)} placeholder="e.g. Rajesh Kumar" />
            </div>
            <div className="space-y-2">
                <Label>Job Title</Label>
                <Input value={data.personal.title} onChange={e => handleChange('personal', 'title', e.target.value)} placeholder="e.g. Software Engineer" />
            </div>
            <div className="space-y-2">
                <Label>Email</Label>
                <Input value={data.personal.email} onChange={e => handleChange('personal', 'email', e.target.value)} placeholder="e.g. rajesh@example.com" />
            </div>
            <div className="space-y-2">
                <Label>Phone</Label>
                <Input value={data.personal.phone} onChange={e => handleChange('personal', 'phone', e.target.value)} placeholder="e.g. +91 98765 43210" />
            </div>
            <div className="space-y-2 sm:col-span-2">
                <Label>Address</Label>
                <Input value={data.personal.address} onChange={e => handleChange('personal', 'address', e.target.value)} placeholder="e.g. New Delhi, India" />
            </div>
             <div className="space-y-2">
                <Label>LinkedIn (Optional)</Label>
                <Input value={data.personal.linkedin} onChange={e => handleChange('personal', 'linkedin', e.target.value)} placeholder="LinkedIn Profile URL" />
            </div>
        </div>
      </Section>

      {/* Summary */}
      <Section title="Professional Summary" icon={BookOpen}>
         <div className="space-y-2">
            <Label>Career Objective / Summary</Label>
            <Textarea 
                value={data.summary} 
                onChange={e => updateData(prev => ({ ...prev, summary: e.target.value }))} 
                placeholder="Briefly describe your career goals and professional strengths..."
                className="h-32"
            />
        </div>
      </Section>

      {/* Experience */}
      <Section title="Work Experience" icon={Briefcase}>
         {data.experience.map((exp, index) => (
            <div key={index} className="p-4 border rounded-lg bg-white space-y-3 relative mb-4 last:mb-0">
                <button onClick={() => removeItem('experience', index)} className="absolute top-2 right-2 text-red-500 hover:bg-red-50 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                        <Label>Company Name</Label>
                        <Input value={exp.company} onChange={e => handleArrayChange('experience', index, 'company', e.target.value)} placeholder="e.g. Tech Solutions Ltd" />
                    </div>
                    <div className="space-y-1">
                        <Label>Job Role</Label>
                        <Input value={exp.role} onChange={e => handleArrayChange('experience', index, 'role', e.target.value)} placeholder="e.g. Junior Developer" />
                    </div>
                     <div className="space-y-1 sm:col-span-2">
                        <Label>Duration</Label>
                        <Input value={exp.duration} onChange={e => handleArrayChange('experience', index, 'duration', e.target.value)} placeholder="e.g. Jan 2020 - Present" />
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                        <Label>Description</Label>
                        <Textarea value={exp.description} onChange={e => handleArrayChange('experience', index, 'description', e.target.value)} placeholder="Describe your responsibilities and achievements..." />
                    </div>
                </div>
            </div>
         ))}
         <Button variant="outline" className="w-full" onClick={() => addItem('experience', { company: '', role: '', duration: '', description: '' })}>
            <Plus className="w-4 h-4 mr-2" /> Add Experience
         </Button>
      </Section>

      {/* Education */}
      <Section title="Education" icon={GraduationCap}>
         {data.education.map((edu, index) => (
            <div key={index} className="p-4 border rounded-lg bg-white space-y-3 relative mb-4 last:mb-0">
                <button onClick={() => removeItem('education', index)} className="absolute top-2 right-2 text-red-500 hover:bg-red-50 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                        <Label>Institute / School</Label>
                        <Input value={edu.school} onChange={e => handleArrayChange('education', index, 'school', e.target.value)} placeholder="e.g. Delhi University" />
                    </div>
                    <div className="space-y-1">
                        <Label>Degree / Class</Label>
                        <Input value={edu.degree} onChange={e => handleArrayChange('education', index, 'degree', e.target.value)} placeholder="e.g. B.Tech Computer Science" />
                    </div>
                     <div className="space-y-1">
                        <Label>Year</Label>
                        <Input value={edu.year} onChange={e => handleArrayChange('education', index, 'year', e.target.value)} placeholder="e.g. 2018 - 2022" />
                    </div>
                    <div className="space-y-1">
                        <Label>Score / Grade</Label>
                        <Input value={edu.score} onChange={e => handleArrayChange('education', index, 'score', e.target.value)} placeholder="e.g. 8.5 CGPA" />
                    </div>
                </div>
            </div>
         ))}
         <Button variant="outline" className="w-full" onClick={() => addItem('education', { school: '', degree: '', year: '', score: '' })}>
            <Plus className="w-4 h-4 mr-2" /> Add Education
         </Button>
      </Section>

      {/* Skills */}
      <Section title="Skills" icon={Wrench}>
        <div className="space-y-2">
            <Label>Skills (Comma separated)</Label>
            <Textarea 
                value={data.skills} 
                onChange={e => updateData(prev => ({ ...prev, skills: e.target.value }))} 
                placeholder="e.g. JavaScript, React, Node.js, Python, Communication, Teamwork"
                className="h-24"
            />
            <p className="text-xs text-gray-500">Separate each skill with a comma.</p>
        </div>
      </Section>

      {/* Projects */}
      <Section title="Projects" icon={Layers}>
         {data.projects.map((proj, index) => (
            <div key={index} className="p-4 border rounded-lg bg-white space-y-3 relative mb-4 last:mb-0">
                <button onClick={() => removeItem('projects', index)} className="absolute top-2 right-2 text-red-500 hover:bg-red-50 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
                <div className="space-y-1">
                    <Label>Project Title</Label>
                    <Input value={proj.title} onChange={e => handleArrayChange('projects', index, 'title', e.target.value)} placeholder="e.g. E-commerce Website" />
                </div>
                <div className="space-y-1">
                    <Label>Description</Label>
                    <Textarea value={proj.description} onChange={e => handleArrayChange('projects', index, 'description', e.target.value)} placeholder="Describe the project features and technologies used..." />
                </div>
            </div>
         ))}
         <Button variant="outline" className="w-full" onClick={() => addItem('projects', { title: '', description: '' })}>
            <Plus className="w-4 h-4 mr-2" /> Add Project
         </Button>
      </Section>

       {/* Additional Info */}
       <Section title="Languages & Hobbies" icon={Heart}>
        <div className="space-y-4">
            <div className="space-y-2">
                <Label>Languages (Comma separated)</Label>
                <Input 
                    value={data.languages} 
                    onChange={e => updateData(prev => ({ ...prev, languages: e.target.value }))} 
                    placeholder="e.g. English, Hindi, Spanish"
                />
            </div>
             <div className="space-y-2">
                <Label>Hobbies (Comma separated)</Label>
                <Input 
                    value={data.hobbies} 
                    onChange={e => updateData(prev => ({ ...prev, hobbies: e.target.value }))} 
                    placeholder="e.g. Reading, Cricket, Traveling"
                />
            </div>
        </div>
      </Section>

    </div>
  );
};

export default ResumeForm;
