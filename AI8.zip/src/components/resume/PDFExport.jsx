
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Loader2 } from 'lucide-react';
import html2pdf from 'html2pdf.js'; // Replaced manual html2canvas+jspdf with html2pdf.js library
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';

const PDFExport = ({ targetId, fileName = 'resume', className, variant = "default", size = "default" }) => {
  const [downloading, setDownloading] = useState(false);
  const { toast } = useToast();

  const handleDownload = async (e) => {
    e.preventDefault();
    e.stopPropagation();

    const element = document.getElementById(targetId);
    if (!element) {
        toast({ 
          title: "Preview Required", 
          description: "Please switch to the 'Preview & Download' tab to generate your PDF.", 
          variant: "default"
        });
        return;
    }

    try {
      setDownloading(true);
      
      // Configuration for html2pdf
      // 1. Using a higher scale helps with clarity
      // 2. 'letterRendering' isn't a standard html2canvas prop anymore but 'useCORS' is critical
      // 3. We adjust margin to 0 as the resume design itself has padding
      const opt = {
        margin:       0, 
        filename:     `${fileName}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 }, // JPEG often handles complex layouts with less artifacts than low-compression PNG in PDFs
        html2canvas:  { 
            scale: 2, 
            useCORS: true, 
            logging: false,
            // These options specifically target text rendering issues
            letterRendering: true, 
            scrollY: 0
        },
        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
      };

      // Wait a split second to ensure any React renders are complete
      await new Promise(resolve => setTimeout(resolve, 100));

      // Use the worker API
      await html2pdf().set(opt).from(element).save();

      toast({ title: "Success", description: "Resume downloaded successfully!" });
    } catch (error) {
      console.error("PDF Generation Error:", error);
      toast({ title: "Error", description: "Failed to generate PDF. Please try again.", variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Button 
        type="button" 
        onClick={handleDownload} 
        disabled={downloading}
        variant={variant}
        size={size}
        className={cn("gap-2 shadow-sm", className)}
    >
      {downloading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <Download className="h-4 w-4" />
      )}
      <span className="hidden sm:inline">{downloading ? 'Generating...' : 'Download PDF'}</span>
    </Button>
  );
};

export default PDFExport;
