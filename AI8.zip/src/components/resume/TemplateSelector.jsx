
import React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const templates = [
    { id: 'modern', name: 'Modern Clean', color: 'bg-slate-800' },
    { id: 'ats', name: 'ATS Friendly', color: 'bg-white border-2 border-gray-300' }
];

const TemplateSelector = ({ activeTemplate, onChange }) => {
  return (
    <div className="grid grid-cols-2 gap-3">
      {templates.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            "relative h-16 rounded-lg flex items-center justify-center transition-all shadow-sm",
            activeTemplate === t.id ? "ring-2 ring-primary ring-offset-2" : "hover:opacity-90",
            t.color
          )}
        >
           <span className={cn(
               "font-semibold text-sm",
               t.id === 'modern' ? 'text-white' : 'text-gray-800'
           )}>
            {t.name}
           </span>
           {activeTemplate === t.id && (
             <div className="absolute -top-2 -right-2 bg-primary text-white rounded-full p-1 shadow-md">
                <Check className="w-3 h-3" />
             </div>
           )}
        </button>
      ))}
    </div>
  );
};

export default TemplateSelector;
