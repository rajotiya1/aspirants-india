
import React, { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Upload, X } from 'lucide-react';

const PhotoUpload = ({ photo, onPhotoChange }) => {
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onPhotoChange(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemove = () => {
    onPhotoChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 p-4 border-2 border-dashed border-gray-200 rounded-lg bg-gray-50/50">
      <div className="relative w-32 h-32">
        {photo ? (
          <div className="relative w-full h-full">
            <img 
              src={photo} 
              alt="Profile Preview" 
              className="w-full h-full object-cover rounded-full border-4 border-white shadow-md"
            />
            <button
              onClick={handleRemove}
              className="absolute -top-1 -right-1 bg-red-500 text-white p-1.5 rounded-full hover:bg-red-600 transition-colors shadow-sm"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="w-full h-full bg-gray-100 rounded-full flex items-center justify-center border-2 border-gray-200 text-gray-400">
            <Camera className="w-10 h-10" />
          </div>
        )}
      </div>

      <div className="flex gap-2 w-full">
        <input
          type="file"
          accept="image/*"
          capture="user"
          className="hidden"
          ref={fileInputRef}
          onChange={handleFileChange}
        />
        <Button 
          type="button"
          variant="outline" 
          className="w-full gap-2"
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="w-4 h-4" />
          {photo ? 'Change Photo' : 'Upload Photo'}
        </Button>
      </div>
      <p className="text-xs text-muted-foreground text-center">
        Tap to upload or take a selfie. Supports JPG, PNG.
      </p>
    </div>
  );
};

export default PhotoUpload;
