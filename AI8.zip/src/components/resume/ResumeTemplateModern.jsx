
import React from 'react';

const ResumeTemplateModern = ({ data }) => {
  const { personal, summary, education, experience, skills, projects, languages, hobbies, photo } = data;

  // Explicit styles to prevent character overlapping in PDF generation
  // letter-spacing: 0.5px ensures characters don't merge
  // font-variant-ligatures: none prevents joined characters which confuse some renderers
  const safePrintStyles = {
    letterSpacing: '0.05em', 
    fontVariantLigatures: 'none',
    textRendering: 'optimizeLegibility',
    lineHeight: '1.5',
    fontFeatureSettings: '"liga" 0'
  };

  return (
    <div 
        className="w-full h-full bg-white text-gray-800 font-sans flex flex-col min-h-[297mm]"
        style={safePrintStyles}
    >
      {/* Header */}
      <div className="bg-slate-800 text-white p-8 flex items-center gap-6">
        {photo && (
          <div className="shrink-0">
            <img 
              src={photo} 
              alt={personal.name} 
              className="w-32 h-32 rounded-full border-4 border-slate-600 object-cover"
              crossOrigin="anonymous" // Important for html2canvas/html2pdf
            />
          </div>
        )}
        <div className="flex-1">
          <h1 className="text-3xl font-bold uppercase tracking-wider" style={{ letterSpacing: '0.08em' }}>{personal.name || 'Your Name'}</h1>
          <p className="text-xl text-slate-300 mt-1 tracking-wide">{personal.title || 'Professional Title'}</p>
          
          <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-300">
            {personal.email && <span>📧 {personal.email}</span>}
            {personal.phone && <span>📱 {personal.phone}</span>}
            {personal.address && <span>📍 {personal.address}</span>}
            {personal.linkedin && <span>🔗 {personal.linkedin}</span>}
          </div>
        </div>
      </div>

      <div className="flex flex-1">
        {/* Left Column */}
        <div className="w-1/3 bg-slate-100 p-6 space-y-6 border-r border-slate-200">
          
          {/* Skills */}
          {skills && (
            <section>
              <h3 className="text-lg font-bold text-slate-800 border-b-2 border-slate-300 pb-2 mb-3 uppercase tracking-wide">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {skills.split(',').map((skill, i) => (
                  <span key={i} className="bg-slate-200 text-slate-700 px-2 py-1 rounded text-sm font-medium">
                    {skill.trim()}
                  </span>
                ))}
              </div>
            </section>
          )}

          {/* Education */}
          {education.length > 0 && (
            <section>
              <h3 className="text-lg font-bold text-slate-800 border-b-2 border-slate-300 pb-2 mb-3 uppercase tracking-wide">Education</h3>
              <div className="space-y-4">
                {education.map((edu, i) => (
                  <div key={i}>
                    <p className="font-bold text-sm">{edu.degree}</p>
                    <p className="text-sm text-gray-600">{edu.school}</p>
                    <p className="text-xs text-gray-500">{edu.year}</p>
                    {edu.score && <p className="text-xs text-slate-600 mt-1">Grade: {edu.score}</p>}
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Languages */}
          {languages && (
            <section>
              <h3 className="text-lg font-bold text-slate-800 border-b-2 border-slate-300 pb-2 mb-3 uppercase tracking-wide">Languages</h3>
              <p className="text-sm text-gray-700 whitespace-pre-line">{languages}</p>
            </section>
          )}
          
           {/* Hobbies */}
           {hobbies && (
            <section>
              <h3 className="text-lg font-bold text-slate-800 border-b-2 border-slate-300 pb-2 mb-3 uppercase tracking-wide">Hobbies</h3>
              <p className="text-sm text-gray-700 whitespace-pre-line">{hobbies}</p>
            </section>
          )}
        </div>

        {/* Right Column */}
        <div className="w-2/3 p-8 space-y-6">
          
          {/* Summary */}
          {summary && (
            <section>
              <h3 className="text-xl font-bold text-slate-800 border-b-2 border-slate-200 pb-2 mb-3 uppercase tracking-wide">Profile</h3>
              <p className="text-sm leading-relaxed text-gray-700 text-justify">{summary}</p>
            </section>
          )}

          {/* Experience */}
          {experience.length > 0 && (
            <section>
              <h3 className="text-xl font-bold text-slate-800 border-b-2 border-slate-200 pb-2 mb-3 uppercase tracking-wide">Experience</h3>
              <div className="space-y-6">
                {experience.map((exp, i) => (
                  <div key={i}>
                    <div className="flex justify-between items-baseline mb-1">
                      <h4 className="font-bold text-gray-800 tracking-wide">{exp.role}</h4>
                      <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-1 rounded">{exp.duration}</span>
                    </div>
                    <p className="text-sm font-medium text-blue-600 mb-2">{exp.company}</p>
                    <p className="text-sm text-gray-600 whitespace-pre-line leading-relaxed text-justify">{exp.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* Projects */}
          {projects.length > 0 && (
            <section>
              <h3 className="text-xl font-bold text-slate-800 border-b-2 border-slate-200 pb-2 mb-3 uppercase tracking-wide">Projects</h3>
              <div className="space-y-4">
                {projects.map((proj, i) => (
                  <div key={i}>
                    <h4 className="font-bold text-gray-800 text-sm tracking-wide">{proj.title}</h4>
                    <p className="text-sm text-gray-600 mt-1 leading-relaxed text-justify">{proj.description}</p>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResumeTemplateModern;
