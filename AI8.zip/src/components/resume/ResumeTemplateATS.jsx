
import React from 'react';

const ResumeTemplateATS = ({ data }) => {
  const { personal, summary, education, experience, skills, projects, languages, hobbies } = data;

  // Explicit styles to prevent character overlapping
  const safePrintStyles = {
    letterSpacing: '0.05em', 
    fontVariantLigatures: 'none',
    textRendering: 'optimizeLegibility',
    lineHeight: '1.6',
    fontFeatureSettings: '"liga" 0'
  };

  return (
    <div 
        className="w-full h-full bg-white text-black font-serif p-10 min-h-[297mm]"
        style={safePrintStyles}
    >
      {/* Header */}
      <div className="text-center border-b-2 border-black pb-4 mb-6">
        <h1 className="text-3xl font-bold uppercase tracking-widest" style={{ letterSpacing: '0.1em' }}>{personal.name || 'YOUR NAME'}</h1>
        <div className="mt-2 text-sm flex justify-center flex-wrap gap-x-4 tracking-wide">
          {personal.email && <span>{personal.email}</span>}
          {personal.phone && <span>| {personal.phone}</span>}
          {personal.address && <span>| {personal.address}</span>}
          {personal.linkedin && <span>| {personal.linkedin}</span>}
        </div>
      </div>

      {/* Summary */}
      {summary && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Professional Summary</h2>
          <p className="text-sm leading-relaxed text-justify">{summary}</p>
        </section>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Work Experience</h2>
          <div className="space-y-4">
            {experience.map((exp, i) => (
              <div key={i}>
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold text-base tracking-wide">{exp.company}</h3>
                  <span className="text-sm italic tracking-wide">{exp.duration}</span>
                </div>
                <div className="text-sm font-semibold italic mb-1 tracking-wide">{exp.role}</div>
                <p className="text-sm text-justify whitespace-pre-line leading-relaxed">{exp.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Education */}
      {education.length > 0 && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Education</h2>
          <div className="space-y-3">
            {education.map((edu, i) => (
              <div key={i} className="flex justify-between">
                <div>
                  <div className="font-bold text-sm tracking-wide">{edu.school}</div>
                  <div className="text-sm tracking-wide">{edu.degree}</div>
                  {edu.score && <div className="text-sm text-gray-600 tracking-wide">Score/Grade: {edu.score}</div>}
                </div>
                <div className="text-sm italic text-right tracking-wide">
                  <div>{edu.year}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Skills */}
      {skills && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Technical Skills</h2>
          <p className="text-sm leading-relaxed tracking-wide text-justify">{skills}</p>
        </section>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Key Projects</h2>
          <div className="space-y-3">
            {projects.map((proj, i) => (
              <div key={i}>
                <h3 className="font-bold text-sm tracking-wide">{proj.title}</h3>
                <p className="text-sm text-justify mt-1 leading-relaxed">{proj.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Additional Info */}
      {(languages || hobbies) && (
        <section className="mb-6">
          <h2 className="text-lg font-bold uppercase border-b border-gray-400 mb-3 tracking-wider">Additional Information</h2>
          <div className="text-sm space-y-1">
             {languages && (
                <div className="grid grid-cols-[120px_1fr]">
                    <span className="font-bold tracking-wide">Languages:</span>
                    <span className="tracking-wide">{languages}</span>
                </div>
             )}
             {hobbies && (
                <div className="grid grid-cols-[120px_1fr]">
                    <span className="font-bold tracking-wide">Interests:</span>
                    <span className="tracking-wide">{hobbies}</span>
                </div>
             )}
          </div>
        </section>
      )}
    </div>
  );
};

export default ResumeTemplateATS;
