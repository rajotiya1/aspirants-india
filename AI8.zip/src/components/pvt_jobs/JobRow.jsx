import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Briefcase, Star, BookOpen, MapPin, Phone, Info, ChevronDown, Calendar } from 'lucide-react';
import { formatRelativeDate } from '@/lib/utils';

const JobDetailItem = ({ icon: Icon, label, value }) => {
  if (!value) return null;
  return (
    <div className="flex items-start py-2">
      {Icon && <Icon className="w-4 h-4 text-primary mr-3 mt-1 flex-shrink-0" />}
      <div>
        <p className="text-xs font-semibold text-muted-foreground">{label}</p>
        <p className="text-sm text-foreground">{value}</p>
      </div>
    </div>
  );
};

const JobRow = ({ job, isOpen, onToggle }) => {
  return (
    <div className="border-b border-border last:border-b-0">
      <button
        onClick={() => onToggle(job.id)}
        className="w-full text-left p-4 flex justify-between items-center cursor-pointer hover:bg-secondary/50 transition-colors"
      >
        <div className="flex items-center flex-1 min-w-0">
          <Briefcase className="w-5 h-5 text-primary mr-3 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            {/* FIXED: job_name now wraps into multiple lines instead of cutting */}
            <h3 className="text-base font-semibold text-foreground break-words whitespace-normal leading-snug">
              {job.job_name}
            </h3>
            <div className="flex items-center gap-2 mt-1">
              <Calendar className="w-3 h-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">{formatRelativeDate(job.created_at)}</span>
            </div>
          </div>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="ml-2"
        >
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
              <JobDetailItem label="Salary" value={job.salary} />
              <JobDetailItem icon={Star} label="Experience" value={job.experience} />
              <JobDetailItem icon={BookOpen} label="Qualification" value={job.qualification} />
              <JobDetailItem icon={MapPin} label="Address" value={`${job.address}, ${job.city}, ${job.district}, ${job.state}`} />
              <JobDetailItem icon={Phone} label="Contact No." value={job.contact_no} />
              <JobDetailItem icon={Info} label="Interview/Apply" value={job.interview_apply} />
            </div>
            {job.job_jpeg && (
              <div className="px-4 pb-4">
                <a
                  href={job.job_jpeg}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-medium text-blue-600 hover:underline"
                >
                  View Job Image
                </a>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default JobRow;