import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import JobRow from './JobRow';
import { Briefcase } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format, isToday, parseISO } from 'date-fns';

const JobList = ({ jobs }) => {
  const [openJobId, setOpenJobId] = useState(null);

  const handleToggle = (jobId) => {
    setOpenJobId(prevId => (prevId === jobId ? null : jobId));
  };

  if (jobs.length === 0) {
    return (
      <div className="text-center py-16">
        <Briefcase className="mx-auto h-16 w-16 text-muted-foreground" />
        <h3 className="mt-4 text-xl font-semibold">कोई नौकरी नहीं मिली</h3>
        <p className="mt-2 text-muted-foreground">इस श्रेणी में कोई नौकरी उपलब्ध नहीं है।</p>
      </div>
    );
  }

  const groupedJobs = jobs.reduce((acc, job) => {
    const date = format(parseISO(job.created_at), 'yyyy-MM-dd');
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(job);
    return acc;
  }, {});

  const sortedDates = Object.keys(groupedJobs).sort((a, b) => new Date(b) - new Date(a));

  return (
    <div className="space-y-4">
      {sortedDates.map(date => {
        const dateObj = parseISO(date);
        const isNew = isToday(dateObj);
        return (
          <div key={date}>
            <div className="flex items-center gap-2 mb-2 px-1">
              <h2 className="text-lg font-bold text-foreground">
                {format(dateObj, 'MMMM d, yyyy')}
              </h2>
              {isNew && <Badge variant="destructive">NEW</Badge>}
            </div>
            <Card className="shadow-md">
              <AnimatePresence>
                {groupedJobs[date].map((job) => (
                  <JobRow
                    key={job.id}
                    job={job}
                    isOpen={openJobId === job.id}
                    onToggle={handleToggle}
                  />
                ))}
              </AnimatePresence>
            </Card>
          </div>
        );
      })}
    </div>
  );
};

export default JobList;