
import React from "react";
import { formatDate, normalizeUrl } from "@/lib/utils";
import {
  Check,
  Link as LinkIcon,
  Globe,
  FileText,
  UserPlus,
  Download,
} from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const KV = ({ label, children }) => (
  <div className="grid grid-cols-[150px,1fr] gap-x-3 text-sm leading-5 font-bold">
    <div className="text-left text-gray-600">{label} :</div>
    <div className="text-left flex items-center gap-2">{children ?? "-"}</div>
  </div>
);

const ActionButton = ({ href, to, onClick, children, className, label }) => {
  const motionProps = {
    whileHover: { scale: 1.02 },
    whileTap: { scale: 0.98 },
    className: `w-full py-2.5 mb-2 rounded-lg text-white font-semibold shadow-md flex items-center justify-center gap-2 ${className}`,
  };

  if (href) {
    return (
      <motion.a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => e.stopPropagation()}
        aria-label={label}
        {...motionProps}
      >
        {children}
      </motion.a>
    );
  }

  if (to) {
    return (
      <motion.div {...motionProps}>
        <Link
          to={to}
          onClick={(e) => e.stopPropagation()}
          className="w-full h-full flex items-center justify-center gap-2"
        >
          {children}
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.button onClick={onClick} aria-label={label} {...motionProps}>
      {children}
    </motion.button>
  );
};

const JobTableCard = React.memo(
  ({ job, onAdd, isAdded, expanded, onToggle }) => {
    const detailsText = (
      job.details ?? job.detail ?? job.description ?? ""
    )
      .toString()
      .trim();

    const applyLink = job.direct_link ? normalizeUrl(job.direct_link) : null;
    const websiteLink = job.official_website
      ? normalizeUrl(job.official_website)
      : null;
    const pdfLink = job.pdf_url || job.notification_pdf;

    return (
      <div className="border-b bg-white rounded-lg shadow-sm mb-2 overflow-hidden">
        {/* 🔹 Header Row */}
        <button
          onClick={() => onToggle(job.id)}
          className="w-full text-left hover:bg-gray-50 cursor-pointer"
        >
          <div className="job-table-row text-sm font-bold">
            <div className="job-table-cell py-2 align-top w-[40%]">
              {job.name_of_post}
            </div>
            <div className="job-table-cell py-2 align-top w-[35%]">
              {job.qualification}
            </div>
            <div className="job-table-cell py-2 align-top w-[25%] text-left md:text-right whitespace-nowrap">
              {formatDate(job.last_date)}
            </div>
          </div>
        </button>

        {/* 🔹 Expandable Details */}
        <div
          className={`overflow-hidden transition-all duration-300 ease-out ${
            expanded ? "max-h-[1400px] opacity-100" : "max-h-0"
          }`}
        >
          <div className="p-3 bg-white border-t text-sm font-bold">
            {detailsText && (
              <p className="text-sm leading-5 text-black mb-3 text-justify">
                {detailsText}
              </p>
            )}

            <div className="space-y-1 mb-4">
              <KV label="Nos. of Posts">
                {job.no_of_post || job.total_posts || "N/A"}
              </KV>
              <KV label="Age Limit">{job.age_limit || "N/A"}</KV>
              <KV label="State">{job.state || "N/A"}</KV>
              <KV label="Recruitment Board">
                {job.requirement_board || job.board || "N/A"}
              </KV>
              <KV label="Form filling Start">
                {job.form_filling_start
                  ? formatDate(job.form_filling_start)
                  : "N/A"}
              </KV>
              <KV label="Pay-Scale">{job.pay_scale || "N/A"}</KV>
            </div>

            {/* 🔹 Action Buttons */}
            <div className="flex flex-col items-center">
              {/* A to Z Detail */}
              {job.slug && (
                <ActionButton
                  to={`/job/${job.slug}`}
                  className="bg-pink-600 hover:bg-pink-700"
                  label="A to Z Detail"
                >
                  <FileText className="w-4 h-4" /> A to Z Detail
                </ActionButton>
              )}

              {/* Add to My Profile */}
              <ActionButton
                onClick={(e) => {
                  e.stopPropagation();
                  if (isAdded) return;
                  onAdd(job);
                }}
                className={
                  isAdded
                    ? "bg-gray-500 cursor-not-allowed opacity-70"
                    : "bg-orange-600 hover:bg-orange-700"
                }
                label={isAdded ? "Job Added" : "Add to My Profile"}
              >
                {isAdded ? (
                  <>
                    <Check className="w-4 h-4" /> Added to Profile
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" /> Add to My Profile
                  </>
                )}
              </ActionButton>

              {/* Download PDF - DIRECT LINK */}
              {pdfLink && (
                <ActionButton
                  href={normalizeUrl(pdfLink)}
                  className="bg-purple-600 hover:bg-purple-700"
                  label="Download PDF"
                >
                  <Download className="w-4 h-4" /> Download PDF
                </ActionButton>
              )}

              {/* Official Website */}
              {websiteLink && (
                <ActionButton
                  href={websiteLink}
                  className="bg-blue-600 hover:bg-blue-700"
                  label="Official Website"
                >
                  <Globe className="w-4 h-4" /> Official Website
                </ActionButton>
              )}

              {/* Apply Online */}
              {applyLink && (
                <ActionButton
                  href={applyLink}
                  className="bg-emerald-600 hover:bg-emerald-700"
                  label="Apply Online"
                >
                  <LinkIcon className="w-4 h-4" /> Apply Online
                </ActionButton>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
);

export default JobTableCard;
