import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import SEO from '@/components/SEO';
import { Loader2 } from 'lucide-react';
import CategoryTabBar from '@/components/jobs/CategoryTabBar';
import FilterBar from '@/components/jobs/FilterBar';
import JobCategoryPage from '@/components/jobs/JobCategoryPage';
import { supabase } from '@/lib/customSupabaseClient';
import { fetchJobCategories } from '@/lib/jobs-data';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';

const JobPageWrapper = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const { toast } = useToast();
    const { user } = useAuth();

    const [categories, setCategories] = useState([]);
    const [loadingCategories, setLoading] = useState(true);
    const [activeIndex, setActiveIndex] = useState(0);
    const [filters, setFilters] = useState({ keyword: '', state: 'all' });
    const [userJobIds, setUserJobIds] = useState(new Set());

    const swiperRef = useRef(null);
    const tabsRef = useRef(null);
    const urlDebounceRef = useRef(null);
    const cacheRef = useRef({});
    
    const gestureModeRef = useRef('idle'); // 'idle' | 'swipe' | 'programmatic'
    const startIndexRef = useRef(0);
    const scrollEndTimer = useRef();

    const queryParams = useMemo(() => new URLSearchParams(location.search), [location.search]);

    const scrollActiveTabIntoView = useCallback(() => {
        const wrap = tabsRef.current;
        if (!wrap) return;
        const btn = wrap.children?.[activeIndex];
        if (!btn) return;
        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }, [activeIndex]);

    useEffect(() => {
        let mounted = true;
        const getCategories = async () => {
            setLoading(true);
            try {
                const fetchedCategories = await fetchJobCategories();
                if (mounted) {
                    const catSlug = queryParams.get('cat') || 'all';
                    const initialIndex = fetchedCategories.findIndex(c => c.slug === catSlug);
                    const validIndex = initialIndex >= 0 ? initialIndex : 0;
                    
                    setCategories(fetchedCategories);
                    setActiveIndex(validIndex);
                    startIndexRef.current = validIndex;
                }
            } catch (error) {
                console.error("Failed to fetch categories", error);
            } finally {
                if (mounted) {
                    setLoading(false);
                }
            }
        };
        getCategories();
        
        return () => {
            mounted = false;
            if (urlDebounceRef.current) clearTimeout(urlDebounceRef.current);
            if (scrollEndTimer.current) clearTimeout(scrollEndTimer.current);
        };
    }, []);

    useEffect(() => {
        if (!user) return;
        let mounted = true;
        const fetchSavedJobs = async () => {
            const { data } = await supabase.from('user_saved_jobs').select('job_id').eq('user_id', user.id);
            if (data && mounted) setUserJobIds(new Set(data.map(j => j.job_id)));
        };
        fetchSavedJobs();
        return () => { mounted = false; };
    }, [user]);

    const handleFilterChange = useCallback((newFilters) => {
        setFilters(newFilters);
    }, []);

    const handleJobAdd = useCallback(async (job) => {
        if (!user) return;
        const { error } = await supabase.from('user_saved_jobs').insert({ user_id: user.id, job_id: job.id });
        if (error) {
            toast({ title: "Error saving job", variant: "destructive" });
        } else {
            setUserJobIds(prev => new Set(prev).add(job.id));
            toast({ title: "Job Saved!", description: `${job.name_of_post} added.` });
        }
    }, [user, toast]);

    const handleTabClick = useCallback((index) => {
      const swiper = swiperRef.current?.swiper;
      if (!swiper || typeof swiper.slideTo !== 'function') return;
      if (index === activeIndex) return;
    
      gestureModeRef.current = 'programmatic';
      startIndexRef.current  = swiper.activeIndex ?? index;
      swiper.slideTo(index, 0);
      
      setTimeout(() => { gestureModeRef.current = 'idle'; }, 250);
    }, [activeIndex]);

    const handleSlideChange = useCallback((swiper) => {
      const next = swiper?.activeIndex ?? 0;
      if (gestureModeRef.current === 'swipe') {
        const start = startIndexRef.current;
        const clamped = Math.max(start - 1, Math.min(start + 1, next));
        if (clamped !== next) swiper.slideTo(clamped, 0);
        if (clamped !== activeIndex) setActiveIndex(clamped);
      } else {
        if (next !== activeIndex) setActiveIndex(next);
      }
      setTimeout(scrollActiveTabIntoView, 0);
    }, [activeIndex, scrollActiveTabIntoView]);
    
    const handleSlideChangeEnd = useCallback((swiper) => {
        const idx = swiper?.activeIndex ?? 0;
        const cat = categories[idx];
        if (!cat) return;
        
        startIndexRef.current = idx;
        
        setTimeout(scrollActiveTabIntoView, 0);

        if (urlDebounceRef.current) clearTimeout(urlDebounceRef.current);
        urlDebounceRef.current = setTimeout(() => {
            navigate(`/jobs?cat=${cat.slug}`, { replace: true });
        }, 180);
    }, [categories, navigate, scrollActiveTabIntoView]);

    const handleSwiper = useCallback((swiper) => {
        swiperRef.current = { swiper };
        
        const el = swiper?.el;
        if (el) {
          const onDown = () => { gestureModeRef.current = 'swipe'; startIndexRef.current = swiper.activeIndex ?? 0; };
          const onUp   = () => { gestureModeRef.current = 'idle'; };
          el.addEventListener('touchstart', onDown, {passive:true});
          el.addEventListener('pointerdown', onDown, {passive:true});
          el.addEventListener('touchend', onUp, {passive:true});
          el.addEventListener('pointerup', onUp, {passive:true});
        
          const onScroll = () => {
            clearTimeout(scrollEndTimer.current);
            scrollEndTimer.current = setTimeout(() => {
              if (gestureModeRef.current !== 'swipe') return;
              const idxNow = swiper.activeIndex ?? 0;
              const start  = startIndexRef.current;
              const clamped = Math.max(start - 1, Math.min(start + 1, idxNow));
              if (clamped !== idxNow) swiper.slideTo(clamped, 0);
              startIndexRef.current = clamped;
            }, 120);
          };
          el.addEventListener('scroll', onScroll, {passive:true});

          return () => {
            el.removeEventListener('touchstart', onDown);
            el.removeEventListener('pointerdown', onDown);
            el.removeEventListener('touchend', onUp);
            el.removeEventListener('pointerup', onUp);
            el.removeEventListener('scroll', onScroll);
          }
        }
    }, []);

    useEffect(() => {
        scrollActiveTabIntoView();
    }, [activeIndex, scrollActiveTabIntoView]);
    
    return (
        <div className="flex flex-col h-full bg-background">
            <SEO title="Find Jobs" description="Browse the latest government and private job openings." />
            
            <div className="bg-background flex-shrink-0 z-10">
                {loadingCategories ? (
                    <div className="h-[48px] flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin"/></div>
                ) : (
                    <CategoryTabBar 
                        categories={categories} 
                        activeIndex={activeIndex} 
                        onTabClick={handleTabClick} 
                        tabsRef={tabsRef}
                    />
                )}
            </div>

            <div className="flex-shrink-0 bg-background z-10">
                <FilterBar onFilterChange={handleFilterChange} />
            </div>
            
            <div className="flex-grow overflow-hidden">
              {loadingCategories ? (
                <div className="w-full h-full flex justify-center items-center">
                  <Loader2 className="w-8 h-8 animate-spin" />
                </div>
              ) : categories.length > 0 ? (
                <Swiper
                  onSwiper={handleSwiper}
                  onSlideChange={handleSlideChange}
                  onSlideChangeTransitionEnd={handleSlideChangeEnd}
                  initialSlide={activeIndex}
                  slidesPerView={1}
                  spaceBetween={0}
                  allowTouchMove
                  speed={200}
                  threshold={12}
                  touchAngle={45}
                  lazyPreloadPrevNext={2}
                  className="h-full"
                >
                  {categories.map((category, index) => (
                    <SwiperSlide
                      key={category.slug}
                      className="bg-background"
                    >
                      <JobCategoryPage
                        category={category}
                        filters={filters}
                        userJobIds={userJobIds}
                        onJobAdd={handleJobAdd}
                        isActive={index === activeIndex}
                        cache={{ current: cacheRef.current }}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              ) : null}
            </div>
        </div>
    );
};

export default JobPageWrapper;