import React from 'react';
import { cn } from '@/lib/utils';

const CategoryTabBar = ({ categories, activeIndex, onTabClick, tabsRef, disabled }) => (
  <div
    ref={tabsRef}
    role="tablist"
    className="flex items-center overflow-x-auto whitespace-nowrap px-2 gap-2 bg-background shadow-sm h-[48px]"
    style={{
      scrollBehavior: 'smooth',
      WebkitOverflowScrolling: 'touch',
    }}
  >
    {categories.map((category, index) => {
      const isActive = activeIndex === index;
      return (
        <button
          key={category.slug}
          role="tab"
          aria-selected={isActive}
          title={category.name}
          disabled={disabled}
          onClick={() => onTabClick(index)}
          className={cn(
            'inline-flex items-center justify-center shrink-0 min-w-[96px] h-[44px] px-3 rounded-t-md text-sm font-semibold leading-none outline-none border-b-2 transition-all duration-200',
            'focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-wavy-navy',
            {
              'text-gray-600 hover:text-wavy-navy border-transparent': !isActive,
              'text-wavy-navy bg-wavy-navy/10 border-wavy-navy': isActive,
              'cursor-not-allowed opacity-60': disabled,
            }
          )}
        >
          {category.name}
        </button>
      );
    })}
  </div>
);

export default React.memo(CategoryTabBar);