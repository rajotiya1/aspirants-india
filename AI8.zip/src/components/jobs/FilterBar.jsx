import React, { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, X } from 'lucide-react';
import { fetchStates } from '@/api/states.js';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDebounce } from '@/hooks/useDebounce';

const FilterBar = ({ onFilterChange }) => {
    const [keyword, setKeyword] = useState('');
    const [selectedState, setSelectedState] = useState('all');
    const [states, setStates] = useState([]);
    const debouncedKeyword = useDebounce(keyword, 300);
    
    useEffect(() => {
        fetchStates().then((opts) => {
          const norm = (opts || []).map(o => ({
            value: o?.value ?? o?.state_key ?? 'all',
            label: o?.label ?? o?.state_name ?? 'All India',
          }));
          const withAll = norm[0]?.value === 'all'
            ? norm
            : [{ value: 'all', label: 'All India' }, ...norm.filter(x => x.value !== 'all')];
          setStates(withAll);
        }).catch(console.error);
    }, []);

    useEffect(() => {
        onFilterChange({
          keyword: debouncedKeyword,
          stateKey: selectedState,
          state: selectedState,
        });
    }, [debouncedKeyword, selectedState, onFilterChange]);

    const handleClear = () => {
        setKeyword('');
    };

    return (
        <div className="flex items-center space-x-2 p-2 bg-background sticky top-0 z-10" style={{boxShadow: '0 2px 4px rgba(0,0,0,0.05)'}}>
            <div className="relative flex-grow">
                <Input
                    type="text"
                    placeholder="Qualifications, Keywords..."
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    className="pl-10"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                {keyword && (
                    <Button
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1/2 transform -translate-y-1/2 h-7 w-7"
                        onClick={handleClear}
                    >
                        <X className="h-4 w-4" />
                    </Button>
                )}
            </div>
            
            <Select value={selectedState} onValueChange={setSelectedState}>
                <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="All India" />
                </SelectTrigger>
                <SelectContent className="max-h-72 overflow-y-auto bg-white text-black">
                  {states.map(s => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label}
                    </SelectItem>
                  ))}
                </SelectContent>
            </Select>
        </div>
    );
};

export default FilterBar;