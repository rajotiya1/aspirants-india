import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/contexts/SupabaseAuthContext";
import { Loader2, Briefcase, Search } from "lucide-react";
import JobTableCard from "@/components/jobs/JobTableCard";
import LatestArticles from "@/components/LatestArticles";
import { supabase } from "@/lib/customSupabaseClient";
import { formatDate } from "@/lib/utils";
import { fetchJobs } from "@/api/jobs";

const JobTableHeader = () => (
  <div className="table w-full table-fixed bg-gray-100 dark:bg-gray-800 text-foreground font-bold text-sm rounded-t-md sticky top-0 z-10 shadow-sm">
    <div className="table-row">
      <div className="table-cell p-2 py-2 align-top w-[40%]">Name of Post</div>
      <div className="table-cell p-2 py-2 align-top w-[35%]">Qualification</div>
      <div className="table-cell p-2 py-2 align-top text-right w-[25%]">
        Last Date
      </div>
    </div>
  </div>
);

const SkeletonLoader = () => (
  <div className="space-y-3 mt-4 px-2 sm:px-4">
    <div className="h-10 bg-muted rounded-lg animate-pulse"></div>
    {[...Array(8)].map((_, i) => (
      <div key={i} className="h-12 bg-muted rounded-lg animate-pulse"></div>
    ))}
  </div>
);

const JobCategoryPage = ({ categorySlug }) => {
  const { toast } = useToast();
  const { user } = useAuth();

  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [offset, setOffset] = useState(0);
  const [userJobIds, setUserJobIds] = useState(new Set());
  const [expandedJobId, setExpandedJobId] = useState(null);
  const [initialLoad, setInitialLoad] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const loaderRef = useRef(null);
  const scrollContainerRef = useRef(null);

  // -------- Load Saved Jobs --------
  useEffect(() => {
    if (!user) return;
    const fetchSavedJobs = async () => {
      const { data } = await supabase
        .from("user_saved_jobs")
        .select("job_id_bigint, job_id_uuid")
        .eq("user_id", user.id);
      if (data) {
        const ids = new Set();
        data.forEach((j) => {
          if (j.job_id_bigint) ids.add(String(j.job_id_bigint));
          if (j.job_id_uuid) ids.add(j.job_id_uuid);
        });
        setUserJobIds(ids);
      }
    };
    fetchSavedJobs();
  }, [user]);

  // -------- Load Jobs --------
  const loadJobs = useCallback(
    async (isNewCategory) => {
      setLoading(true);
      const currentOffset = isNewCategory ? 0 : offset;
      try {
        const { data: newJobs } = await fetchJobs({
          category_slug: categorySlug,
          offset: currentOffset,
          limit: 20,
        });

        if (isNewCategory) {
          setJobs(newJobs || []);
        } else {
          setJobs((prev) => [...prev, ...(newJobs || [])]);
        }

        setHasMore((newJobs?.length || 0) > 0);
        if (initialLoad) setInitialLoad(false);
      } catch (error) {
        if (error.code !== "PGRST103") {
          toast({
            title: "Error fetching jobs",
            description: error.message,
            variant: "destructive",
          });
        }
        setHasMore(false);
      } finally {
        setLoading(false);
      }
    },
    [categorySlug, offset, toast, initialLoad, user]
  );

  useEffect(() => {
    setJobs([]);
    setOffset(0);
    setHasMore(true);
    setInitialLoad(true);
    if (scrollContainerRef.current) scrollContainerRef.current.scrollTop = 0;
  }, [categorySlug]);

  useEffect(() => {
    loadJobs(offset === 0);
  }, [offset, categorySlug]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading && !initialLoad) {
          setOffset((prev) => prev + 20);
        }
      },
      { root: scrollContainerRef.current, rootMargin: "200px" }
    );
    const currentLoader = loaderRef.current;
    if (currentLoader) observer.observe(currentLoader);
    return () => {
      if (currentLoader) observer.unobserve(currentLoader);
    };
  }, [hasMore, loading, initialLoad]);

  // -------- Save Job --------
  const handleJobAdd = useCallback(
    async (job) => {
      if (!user) return;

      const tableSourceMap = {
        "all-states": "jobs_all_states",
        banking: "jobs_banking",
        forces: "jobs_forces",
        teaching: "jobs_teaching",
        engineering: "jobs_engineering",
        railway: "jobs_railway",
      };
      const tableSource = tableSourceMap[categorySlug] || "jobs";

      const isUuid = job.id.length > 15;
      const payload = {
        user_id: user.id,
        table_source: tableSource,
        job_id_bigint: isUuid ? null : job.id,
        job_id_uuid: isUuid ? job.id : null,
      };

      const { error } = await supabase.from("user_saved_jobs").insert(payload);

      if (error) {
        toast({
          title: error.code === "23505" ? "Already Saved" : "Error saving job",
          description:
            error.code === "23505"
              ? "This job is already in your profile."
              : error.message,
          variant: error.code === "23505" ? "default" : "destructive",
        });
      } else {
        setUserJobIds((prev) => new Set(prev).add(String(job.id)));
        toast({
          title: "Job Saved!",
          description: `${job.name_of_post} added.`,
        });
      }
    },
    [user, toast, categorySlug]
  );

  const handleToggle = useCallback(
    (jobId) => setExpandedJobId((prev) => (prev === jobId ? null : jobId)),
    []
  );

  // -------- Filter Logic --------
  const filteredJobs = useMemo(() => {
    if (!searchTerm.trim()) return jobs;
    const term = searchTerm.toLowerCase();
    return jobs.filter((job) => {
      return (
        job?.name_of_post?.toLowerCase().includes(term) ||
        job?.qualification?.toLowerCase().includes(term) ||
        job?.state?.toLowerCase().includes(term) ||
        job?.authority?.toLowerCase().includes(term)
      );
    });
  }, [jobs, searchTerm]);

  // -------- Grouping --------
  const groupedJobs = useMemo(() => {
    const isAllStates = categorySlug === "all-states";
    return filteredJobs.reduce((acc, job) => {
      const groupKey = isAllStates
        ? job.state || "Other"
        : formatDate(job.date_of_post);
      if (!acc[groupKey]) acc[groupKey] = [];
      acc[groupKey].push(job);
      return acc;
    }, {});
  }, [filteredJobs, categorySlug]);

  const sortedGroupKeys = useMemo(() => {
    const isAllStates = categorySlug === "all-states";
    const keys = Object.keys(groupedJobs);
    if (isAllStates) return keys.sort((a, b) => a.localeCompare(b));
    return keys.sort(
      (a, b) =>
        new Date(b.split("/").reverse().join("-")) -
        new Date(a.split("/").reverse().join("-"))
    );
  }, [groupedJobs, categorySlug]);

  if (initialLoad) return <SkeletonLoader />;

  return (
    <div ref={scrollContainerRef} className="flex-grow overflow-y-auto px-2 sm:px-4 h-full">
      {jobs.length > 0 ? (
        <>
          {/* 🔍 Search Bar */}
          <div className="sticky top-0 bg-white z-20 py-2">
            <div className="relative w-full">
              <Search className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search by Job, Qualification, or State..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <JobTableHeader />

          {sortedGroupKeys.map((groupKey) => (
            <div key={groupKey} className="mb-4">
              <div className="text-center bg-blue-50 text-blue-700 p-1 rounded-md my-2 font-semibold border border-blue-200 shadow-sm">
                {groupKey}
              </div>
              {groupedJobs[groupKey].map((job) => (
                <JobTableCard
                  key={job.id}
                  job={job}
                  onAdd={handleJobAdd}
                  isAdded={userJobIds.has(String(job.id))}
                  expanded={expandedJobId === job.id}
                  onToggle={handleToggle}
                />
              ))}
            </div>
          ))}

          {/*<div className="mt-8">
            <LatestArticles />
          </div>*/}
        </>
      ) : (
        <div className="text-center py-10 text-gray-500 flex flex-col items-center min-h-[300px] justify-center">
          <Briefcase className="w-12 h-12 mb-2 text-gray-400" />
          No jobs found for this category.
        </div>
      )}

      {loading && !initialLoad && (
        <div className="text-center py-4">
          <Loader2 className="w-6 h-6 animate-spin mx-auto" />
        </div>
      )}
      <div ref={loaderRef} style={{ height: "1px" }} />
    </div>
  );
};

export default JobCategoryPage;