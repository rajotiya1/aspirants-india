import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from "@/components/ui/use-toast";
import { submitJobSuggestion } from '@/services/aspirantsApi';

import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { X, Send, Loader2 } from 'lucide-react';

const CreateSurveyModal = ({ isOpen, onClose }) => {
    const { register, handleSubmit, reset, formState: { errors } } = useForm();
    const { user } = useAuth();
    const { toast } = useToast();
    const [isSubmitting, setIsSubmitting] = useState(false);

    const onSubmit = async (formData) => {
        if (!user) {
            toast({ variant: "destructive", title: "Authentication Error", description: "You must be logged in to submit a suggestion." });
            return;
        }

        setIsSubmitting(true);
        try {
            await submitJobSuggestion({ ...formData, userId: user.id });
            toast({
                title: "Suggestion Submitted!",
                description: "After verification, your submitted vacancy will be made live.",
                className: "bg-green-500 text-white"
            });
            reset();
            onClose();
        } catch (error) {
            toast({ variant: "destructive", title: "Submission Failed", description: error.message });
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ y: 50, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: 50, opacity: 0 }}
                        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                        className="relative w-full max-w-lg bg-gradient-to-b from-slate-800 to-slate-900 p-6 rounded-2xl border border-white/20 shadow-2xl text-white"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white transition-colors">
                            <X size={24} />
                        </button>

                        <h2 className="text-2xl font-bold text-center mb-2 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-pink-500">Create New Job Survey</h2>
                        <p className="text-center text-sm text-gray-400 mb-6">Your submission will be reviewed by an admin.</p>
                        
                        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                            <div>
                                <Label htmlFor="vacancy_name" className="text-gray-300">Name of Vacancy</Label>
                                <Input id="vacancy_name" {...register("vacancy_name", { required: "Vacancy name is required." })} className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400" placeholder="e.g., Haryana University Clerk" />
                                {errors.vacancy_name && <p className="text-red-400 text-xs mt-1">{errors.vacancy_name.message}</p>}
                            </div>
                            <div>
                                <Label htmlFor="vacancy_details" className="text-gray-300">Details of Vacancy</Label>
                                <Textarea id="vacancy_details" {...register("vacancy_details")} className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400" placeholder="Provide any additional details..." />
                            </div>
                             <div>
                                <Label htmlFor="suggester_name" className="text-gray-300">Your Name</Label>
                                <Input id="suggester_name" {...register("suggester_name", { required: "Your name is required." })} className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400" placeholder="Enter your full name" />
                                {errors.suggester_name && <p className="text-red-400 text-xs mt-1">{errors.suggester_name.message}</p>}
                            </div>
                             <div>
                                <Label htmlFor="suggester_email" className="text-gray-300">Your Email-ID</Label>
                                <Input id="suggester_email" type="email" {...register("suggester_email", { required: "Email is required.", pattern: { value: /^\S+@\S+$/i, message: "Invalid email address" }})} className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400" placeholder="you@example.com" />
                                {errors.suggester_email && <p className="text-red-400 text-xs mt-1">{errors.suggester_email.message}</p>}
                            </div>
                             <div>
                                <Label htmlFor="suggester_mobile" className="text-gray-300">Your Mobile No.</Label>
                                <Input id="suggester_mobile" type="tel" {...register("suggester_mobile")} className="bg-slate-700/50 border-slate-600 text-white placeholder-slate-400" placeholder="Enter your mobile number" />
                            </div>

                            <Button type="submit" disabled={isSubmitting} className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-lg shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105">
                                {isSubmitting ? <Loader2 className="animate-spin" /> : <><Send className="mr-2" size={18} /> Submit for Verification</>}
                            </Button>
                        </form>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};

export default CreateSurveyModal;