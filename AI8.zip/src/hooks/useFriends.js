import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';

export const useFriends = () => {
    const { user } = useAuth();
    const [friends, setFriends] = useState([]);
    const [friendCount, setFriendCount] = useState(0);
    const [loading, setLoading] = useState(true);

    const fetchFriends = useCallback(async () => {
        if (!user) {
            setLoading(false);
            return;
        }
        setLoading(true);
        const { data, error, count } = await supabase
            .from('friendships')
            .select('*, requester:requester_id(*), addressee:addressee_id(*)', { count: 'exact' })
            .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`)
            .eq('status', 'accepted');

        if (error) {
            console.error("Error fetching friends", error);
        } else {
            const friendProfiles = data.map(f => f.requester.id === user.id ? f.addressee : f.requester);
            setFriends(friendProfiles);
            setFriendCount(count || 0);
        }
        setLoading(false);
    }, [user]);

    useEffect(() => {
        if(user) fetchFriends();
        
        const channel = supabase.channel('public:friendships')
          .on('postgres_changes', { event: '*', schema: 'public', table: 'friendships' }, (payload) => {
              const record = payload.new || payload.old;
              if (record && (record.requester_id === user?.id || record.addressee_id === user?.id)) {
                fetchFriends();
              }
          })
          .subscribe();
        
        return () => {
            supabase.removeChannel(channel);
        };
    }, [user, fetchFriends]);

    return { friends, friendCount, loading };
}