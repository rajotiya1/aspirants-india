import { useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const isValidUUID = (str) => {
  if (typeof str !== 'string') return false;
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
};

export function useTargetUserId() {
  const { userId: routeId } = useParams();
  const { user } = useAuth();
  
  // Priority 1: A valid UUID from the route parameter.
  if (isValidUUID(routeId)) {
    return routeId;
  }
  
  // Priority 2: The currently logged-in user's ID.
  if (user?.id && isValidUUID(user.id)) {
    return user.id;
  }
  
  // Fallback: Return null if no valid ID is available.
  return null;
}