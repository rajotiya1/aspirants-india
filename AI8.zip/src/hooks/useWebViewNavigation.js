import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const useWebViewNavigation = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handlePopState = (event) => {
      const isRootPage = location.pathname === '/dashboard' || location.pathname === '/';
      
      if (isRootPage) {
        if (window.Android && typeof window.Android.exitApp === 'function') {
          window.Android.exitApp();
        } else {
          console.log("WebView exitApp interface not found. On a browser, this would not close the tab.");
        }
      } else {
        navigate(-1);
      }
    };
    
    const handleAndroidBack = () => {
       handlePopState();
    };

    window.addEventListener('popstate', handlePopState);
    
    if (window.Android) {
      window.handleBackButton = handleAndroidBack;
    }

    return () => {
      window.removeEventListener('popstate', handlePopState);
      if (window.Android) {
        delete window.handleBackButton;
      }
    };
  }, [location, navigate]);
};

export default useWebViewNavigation;