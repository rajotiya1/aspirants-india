import { useState, useCallback } from 'react';
import { shouldRetry, getRetryDelay } from '@/lib/errorUtils';

export const useRetry = (maxAttempts = 3) => {
  const [isRetrying, setIsRetrying] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  const executeWithRetry = useCallback(async (asyncFunction, onError) => {
    let lastError = null;
    
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        setRetryCount(attempt);
        
        if (attempt > 0) {
          setIsRetrying(true);
          const delay = getRetryDelay(attempt - 1);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
        
        const result = await asyncFunction();
        setIsRetrying(false);
        setRetryCount(0);
        return { data: result, error: null };
        
      } catch (error) {
        lastError = error;
        
        if (!shouldRetry(error, attempt, maxAttempts)) {
          break;
        }
      }
    }
    
    setIsRetrying(false);
    setRetryCount(0);
    
    if (onError) {
      onError(lastError);
    }
    
    return { data: null, error: lastError };
  }, [maxAttempts]);

  return {
    executeWithRetry,
    isRetrying,
    retryCount,
  };
};