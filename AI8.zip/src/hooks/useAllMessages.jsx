import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { decryptMessage } from '@/lib/crypto';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

export const useAllMessages = (openChatCallback, getChatStates) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState({});
  const [unreadCounts, setUnreadCounts] = useState({});
  const toastRef = useRef(new Set());

  const fetchAllMessages = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase.rpc('get_all_messages_for_user');

    if (error) {
      console.error('Error fetching all messages:', error);
      return;
    }

    const decryptedMessages = data.map(msg => {
      try {
        const decrypted = decryptMessage(msg.encrypted_content, user.id, msg.sender_id === user.id ? msg.receiver_id : msg.sender_id);
        return { ...msg, content: decrypted.content };
      } catch (e) {
        console.error("Failed to decrypt message:", msg.id, e);
        return { ...msg, content: "🔒 Failed to decrypt message" };
      }
    }).filter(Boolean);

    const messagesByFriend = {};
    const newUnreadCounts = {};
    decryptedMessages.forEach(msg => {
      const friendId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
      if (!messagesByFriend[friendId]) {
        messagesByFriend[friendId] = [];
      }
      messagesByFriend[friendId].push(msg);
      if (!msg.is_read && msg.receiver_id === user.id) {
        newUnreadCounts[friendId] = (newUnreadCounts[friendId] || 0) + 1;
      }
    });

    setMessages(messagesByFriend);
    setUnreadCounts(newUnreadCounts);
  }, [user]);

  const handleNewMessage = useCallback(async (payload) => {
    const newMessage = payload.new;
    if (!user || newMessage.sender_id === user.id) return;

    const friendId = newMessage.sender_id;

    try {
      const decrypted = decryptMessage(newMessage.encrypted_content, user.id, friendId);
      if (!decrypted || !decrypted.content) {
        console.error(`Failed to decrypt message from ${friendId}.`);
        return;
      }

      const messageWithContent = { ...newMessage, content: decrypted.content };

      setMessages(prev => ({
        ...prev,
        [friendId]: [...(prev[friendId] || []), messageWithContent]
      }));

      const currentChatStates = getChatStates();
      const chatState = currentChatStates[friendId];

      if (!chatState || chatState.minimized) {
        setUnreadCounts(prev => ({ ...prev, [friendId]: (prev[friendId] || 0) + 1 }));
        
        if (!toastRef.current.has(friendId)) {
            const { data: friendProfile } = await supabase.from('profiles').select('id, name, avatar_path').eq('id', friendId).single();
            if (friendProfile) {
                toast({
                    title: `New message from ${friendProfile.name}`,
                    description: messageWithContent.content,
                    action: <Button variant="secondary" size="sm" onClick={() => openChatCallback(friendProfile)}>Open Chat</Button>
                });
                toastRef.current.add(friendId);
                setTimeout(() => toastRef.current.delete(friendId), 5000); 
            }
        }
      } else {
        markMessagesAsRead(friendId, false);
      }

    } catch (error) {
      console.error('Error handling new message:', error);
    }
  }, [user, toast, openChatCallback, getChatStates]);

  const markMessagesAsRead = useCallback(async (friendId, clearLocalCount = true) => {
    if (!user) return;
    if (clearLocalCount) {
        setUnreadCounts(prev => {
            const newCounts = {...prev};
            delete newCounts[friendId];
            return newCounts;
        });
    }
    const { error } = await supabase.rpc('mark_messages_as_read', { p_friend_id: friendId });
    if (error) {
        console.error('Error marking messages as read:', error);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchAllMessages();
    } else {
      setMessages({});
      setUnreadCounts({});
    }
  }, [user, fetchAllMessages]);

  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`chat-messages-for-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${user.id}` },
        handleNewMessage
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, handleNewMessage]);

  return { messages, unreadCounts, setMessages, markMessagesAsRead };
};