import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { decryptMessage } from '@/lib/crypto';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

export const useAllMessages = (openChatCallback) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState({});
  const [unreadCounts, setUnreadCounts] = useState({});
  const [loading, setLoading] = useState(true);
  const chatStatesRef = useRef({});

  const fetchAllMessages = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.rpc('get_all_messages_for_user');

    if (error) {
      console.error('Error fetching all messages:', error);
      toast({ title: "Error", description: "Could not load messages.", variant: "destructive" });
      setLoading(false);
      return;
    }
    
    const newMessages = {};
    const newUnreadCounts = {};
    
    data.forEach(msg => {
      const friendId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
      if (!newMessages[friendId]) {
        newMessages[friendId] = [];
      }
      try {
        const decrypted = decryptMessage(msg.encrypted_content, user.id, friendId);
        newMessages[friendId].push({ ...msg, content: decrypted.content });

        if (msg.receiver_id === user.id && !msg.is_read) {
            newUnreadCounts[friendId] = (newUnreadCounts[friendId] || 0) + 1;
        }

      } catch (e) {
        console.error("Failed to decrypt message:", msg.id, e);
        newMessages[friendId].push({ ...msg, content: "🔒 Failed to decrypt message" });
      }
    });

    Object.keys(newMessages).forEach(friendId => {
        newMessages[friendId].sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
    });

    setMessages(newMessages);
    setUnreadCounts(newUnreadCounts);
    setLoading(false);

  }, [user, toast]);

  useEffect(() => {
    fetchAllMessages();
  }, [fetchAllMessages]);
  
  const handleNewMessage = useCallback(async (payload) => {
    const newMessage = payload.new;
    if (!user || newMessage.sender_id === user.id) return;
    
    const friendId = newMessage.sender_id;

    try {
      const decrypted = decryptMessage(newMessage.encrypted_content, user.id, friendId);
      if (!decrypted || !decrypted.content) return;

      const messageWithContent = { ...newMessage, content: decrypted.content };

      setMessages(prev => ({
        ...prev,
        [friendId]: [...(prev[friendId] || []), messageWithContent]
      }));
      
      const isChatOpen = chatStatesRef.current[friendId] && !chatStatesRef.current[friendId].minimized;

      if (!isChatOpen) {
          setUnreadCounts(prev => ({ ...prev, [friendId]: (prev[friendId] || 0) + 1 }));
      } else {
        await supabase.rpc('mark_messages_as_read', { p_friend_id: friendId });
      }

      if (!chatStatesRef.current[friendId]) {
        const { data: friendProfile } = await supabase.from('profiles').select('*').eq('id', friendId).single();
         if (friendProfile) {
           toast({
              title: `New message from ${friendProfile.name}`,
              description: messageWithContent.content,
              action: <Button variant="secondary" size="sm" onClick={() => openChatCallback(friendProfile)}>Open Chat</Button>
          });
        }
      }

    } catch (error) {
      console.error('Error handling new message:', error);
    }
  }, [user, toast, openChatCallback]);

  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel(`chat-messages-for-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `receiver_id=eq.${user.id}` },
        handleNewMessage
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, handleNewMessage]);

  const updateChatStatesRef = (states) => {
    chatStatesRef.current = states;
  };

  return { messages, setMessages, unreadCounts, setUnreadCounts, loading, updateChatStatesRef, fetchAllMessages };
};