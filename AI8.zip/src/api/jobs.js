import { supabase } from "@/lib/customSupabaseClient";

const safeFetchFromTable = async (tableName, { q = "", state_key = "all", limit = 20, offset = 0, category_slug = "all" }) => {
  let countQuery = supabase.from(tableName).select("*", { count: "exact", head: true });

  if (category_slug !== "all") {
    countQuery = countQuery.eq("category_slug", category_slug);
  }
  if (state_key !== "all") {
    countQuery = countQuery.eq("state_key", state_key);
  }
  if (q.trim() !== "") {
    const like = `%${q.trim()}%`;
    countQuery = countQuery.or(`name_of_post.ilike.${like},qualification.ilike.${like},authority.ilike.${like},state.ilike.${like}`);
  }

  const { count, error: countError } = await countQuery;

  if (countError) {
    console.error(`Error counting jobs from ${tableName}:`, countError);
    throw countError;
  }

  if (offset >= count) {
    return { data: [], count };
  }

  let dataQuery = supabase
    .from(tableName)
    .select("*")
    .order("date_of_post", { ascending: false })
    .order("id", { ascending: false })
    .range(offset, offset + limit - 1);

  if (category_slug !== "all") {
    dataQuery = dataQuery.eq("category_slug", category_slug);
  }
  if (state_key !== "all") {
    dataQuery = dataQuery.eq("state_key", state_key);
  }
  if (q.trim() !== "") {
    const like = `%${q.trim()}%`;
    dataQuery = dataQuery.or(`name_of_post.ilike.${like},qualification.ilike.${like},authority.ilike.${like},state.ilike.${like}`);
  }

  const { data, error: dataError } = await dataQuery;

  if (dataError) {
    console.error(`Error fetching jobs from ${tableName}:`, dataError);
    throw dataError;
  }

  return { data, count };
};


export async function fetchJobs(options) {
  const tableMap = {
    'all-states': 'jobs_all_states',
    'banking': 'jobs_banking',
    'forces': 'jobs_forces',
    'teaching': 'jobs_teaching',
    'engineering': 'jobs_engineering',
    'railway': 'jobs_railway',
    'default': 'jobs'
  };
  
  const tableName = tableMap[options.category_slug] || tableMap['default'];
  
  // If the category slug matches a special table, we don't want to filter by it again inside the query.
  // But for the main 'jobs' table, we DO want to filter by category_slug if it's not 'all'.
  const fetchOptions = { ...options };
  if (tableMap[options.category_slug]) {
      // It's a dedicated table, so we don't need to filter by category_slug within it.
      // But we should allow 'all' to pass through for the main jobs table.
      if(tableName !== 'jobs') {
        fetchOptions.category_slug = 'all';
      }
  }

  return safeFetchFromTable(tableName, fetchOptions);
}