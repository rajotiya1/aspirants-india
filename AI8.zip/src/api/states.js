import { supabase } from '@/lib/customSupabaseClient';

export async function fetchStates() {
  const { data, error } = await supabase
    .from('job_states_all')                 // ⬅️ master+counts view
    .select('state_key,state_name,is_ut,job_count')
    .order('is_ut', { ascending: true })
    .order('state_name', { ascending: true });

  if (error) throw error;

  // First option: All India
  const options = [
    { value: 'all', label: 'All India' },
    ...(data ?? []).map(s => ({
      value: s.state_key,                   // filter key
      label: s.state_name,                  // shown to user
      isUT: !!s.is_ut,
      count: s.job_count
    })),
  ];
  console.log('STATE OPTIONS (from API):', options.slice(0, 5));
  return options;
}