# Project Safepoint Checklist (2025-10-07)

This document provides a concise checklist for maintaining project stability and ensuring safe future development.

**Last Reviewed:** 2025-10-07
**Reviewer:** Horizon AI Audit
**Change Scope:** Only Documentation. Project code untouched.

---

## 🚫 Don'ts (Critical Rules)

-   **DO NOT** modify `src/main.jsx` or `src/App.jsx` without a clear understanding of the entire application structure. They are the heart of the app.
-   **DO NOT** modify `src/contexts/SupabaseAuthContext.jsx`. It controls all user authentication, sessions, and initial profile fetching.
-   **DO NOT** hardcode API keys or secrets. The current implementation in `src/lib/customSupabaseClient.js` is a security risk. Move keys to a `.env` file.
-   **DO NOT** introduce new data-fetching patterns without first checking existing services (`src/services/`) and hooks (`src/hooks/`).

## ✅ Single-Source-of-Truth Targets

For all future development, use the following Supabase tables, views, and RPCs as the definitive source for data.

-   **User Profiles:** `profiles` (Table)
-   **Friendships:** `friendships` (Table) and `is_friend` (RPC)
-   **Saved Jobs:** `get_all_saved_jobs` (RPC) - This is the unified function for all job types.
-   **Applied Jobs:** `getMyAppliedJobsWithDetails` (Service function wrapping RPC/query)
-   **General Job Listings:** `jobs_public_v2` (View) - **RECOMMENDED** for future development to unify job data.
-   **Job Categories:** `job_categories_bar` (View) - **RECOMMENDED** for category navigation.

## 🧪 How to Test Filters via REST

You can test Supabase queries directly in your browser or with a tool like Postman/cURL without exposing secret keys. Use the public `anon` key.

**Base URL:** `https://quomkiuitctcghdppqrj.supabase.co/rest/v1/`

**Required Headers:**
-   `apikey: [YOUR_SUPABASE_ANON_KEY]`
-   `Authorization: Bearer [YOUR_SUPABASE_ANON_KEY]`

**Example: Get jobs in Haryana with "Clerk" keyword (using recommended view)**

```
GET https://quomkiuitctcghdppqrj.supabase.co/rest/v1/jobs_public_v2?state_key=eq.haryana&or=(name_of_post.ilike.*clerk*,qualification.ilike.*clerk*)
```

**Example: Call the `get_all_saved_jobs` RPC (requires a valid user JWT)**

```
POST https://quomkiuitctcghdppqrj.supabase.co/rest/v1/rpc/get_all_saved_jobs
Authorization: Bearer [USER_JWT_TOKEN]
Content-Type: application/json

{ "p_user_id": "the-user-uuid-to-query" }
```

## ⏪ Quick Rollback Note

Before making any significant changes to the codebase:

1.  **Press the 'Hostinger Horizons' dropdown menu at the top left corner of your screen.**
2.  **Press the 'Export Project' button to download a complete `.zip` backup.**

If a change introduces a critical error, you can revert by simply re-uploading the last known good `.zip` file to the project. This is the fastest way to restore functionality.