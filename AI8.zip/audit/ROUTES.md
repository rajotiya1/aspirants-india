# Discovered Routes & Navigation Items (2025-10-07)

This document lists all defined application routes and their corresponding components, as found in `src/App.jsx`.

**Last Reviewed:** 2025-10-07
**Reviewer:** Horizon AI Audit
**Change Scope:** Only Documentation. Project code untouched.

---

## Application Routes

The application uses a nested routing structure with a main `AppShell` for authenticated users.

| Path                                  | Component             | Page/Feature          | Protection     | Notes                                                     |
| ------------------------------------- | --------------------- | --------------------- | -------------- | --------------------------------------------------------- |
| `/`                                   | `RootRedirect`        | Redirect Logic        | Auth Redirect  | Redirects to `/welcome` if logged in, else to `/login`.   |
| `/login`                              | `Login`               | Login                 | Public         |                                                           |
| `/update-password`                    | `UpdatePassword`      | Update Password       | Public         | For password recovery.                                    |
| `/welcome`                            | `WelcomeScreen`       | Welcome Screen        | Protected      | Landing page after login.                                 |
| `/app`                                | `AppShell`            | App Shell             | Protected      | Main layout for the authenticated app.                    |
| `/app/dashboard/*`                    | `AppDashboard`        | Dashboard             | Protected      | Nested routes for dashboard sections.                     |
| `/app/jobs/*`                         | `AppJobs`             | Jobs Section          | Protected      | Nested routes for all job-related pages.                  |
| `/app/profile/*`                      | `AppProfile`          | Profile Section       | Protected      | Handles all user profile tabs and dynamic user IDs.       |
| `/app/study/*`                        | `AppStudy`            | Study Material        | Protected      | Nested routes for study content.                          |
| `/app/exams/*`                        | `AppExams`            | Exams & Results       | Protected      | Nested routes for exams, results, etc.                    |
| `/job/:slug`                          | `JobDetail`           | Job Detail            | Protected      | Standalone page for a specific job.                       |
| `/stories/:slug`                      | `StoryDetailPage`     | Story Detail          | Protected      | Standalone page for a specific story.                     |
| `/notice/:id/pdf`                     | `PdfViewerPage`       | PDF Viewer            | Protected      | Displays PDF notifications.                               |
| `/mania`                              | `ManiaGameHome`       | Mania Game Home       | Protected      |                                                           |
| `/mania/play/:levelId/:setOrder`      | `ManiaGamePlay`       | Mania Game Play       | Protected      |                                                           |
| `/mania/summary/:sessionId`           | `ManiaGameSummary`    | Mania Game Summary    | Protected      |                                                           |
| `/admin`                              | `Admin`               | Admin Panel           | Admin Only     | Accessible only by admin users.                           |
| `/sitemap.xml`                        | `Sitemap`             | Sitemap               | Public         | XML Sitemap for SEO.                                      |
| `*`                                   | `Navigate`            | Catch-all Redirect    | -              | Redirects any unmatched route to `/`.                     |

## Main Navigation Structure

The main navigation is handled by the `AppShell`, which likely contains a bottom tab bar for the primary sections of the app. Based on the routing structure, the main navigation items are:

-   **Dashboard** (`/app/dashboard`)
-   **Jobs** (`/app/jobs`)
-   **Profile** (`/app/profile`)
-   **Study** (`/app/study`)
-   **Exams** (`/app/exams`)