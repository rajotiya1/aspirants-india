# Codebase Audit Report (2025-10-07)

This report provides a read-only analysis of the current state of the application, focusing on data sources, navigation, and potential risks. No changes have been made to the codebase.

**Last Reviewed:** 2025-10-07
**Reviewer:** Horizon AI Audit
**Change Scope:** Only Documentation. Project code untouched.

---

## 1. Data Sources & Supabase Usage

The application fetches data from a wide range of Supabase tables and functions. The logic is distributed across components, pages, and dedicated service files.

### Key Data Endpoints & Tables in Use:

*   **Profiles:**
    *   **Source:** `supabase.from('profiles')`
    *   **Files:** `src/pages/profile/MyProfileInfo.jsx`, `src/contexts/SupabaseAuthContext.jsx`, `src/pages/Friends.jsx`, etc.
    *   **Usage:** Core user data, authentication, and profile information.

*   **Friendships:**
    *   **Source:** `supabase.from('friendships')` and `supabase.rpc('is_friend', ...)`
    *   **Files:** `src/pages/Friends.jsx`, `src/components/FriendshipButton.jsx`
    *   **Usage:** Managing friend requests and relationships.

*   **Jobs (Multiple Sources):**
    *   **`user_saved_jobs` & `get_all_saved_jobs` RPC:** Used in `src/components/profile/SavedJobsTab.jsx` to fetch jobs from multiple tables (`jobs`, `jobs_all_states`, `jobs_banking`, etc.). This is the unified source for saved jobs.
    *   **`asp_applications` & `getMyAppliedJobsWithDetails` Service:** Used in `src/pages/profile/AppliedJobsPage.jsx` to fetch applied jobs.
    *   **`jobs` table:** Still referenced in `src/lib/jobs-data.js` for general job category listings.

*   **Educational & Achievements:**
    *   **Source:** `supabase.from('educational_details')`, `supabase.from('job_achievements')`
    *   **Files:** `src/components/profile/EducationalDetailsTab.jsx`, `src/components/profile/AchievementsTab.jsx`
    *   **Usage:** User-specific details, protected by `is_friend` RLS.

*   **Test Performance:**
    *   **Source:** `supabase.from('daily_leaderboard')`
    *   **File:** `src/components/profile/TestPerformanceTab.jsx`
    *   **Usage:** User's test results, protected by `is_friend` RLS.

### Supabase Client Configuration:

*   The primary Supabase client is initialized in `src/lib/customSupabaseClient.js`.
*   Authentication logic is centralized in `src/contexts/SupabaseAuthContext.jsx`.
*   **Note:** The project correctly uses a centralized client, but API keys are not managed via environment variables, which is a security risk.

## 2. Navigation & Routes

The application has been refactored to use a main `AppShell` for authenticated users, with nested routes for different sections.

*   **Main Shell:** `src/app/AppShell.jsx` wraps the core authenticated experience.
*   **Routing:** Defined in `src/App.jsx`. It correctly separates public routes (`/login`), the `/welcome` screen, and the main `/app/*` routes.
*   **Dynamic Profile Routes:** The profile section (`/app/profile/*`) uses dynamic routing with `:tab` and `:userId` parameters. The `useTargetUserId` hook correctly resolves the user ID to fetch data for, preventing UUID syntax errors.

## 3. Risk Map (DO-NOT-TOUCH)

These files are critical entry points or configuration files. Modifying them without careful consideration can break the entire application.

*   `src/main.jsx`: Main application entry point.
*   `src/App.jsx`: Root component, defines routing and providers.
*   `src/contexts/SupabaseAuthContext.jsx`: Handles all user authentication and session logic.
*   `src/app/AppShell.jsx`: The main layout for the authenticated app.
*   `vite.config.js`: Build tool configuration.
*   `package.json`: Project dependencies and scripts.
*   `src/lib/customSupabaseClient.js`: Supabase client initialization.

## 4. Build Status

A build dry-run cannot be performed in this environment. However, based on the code:
*   The project uses Vite with a post-build script (`tools/post-build.js`), indicating some form of build-time optimization or file manipulation.
*   Hardcoded API keys remain a security concern for production builds.
*   The use of `lazy` loading for components is a good practice for performance.

## 5. Recommendations (DO NOT APPLY)

The following are high-level recommendations for future improvements.

*   **Secure API Keys:** Migrate Supabase URL and Anon Key from `src/lib/customSupabaseClient.js` to `.env` variables (`import.meta.env.VITE_...`).
*   **Consolidate Job Data Sources:** While `get_all_saved_jobs` unifies fetching for saved jobs, general job listings still rely on older table structures. Migrating all job-related queries to use a single, comprehensive view like `jobs_public_v2` would simplify logic.
*   **Code Cleanup:** The `audit` folder contains several files (`GREPS.txt`, `ROUTES.md`, etc.) that seem to be from a previous, manual audit. While useful, they are now outdated. This automated report supersedes them. The file `src/api/jobs.js` appears to be dead code and could be removed.