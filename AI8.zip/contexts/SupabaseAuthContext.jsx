import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useMemo,
} from "react";

import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  // Sync user + profile from Supabase
  const updateSession = useCallback(async (newSession) => {
    setSession(newSession);

    if (newSession?.user) {
      const { data: profile } = await supabase
        .from("profiles")
        .select("is_admin")
        .eq("id", newSession.user.id)
        .single();

      setUser({
        ...newSession.user,
        is_admin: profile?.is_admin || false,
      });
    } else {
      setUser(null);
    }

    setLoading(false);
  }, []);

  // On first load + listen for auth changes
  useEffect(() => {
    const load = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      updateSession(session);
    };

    load();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      updateSession(session);
    });

    return () => subscription.unsubscribe();
  }, [updateSession]);

  // Signup
  const signUp = useCallback(
    async (email, password, options) => {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options,
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Sign up Failed",
          description: error.message,
        });
      }

      return { error };
    },
    [toast]
  );

  // Login
  const signIn = useCallback(
    async (email, password) => {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Sign in Failed",
          description: error.message,
        });
      }

      return { error };
    },
    [toast]
  );

  // Logout — bug-free
  const signOut = useCallback(
    async () => {
      const { error } = await supabase.auth.signOut({
        scope: "global",
      });

      // ignore duplicate logout errors
      if (error && !error.message.includes("session_id")) {
        toast({
          variant: "destructive",
          title: "Sign out Failed",
          description: error.message,
        });
      }

      // cleanup in any condition
      localStorage.removeItem("supabase.auth.token");

      return { error };
    },
    [toast]
  );

  const value = useMemo(
    () => ({
      user,
      session,
      loading,
      signUp,
      signIn,
      signOut,
    }),
    [user, session, loading, signUp, signIn, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context)
    throw new Error("useAuth must be used within an AuthProvider");
  return context;
};
